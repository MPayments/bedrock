/* global React, ReactDOM */
const { useState, useEffect } = React;
const {
  FinanceSidebar, CrmTopnav, Subheader,
  CustomersScreen, CustomerDetailScreen,
  DealsScreen, DealDetailScreen,
  BalancesScreen, RatesScreen, RoutesScreen, RequisitesScreen,
  SystemScreen, TweaksPanel, Icon, cx,
} = window;

const SCREENS = [
  { app: "fin", id: "fin-system", label: "Design system", frame: "fin-plain" },
  { app: "fin", id: "fin-balances", label: "Balances", frame: "fin", crumbs: ["Treasury", "Balances"] },
  { app: "fin", id: "fin-rates", label: "Currency rates", frame: "fin", crumbs: ["Treasury", "Currency rates"] },
  { app: "fin", id: "fin-rates-config", label: "Currency rates · sources", frame: "fin", crumbs: ["Treasury", "Currency rates", "Sources"] },
  { app: "fin", id: "fin-routes", label: "Payment routes", frame: "fin", crumbs: ["Flows", "Payment routes"] },
  { app: "fin", id: "fin-route-edit", label: "Payment route · builder", frame: "fin", crumbs: ["Flows", "Payment routes", "RT-081"] },
  { app: "fin", id: "fin-requisites", label: "Requisites", frame: "fin", crumbs: ["Entities", "Requisites"] },
  { app: "fin", id: "fin-requisite-edit", label: "Requisite · create/edit", frame: "fin", crumbs: ["Entities", "Requisites", "New"] },
  { app: "fin", id: "fin-providers", label: "Requisite providers", frame: "fin", crumbs: ["Entities", "Providers"] },
  { app: "fin", id: "fin-provider-edit", label: "Provider · create/edit", frame: "fin", crumbs: ["Entities", "Providers", "New"] },
  { app: "fin", id: "fin-workbench", label: "Deal workbench (treasury)", frame: "fin", crumbs: ["Deals", "DL-4401"] },
  { app: "fin", id: "fin-customers", label: "Customers (list)", frame: "fin", crumbs: ["Entities", "Customers"] },
  { app: "fin", id: "fin-customer", label: "Customer · detail (bilingual)", frame: "fin", crumbs: ["Entities", "Customers", "Severnaya Stal JSC"] },
  { app: "crm", id: "crm-deals", label: "Deals (pipeline)", frame: "crm", crumbs: ["Deals"] },
  { app: "crm", id: "crm-deal", label: "Deal · detail", frame: "crm", crumbs: ["Deals", "DL-4401"] },
  { app: "crm", id: "crm-customers", label: "Customers (list)", frame: "crm", crumbs: ["Customers"] },
  { app: "crm", id: "crm-customer", label: "Customer · detail (bilingual)", frame: "crm", crumbs: ["Customers", "Severnaya Stal JSC"] },
];

const ShowcaseNav = ({ active, onPick, collapsed, onCollapse }) => {
  if (collapsed) {
    return (
      <button className="showcase-nav" style={{ padding: "8px 10px", cursor: "pointer" }} onClick={onCollapse}>
        <span className="hstack" style={{ gap: 6 }}>
          <Icon name="menu" size={14} /> <span style={{ fontSize: 12.5 }}>Screens</span>
        </span>
      </button>
    );
  }
  const finance = SCREENS.filter(s => s.app === "fin");
  const crm = SCREENS.filter(s => s.app === "crm");
  return (
    <div className="showcase-nav">
      <div className="showcase-nav-head">
        <div className="showcase-nav-title">Bedrock · Prototype</div>
        <button className="icon-btn" onClick={onCollapse} title="Collapse"><Icon name="x" size={14} /></button>
      </div>
      <div className="showcase-nav-list">
        <div className="showcase-app-label">Finance</div>
        {finance.map((s, i) => (
          <div key={s.id} className={cx("showcase-item", active === s.id && "active")} onClick={() => onPick(s.id)}>
            <span>{s.label}</span>
            <span className="showcase-item-kbd">{i + 1}</span>
          </div>
        ))}
        <div className="showcase-app-label">CRM</div>
        {crm.map((s, i) => (
          <div key={s.id} className={cx("showcase-item", active === s.id && "active")} onClick={() => onPick(s.id)}>
            <span>{s.label}</span>
            <span className="showcase-item-kbd">{finance.length + i + 1}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

function App() {
  const [tweaks, setTweaks] = useState(window.BEDROCK_TWEAKS || {});
  const [active, setActive] = useState(() => localStorage.getItem("bedrock-screen") || "fin-customer");
  const [tweaksOpen, setTweaksOpen] = useState(true);
  const [navCollapsed, setNavCollapsed] = useState(false);

  useEffect(() => {
    document.documentElement.setAttribute("data-type", tweaks.typography || "sans-mono");
  }, [tweaks.typography]);

  useEffect(() => {
    localStorage.setItem("bedrock-screen", active);
  }, [active]);

  const updateTweaks = (patch) => {
    const next = { ...tweaks, ...patch };
    setTweaks(next);
    try {
      window.parent.postMessage({ type: "__edit_mode_set_keys", edits: patch }, "*");
    } catch {}
  };

  useEffect(() => {
    const onMsg = (e) => {
      if (e.data?.type === "__activate_edit_mode") setTweaksOpen(true);
      if (e.data?.type === "__deactivate_edit_mode") setTweaksOpen(false);
    };
    window.addEventListener("message", onMsg);
    try { window.parent.postMessage({ type: "__edit_mode_available" }, "*"); } catch {}
    return () => window.removeEventListener("message", onMsg);
  }, []);

  const s = SCREENS.find(x => x.id === active) || SCREENS[0];

  const content = () => {
    switch (active) {
      case "fin-system": return <SystemScreen />;
      case "fin-balances": return <window.BalancesScreen />;
      case "fin-rates": return <window.RatesScreen />;
      case "fin-rates-config": return <window.RatesConfigScreen />;
      case "fin-routes": return <window.RoutesScreen />;
      case "fin-route-edit": return <window.RouteBuilderScreen onBack={() => setActive("fin-routes")} />;
      case "fin-requisites": return <window.RequisitesScreen />;
      case "fin-requisite-edit": return <window.RequisiteEditorScreen onBack={() => setActive("fin-requisites")} />;
      case "fin-providers": return <window.ProvidersScreen onOpen={() => setActive("fin-provider-edit")} onNew={() => setActive("fin-provider-edit")} />;
      case "fin-provider-edit": return <window.ProviderEditorScreen onBack={() => setActive("fin-providers")} />;
      case "fin-workbench": return <window.TreasuryDealWorkbench onBack={() => setActive("crm-deals")} />;
      case "fin-customers": return <CustomersScreen app="finance" onOpen={() => setActive("fin-customer")} />;
      case "fin-customer": return <CustomerDetailScreen app="finance" bilingualLayout={tweaks.bilingualLayout} />;
      case "crm-deals": return <DealsScreen onOpen={() => setActive("crm-deal")} />;
      case "crm-deal": return <DealDetailScreen />;
      case "crm-customers": return <CustomersScreen app="crm" onOpen={() => setActive("crm-customer")} />;
      case "crm-customer": return <CustomerDetailScreen app="crm" bilingualLayout={tweaks.bilingualLayout} />;
      default: return <SystemScreen />;
    }
  };

  const subheader = s.crumbs ? (
    <Subheader crumbs={s.crumbs} right={
      <div className="hstack" style={{ gap: 6 }}>
        <span className="mono" style={{ fontSize: 11, color: "var(--text-faint)" }}>
          {s.app === "fin" ? "finance.bedrock.io" : "crm.bedrock.io"}
        </span>
      </div>
    } />
  ) : null;

  // FRAME: finance with sidebar, crm with topnav, or plain
  let frame;
  if (s.frame === "fin") {
    frame = (
      <div className="app">
        <FinanceSidebar
          collapsed={tweaks.sidebarCollapsed}
          onToggle={() => updateTweaks({ sidebarCollapsed: !tweaks.sidebarCollapsed })}
          activeId={
            active === "fin-balances" ? "balances" :
            active === "fin-rates" || active === "fin-rates-config" ? "rates" :
            active === "fin-routes" || active === "fin-route-edit" ? "routes" :
            active === "fin-requisites" || active === "fin-requisite-edit" ? "requisites" :
            active === "fin-providers" || active === "fin-provider-edit" ? "providers" :
            active === "fin-workbench" ? "workbench" :
            (active === "fin-customers" || active === "fin-customer") ? "customers-fin" :
            null
          }
          onNavigate={(id) => {
            const map = {
              balances: "fin-balances", rates: "fin-rates",
              routes: "fin-routes", requisites: "fin-requisites",
              providers: "fin-providers", workbench: "fin-workbench",
              "customers-fin": "fin-customers",
            };
            if (map[id]) setActive(map[id]);
          }}
        />
        <div className="main">
          {subheader}
          <div className="content">{content()}</div>
        </div>
      </div>
    );
  } else if (s.frame === "crm") {
    frame = (
      <div className="main">
        <CrmTopnav
          activeId={
            active === "crm-deals" || active === "crm-deal" ? "deals" :
            active === "crm-customers" || active === "crm-customer" ? "customers-crm" :
            "dashboard-crm"
          }
          onNavigate={(id) => {
            if (id === "deals") setActive("crm-deals");
            if (id === "customers-crm") setActive("crm-customers");
          }}
        />
        {subheader}
        <div className="content">{content()}</div>
      </div>
    );
  } else {
    frame = (
      <div className="main">
        <div className="content">{content()}</div>
      </div>
    );
  }

  return (
    <>
      {frame}
      <ShowcaseNav active={active} onPick={setActive} collapsed={navCollapsed} onCollapse={() => setNavCollapsed(!navCollapsed)} />
      <TweaksPanel tweaks={tweaks} onChange={updateTweaks} open={tweaksOpen} onToggle={() => setTweaksOpen(!tweaksOpen)} />
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
