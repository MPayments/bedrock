/* global React, Icon, Btn, IconBtn, Segmented, Switch, cx */
const { useState } = React;

const TweaksPanel = ({ tweaks, onChange, open, onToggle }) => {
  if (!open) {
    return (
      <button type="button" className="tweaks-panel" style={{ width: "auto", padding: "8px 12px", cursor: "pointer" }} onClick={onToggle}>
        <span className="hstack" style={{ gap: 6 }}>
          <Icon name="settings" size={14} /> <span style={{ fontSize: 12.5 }}>Tweaks</span>
        </span>
      </button>
    );
  }
  return (
    <div className="tweaks-panel">
      <div className="tweaks-head">
        <div className="tweaks-title"><Icon name="settings" size={14} /> Tweaks</div>
        <IconBtn name="x" title="Close" onClick={onToggle} />
      </div>
      <div className="tweaks-body">
        <div className="tweaks-group">
          <div className="tweaks-label">Bilingual field layout</div>
          <Segmented value={tweaks.bilingualLayout}
            onChange={v => onChange({ bilingualLayout: v })}
            options={[
              { value: "toggle", label: "Toggle" },
              { value: "sbs", label: "Side-by-side" },
              { value: "tabs", label: "Per-field tabs" },
            ]} />
          <div style={{ fontSize: 11.5, color: "var(--text-muted)", marginTop: 2 }}>
            Only affects Customer → General tab
          </div>
        </div>

        <div className="tweaks-group">
          <div className="tweaks-label">Finance sidebar</div>
          <div className="hstack" style={{ justifyContent: "space-between" }}>
            <span style={{ fontSize: 13 }}>Collapsed</span>
            <Switch on={tweaks.sidebarCollapsed} onChange={v => onChange({ sidebarCollapsed: v })} />
          </div>
        </div>

        <div className="tweaks-group">
          <div className="tweaks-label">Typography</div>
          <Segmented value={tweaks.typography}
            onChange={v => onChange({ typography: v })}
            options={[
              { value: "sans-mono", label: "Sans + Mono" },
              { value: "sans-only", label: "Sans only" },
            ]} />
        </div>
      </div>
    </div>
  );
};

window.TweaksPanel = TweaksPanel;
