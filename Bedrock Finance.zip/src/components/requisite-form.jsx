/* global React, Icon, Btn, Badge, Card, Field, Input, Select, SearchSelect, Checkbox, Segmented, CountryPill, cx */
/*
  Shared RequisiteForm
  ----------------------------------------------------------------
  Single source of truth for any requisite-editing surface.
  Used by:
    - Finance → Requisites → create/edit (full-page)
    - CRM → Customer → Counterparties (modal add/edit per counterparty)

  Contract:
    value       : requisite draft (see data.jsx for shape)
    onChange    : (next) => void
    holderLock  : optional { kind, id, name, country } — if set,
                  holder picker is replaced with a read-only chip
    compact     : boolean — hide field-map side rail when rendered in a modal
*/

const { PROVIDERS, PROVIDER_KINDS } = window.BEDROCK_DATA;

// Public kind taxonomy — used everywhere
const KIND_META = {
  ru_bank:        { label: "Russian bank",         short: "RU bank",   icon: "building", group: "Banks" },
  swift_bank:     { label: "International bank",   short: "IBAN/SWIFT", icon: "globe",   group: "Banks" },
  blockchain:     { label: "Blockchain",           short: "Crypto",    icon: "hash",     group: "Crypto" },
  psp:            { label: "Payment processor",    short: "PSP",       icon: "link",     group: "Payment systems" },
  e_wallet:       { label: "E-wallet",             short: "E-wallet",  icon: "wallet",   group: "Payment systems" },
  card_processor: { label: "Card acquirer",        short: "Card",      icon: "card",     group: "Payment systems" },
  cash_desk:      { label: "Cash desk",            short: "Cash",      icon: "wallet",   group: "Physical" },
};

// Quick filter groups — used by the Segmented inside the form
const KIND_FILTERS = [
  { value: "all",      label: "All",            match: () => true },
  { value: "banks",    label: "Banks",          match: k => k === "ru_bank" || k === "swift_bank" },
  { value: "crypto",   label: "Crypto",         match: k => k === "blockchain" },
  { value: "paysys",   label: "Payment systems", match: k => k === "psp" || k === "e_wallet" || k === "card_processor" },
  { value: "cash",     label: "Cash",           match: k => k === "cash_desk" },
];

// Given a holder country, which filter is most relevant?
const suggestedFilter = (country) => {
  if (country === "RU") return "banks";
  return "all";
};

// Seed provider suggestion for a new draft
const suggestProvider = (country) => {
  if (country === "RU") return PROVIDERS.find(p => p.kind === "ru_bank")?.id;
  const swift = PROVIDERS.find(p => p.kind === "swift_bank" && p.country === country);
  return swift?.id || PROVIDERS.find(p => p.kind === "swift_bank")?.id || PROVIDERS[0].id;
};

// Build a fresh draft with sensible defaults
const buildRequisiteDraft = ({ holderRef } = {}) => {
  const country = holderRef?.country;
  const providerId = suggestProvider(country);
  const provider = PROVIDERS.find(p => p.id === providerId);
  return {
    providerId,
    holderRef: holderRef || null,
    ccy: provider.ccy[0],
    nickname: "",
    primary: false,
    status: "draft",
    allowedFor: { incoming: true, outgoing: true, refunds: false, salary: false },
  };
};

window.REQUISITE_KIND_META = KIND_META;
window.buildRequisiteDraft = buildRequisiteDraft;

// ---- Helper: map party kind → icon/group used in the holder picker ----
const HOLDER_KIND_ICON = {
  organization:  "building",
  customer:      "user",
  counterparty:  "briefcase",
};

// ---- The form ---------------------------------------------------------
const RequisiteForm = ({ value, onChange, holderLock, holderOptions, compact = false }) => {
  const set = (patch) => onChange({ ...value, ...patch });
  const provider = PROVIDERS.find(p => p.id === value.providerId);
  const kind = provider?.kind;
  const kindMeta = PROVIDER_KINDS.find(k => k.value === kind);
  const countryFilter = holderLock?.country || value.holderRef?.country;
  const [providerFilter, setProviderFilter] = React.useState(() => suggestedFilter(countryFilter));

  // provider options filtered by the Segmented quick-filter
  const filterFn = KIND_FILTERS.find(f => f.value === providerFilter)?.match || (() => true);
  const providerOptions = PROVIDERS
    .filter(p => filterFn(p.kind))
    .map(p => ({
      value: p.id,
      label: p.name,
      icon: KIND_META[p.kind].icon,
      group: KIND_META[p.kind].group,
      sub: p.country !== "ANY" ? p.country : "",
      meta: p.ccy.join(" · "),
    }));

  const onProviderChange = (providerId) => {
    const p = PROVIDERS.find(x => x.id === providerId);
    // Reset currency to first one the new provider supports, drop kind-specific fields
    const {
      account, iban, walletAddress, memo, mid, walletId, walletEmail, cardMasked, deskRef,
      ...rest
    } = value;
    set({ ...rest, providerId, ccy: p.ccy[0] });
  };

  return (
    <div className="vstack" style={{ gap: 14 }}>
      {/* ---- Provider selection ------------------------------------- */}
      <div>
        <div className="req-form-label">Provider</div>
        <div className="req-form-help">
          Every requisite is attached to a provider (bank, network, PSP, or cash desk). Its type decides which fields appear below.
        </div>
        <div className="hstack" style={{ gap: 8, marginTop: 10 }}>
          <Segmented
            value={providerFilter}
            onChange={setProviderFilter}
            options={KIND_FILTERS}
          />
        </div>
        <div style={{ marginTop: 8 }}>
          <SearchSelect
            options={providerOptions}
            value={value.providerId}
            onChange={onProviderChange}
            searchPlaceholder="Search providers by name, country, or type…"
            placeholder="Select provider…"
          />
        </div>
        {provider && (
          <div className="req-provider-strip">
            <Icon name={KIND_META[kind].icon} size={12} />
            <span>{KIND_META[kind].label}</span>
            {provider.country !== "ANY" && <><span className="dot">·</span><CountryPill code={provider.country} /></>}
            <span className="dot">·</span>
            <span className="mono">{provider.ccy.join(" · ")}</span>
          </div>
        )}
      </div>

      {/* ---- Holder + currency + nickname --------------------------- */}
      <div className="field-row two">
        {holderLock ? (
          <Field label="Holder">
            <div className="holder-lock">
              <Icon name={HOLDER_KIND_ICON[holderLock.kind] || "briefcase"} size={12} />
              <span>{holderLock.name}</span>
              <CountryPill code={holderLock.country} />
            </div>
          </Field>
        ) : (
          <Field label="Holder" required hint="Who owns this requisite — customer, counterparty, or your own organization">
            <SearchSelect
              options={holderOptions || []}
              value={value.holderRef?.id || ""}
              onChange={(id) => {
                const opt = (holderOptions || []).find(o => o.value === id);
                if (!opt) return;
                set({ holderRef: { kind: opt.holderKind || "counterparty", id, name: opt.label, country: opt.sub || "" } });
              }}
              searchPlaceholder="Search parties…"
              placeholder="Select holder…"
            />
          </Field>
        )}
        <Field label="Currency" required>
          <Select value={value.ccy || ""} onChange={e => set({ ccy: e.target.value })}>
            {(provider?.ccy || ["USD"]).map(c => <option key={c} value={c}>{c}</option>)}
          </Select>
        </Field>
      </div>

      <Field label="Nickname" required hint="Short label shown in deals and balance statements">
        <Input value={value.nickname || ""} onChange={e => set({ nickname: e.target.value })} placeholder={`${kindMeta?.label || "Primary"} · ${value.ccy || ""}`} />
      </Field>

      {/* ---- Conditional fields by kind ----------------------------- */}
      <div className="req-form-section">
        <div className="req-form-section-head">
          <Icon name={KIND_META[kind]?.icon} size={12} />
          <span>Details · {KIND_META[kind]?.label || "—"}</span>
        </div>

        {kind === "ru_bank" && (
          <div className="vstack" style={{ gap: 12 }}>
            <Field label="Settlement account" required hint="20 digits · owner's account at this bank">
              <Input className="mono" value={value.account || ""} onChange={e => set({ account: e.target.value })} placeholder="40702 810 9 0000 0012345" />
            </Field>
            <div className="field-row two">
              <Field label="Account holder name (RU)" required>
                <Input value={value.accountHolderName || ""} onChange={e => set({ accountHolderName: e.target.value })} placeholder="ОАО «Северная Сталь»" />
              </Field>
              <Field label="Account type">
                <Select value={value.accountType || "settlement"} onChange={e => set({ accountType: e.target.value })}>
                  <option value="settlement">Settlement (расчётный)</option>
                  <option value="currency">Currency (валютный)</option>
                  <option value="special">Special (специальный)</option>
                </Select>
              </Field>
            </div>
            <Field label="Purpose of payment template" hint="Pre-fills назначение платежа on outgoing transfers">
              <textarea className="input textarea" rows={2} value={value.purpose || ""} onChange={e => set({ purpose: e.target.value })} placeholder="Оплата по договору №___ от ___, в т.ч. НДС 20%" />
            </Field>
            <div className="callout">
              <Icon name="info" size={12} />
              <div style={{ fontSize: 12 }}>
                BIC <span className="mono">{provider.bic}</span> · corr <span className="mono">{provider.corr}</span> · INN <span className="mono">{provider.inn}</span> · KPP <span className="mono">{provider.kpp}</span> are inherited from the provider and not editable here.
              </div>
            </div>
          </div>
        )}

        {kind === "swift_bank" && (
          <div className="vstack" style={{ gap: 12 }}>
            <div className="field-row two">
              <Field label="IBAN / Account number" required>
                <Input className="mono" value={value.iban || ""} onChange={e => set({ iban: e.target.value })}
                  placeholder={provider?.iban_prefix ? `${provider.iban_prefix} xxxx xxxx xxxx xxxx` : "IBAN or local account"} />
              </Field>
              <Field label="Account holder name (EN)" required>
                <Input value={value.accountHolderName || ""} onChange={e => set({ accountHolderName: e.target.value })} placeholder="Lotus Global FZE" />
              </Field>
            </div>
            <Field label="Beneficiary address" required hint="Required by most correspondents for SWIFT MT103">
              <Input value={value.beneficiaryAddress || ""} onChange={e => set({ beneficiaryAddress: e.target.value })} placeholder="Cluster Y, JLT, Dubai, UAE" />
            </Field>
            <div className="field-row two">
              <Field label="Charges">
                <Select value={value.charges || "OUR"} onChange={e => set({ charges: e.target.value })}>
                  <option value="OUR">OUR (sender pays)</option>
                  <option value="SHA">SHA (shared)</option>
                  <option value="BEN">BEN (beneficiary pays)</option>
                </Select>
              </Field>
              <Field label="Purpose code">
                <Select value={value.purposeCode || "GDSV"} onChange={e => set({ purposeCode: e.target.value })}>
                  <option value="GDSV">GDSV · Goods & services</option>
                  <option value="SERV">SERV · Services</option>
                  <option value="OTHR">OTHR · Other</option>
                </Select>
              </Field>
            </div>
            {provider?.intermediary && (
              <div className="callout">
                <Icon name="info" size={12} />
                <div style={{ fontSize: 12 }}>
                  USD payments will route via intermediary <b>{provider.intermediary}</b>. SWIFT <span className="mono">{provider.swift}</span> inherited.
                </div>
              </div>
            )}
          </div>
        )}

        {kind === "blockchain" && (
          <div className="vstack" style={{ gap: 12 }}>
            <Field label="Wallet address" required hint={`${provider.network} · validated on save`}>
              <Input className="mono" value={value.walletAddress || ""} onChange={e => set({ walletAddress: e.target.value })}
                placeholder={provider.network === "TRC-20" ? "T…" : provider.network === "ERC-20" ? "0x…" : "address"} />
            </Field>
            {(provider.network === "TON" || provider.network === "XRP") && (
              <Field label="Memo / tag" required>
                <Input value={value.memo || ""} onChange={e => set({ memo: e.target.value })} />
              </Field>
            )}
            <div className="field-row two">
              <Field label="Network (inherited)">
                <Input value={provider.network} disabled />
              </Field>
              <Field label="Min. confirmations (inherited)">
                <Input value={provider.confirmations} disabled />
              </Field>
            </div>
          </div>
        )}

        {kind === "psp" && (
          <div className="field-row two">
            <Field label="Merchant account" required>
              <Input value={value.mid || ""} onChange={e => set({ mid: e.target.value })} placeholder="acc_abc123" />
            </Field>
            <Field label="Settlement schedule">
              <Select value={value.settlement || "T+2"} onChange={e => set({ settlement: e.target.value })}>
                <option>T+2 daily</option><option>T+1 daily</option><option>Weekly</option>
              </Select>
            </Field>
          </div>
        )}

        {kind === "e_wallet" && (
          <div className="field-row two">
            <Field label="Wallet ID / account" required>
              <Input value={value.walletId || ""} onChange={e => set({ walletId: e.target.value })} placeholder="P1234567" />
            </Field>
            <Field label="Holder email" required>
              <Input type="email" value={value.walletEmail || ""} onChange={e => set({ walletEmail: e.target.value })} />
            </Field>
          </div>
        )}

        {kind === "card_processor" && (
          <div className="vstack" style={{ gap: 12 }}>
            <Field label="Card number (masked)" required hint="We only store last 4 digits">
              <Input className="mono" value={value.cardMasked || ""} onChange={e => set({ cardMasked: e.target.value })} placeholder="4012 •••• •••• 1234" />
            </Field>
            <div className="field-row two">
              <Field label="Holder">
                <Input value={value.accountHolderName || ""} onChange={e => set({ accountHolderName: e.target.value })} />
              </Field>
              <Field label="Expiry">
                <Input value={value.expiry || ""} onChange={e => set({ expiry: e.target.value })} placeholder="MM/YY" />
              </Field>
            </div>
          </div>
        )}

        {kind === "cash_desk" && (
          <div className="vstack" style={{ gap: 12 }}>
            <Field label="Desk reference">
              <Input value={value.deskRef || ""} onChange={e => set({ deskRef: e.target.value })} placeholder="e.g. Dubai-JLT-02" />
            </Field>
            <div className="callout">
              <Icon name="info" size={12} />
              <div style={{ fontSize: 12 }}>
                Cash pickups require only the desk reference and recipient ID check. No account numbers apply.
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ---- Usage flags -------------------------------------------- */}
      <div className="req-form-section">
        <div className="req-form-section-head">
          <Icon name="shield" size={12} />
          <span>Usage</span>
        </div>
        <label className="hstack" style={{ gap: 10, cursor: "pointer", marginBottom: 10 }}>
          <Checkbox checked={!!value.primary} onChange={v => set({ primary: v })} />
          <span style={{ fontSize: 13 }}>Mark as primary requisite for this holder in <span className="mono">{value.ccy || "—"}</span></span>
        </label>
        <div className="hstack" style={{ gap: 14, flexWrap: "wrap", fontSize: 12.5 }}>
          {[
            ["incoming", "Incoming payments"],
            ["outgoing", "Outgoing payments"],
            ["refunds",  "Refunds"],
            ["salary",   "Salary payouts"],
          ].map(([k, label]) => (
            <label key={k} className="hstack" style={{ gap: 6, cursor: "pointer" }}>
              <Checkbox checked={!!(value.allowedFor && value.allowedFor[k])} onChange={v => set({ allowedFor: { ...(value.allowedFor || {}), [k]: v } })} />
              <span>{label}</span>
            </label>
          ))}
        </div>
      </div>

      {!compact && (
        <div className="callout">
          <Icon name="info" size={12} />
          <div style={{ fontSize: 12 }}>
            New requisites start as <b>pending</b>. Treasury verifies by sending a 1.00 test transfer before enabling for live deals.
          </div>
        </div>
      )}
    </div>
  );
};

// ---- Preview panel (used by Finance full-page only) ------------------
const RequisitePreview = ({ value }) => {
  const provider = PROVIDERS.find(p => p.id === value.providerId);
  const kind = provider?.kind;
  return (
    <div className="requisite-preview">
      <div className="eyebrow">As shown in documents</div>
      {kind === "ru_bank" && (
        <div className="mono" style={{ fontSize: 12, lineHeight: 1.6 }}>
          <div>Банк: {provider.name}</div>
          <div>БИК: {provider.bic}</div>
          <div>Корр./сч.: {provider.corr}</div>
          <div>Р/с: {value.account || "—"}</div>
          <div>ИНН: {provider.inn} · КПП: {provider.kpp}</div>
          <div>Получатель: {value.accountHolderName || value.holderRef?.name || "—"}</div>
        </div>
      )}
      {kind === "swift_bank" && (
        <div className="mono" style={{ fontSize: 12, lineHeight: 1.6 }}>
          <div>Bank: {provider.name}</div>
          <div>SWIFT/BIC: {provider.swift}</div>
          <div>IBAN: {value.iban || "—"}</div>
          <div>Beneficiary: {value.accountHolderName || value.holderRef?.name || "—"}</div>
          <div>Address: {value.beneficiaryAddress || "—"}</div>
          {provider.intermediary && <div style={{ color: "var(--text-muted)" }}>via {provider.intermediary}</div>}
        </div>
      )}
      {kind === "blockchain" && (
        <div className="mono" style={{ fontSize: 12, lineHeight: 1.6 }}>
          <div>Network: {provider.network}</div>
          <div style={{ wordBreak: "break-all" }}>Address: {value.walletAddress || "—"}</div>
          {value.memo && <div>Memo: {value.memo}</div>}
        </div>
      )}
      {kind === "cash_desk" && (
        <div className="mono" style={{ fontSize: 12, lineHeight: 1.6 }}>
          <div>Desk: {provider.name}</div>
          <div>Ref: {value.deskRef || "—"}</div>
          <div style={{ color: "var(--text-muted)" }}>{provider.address}</div>
        </div>
      )}
      {(kind === "psp" || kind === "e_wallet" || kind === "card_processor") && (
        <div className="mono" style={{ fontSize: 12, lineHeight: 1.6, color: "var(--text-muted)" }}>
          Preview renders once required fields are filled.
        </div>
      )}
    </div>
  );
};

window.RequisiteForm = RequisiteForm;
window.RequisitePreview = RequisitePreview;
