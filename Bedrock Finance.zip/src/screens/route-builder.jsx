/* global React, Icon, Btn, IconBtn, Badge, Card, cx, Field, Input, Select, Segmented, Switch, Checkbox, Money, Num */
const { useState, useMemo } = React;
const { PROVIDERS, FEE_BASES, LEG_TYPES, ROUTE_TEMPLATES } = window.BEDROCK_DATA;

/* ---- Cost model ----
   A route has:
   - PARTICIPANTS: customer, acting legal entity, Bedrock org(s), beneficiary, sub-agents
   - LEGS: collect / fx / transfer / payout — each carries money between participants
   - COST COMPONENTS: line items on legs OR at route level, classified as
       · "charged"  — added to the price the customer pays
       · "internal" — Bedrock's own cost (eats into margin)
       · "commission" — paid to a sub-agent
   - OUTPUTS:
       · Client pays    = gross + sum(charged fees) + client markup
       · Cost to Bedrock= sum(internal fees) + provider fees we absorb
       · Clean amount   = what beneficiary actually receives
       · Net margin     = client pays − cost − clean amount
------------------- */

const calcLegFee = (fee, grossUsd) => {
  const v = fee?.value || 0;
  if (fee?.base === "gross_pct" || fee?.base === "net_pct") return grossUsd * (v / 100);
  if (fee?.base === "spread_bps") return grossUsd * (v / 10000);
  if (fee?.base === "fixed_ccy") return v;
  if (fee?.base === "tier") return grossUsd * 0.002;
  return 0;
};

const legTypeIcon = (t) => ({
  collect: "download", fx: "exchange", transfer: "arrow_right", payout: "upload",
}[t] || "route");

const legTypeTone = (t) => ({
  collect: "info", fx: "warn", transfer: "default", payout: "pos",
}[t] || "default");

const legTypeDesc = (t) => ({
  collect: "Customer pays into Bedrock account",
  fx: "Convert between currencies",
  transfer: "Move money between Bedrock accounts",
  payout: "Send to beneficiary's account",
}[t] || "");

/* ============================================================
   How-this-works banner (dismissible)
============================================================ */
const HelpBanner = ({ onDismiss }) => (
  <div className="route-help">
    <div className="route-help-icon"><Icon name="route" size={18} /></div>
    <div className="route-help-body">
      <div className="route-help-title">How a payment route works</div>
      <div className="route-help-steps">
        <span><b>1</b> Bind participants (who pays, who receives, which of our orgs handle it)</span>
        <Icon name="arrow_right" size={12} />
        <span><b>2</b> Sequence the money legs (collect → FX → transfer → payout)</span>
        <Icon name="arrow_right" size={12} />
        <span><b>3</b> Price each leg and add route-level fees</span>
      </div>
      <div className="route-help-foot">
        Save as a reusable <b>template</b> for similar deals, or use it directly on deal <span className="mono">DL-4401</span>.
        An <b>accepted calculation</b> freezes this into a commercial promise.
      </div>
    </div>
    <IconBtn name="x" onClick={onDismiss} title="Dismiss" />
  </div>
);

/* ============================================================
   Participant row (customer / org / beneficiary / sub-agent)
============================================================ */
const PARTICIPANTS = [
  { role: "customer",    label: "Customer",            name: "Nordmax Trading LLC",      kind: "Russian legal entity",  req: "REQ-5013", reqLabel: "VTB · RUB", reqOk: true,  badge: "Commercial root" },
  { role: "acting",      label: "Acting legal entity", name: "Nordmax-RU Holding",       kind: "Counterparty · linked to customer", req: "REQ-5013", reqLabel: "VTB · RUB", reqOk: true },
  { role: "org_out",     label: "Our org — collection", name: "Bedrock RU",              kind: "Internal organization", req: "REQ-2201", reqLabel: "Raiffeisen · RUB",  reqOk: true },
  { role: "org_in",      label: "Our org — payout",     name: "Bedrock AE",              kind: "Internal organization", req: "REQ-2250", reqLabel: "Emirates NBD · USD", reqOk: true },
  { role: "beneficiary", label: "Beneficiary",          name: "Lotus Global FZE",        kind: "External counterparty", req: "REQ-5012", reqLabel: "Emirates NBD · IBAN · USD", reqOk: true,  badge: "Payout target" },
  { role: "sub_agent",   label: "Sub-agent (optional)", name: "— None —",                kind: "Would earn commission", req: null,       reqLabel: null, reqOk: null },
];

/* ============================================================
   Route Builder
============================================================ */
const RouteBuilderScreen = ({ routeId = "RT-081", onBack }) => {
  const base = ROUTE_TEMPLATES.find(r => r.id === routeId) || ROUTE_TEMPLATES[0];

  const [mode, setMode] = useState("template"); // "template" | "deal-draft"
  const [helpOpen, setHelpOpen] = useState(true);
  const [name, setName] = useState(base.name);
  const [legs, setLegs] = useState(base.legs);
  const [selectedLegIdx, setSelectedLegIdx] = useState(0);

  // Route-level cost components (beyond per-leg fees)
  const [routeFees, setRouteFees] = useState([
    { id: "rf-1", label: "Client markup",        kind: "charged",   base: "gross_pct", value: 0.20, note: "On top of all costs, kept by Bedrock" },
    { id: "rf-2", label: "SWIFT cable fee",      kind: "charged",   base: "fixed_ccy", value: 35,   ccy: "USD", note: "Passed through to customer" },
    { id: "rf-3", label: "Liquidity cost",       kind: "internal",  base: "gross_pct", value: 0.08, note: "Our treasury carry — eats margin" },
  ]);

  const [sampleAmount, setSampleAmount] = useState(142_000);
  const [status, setStatus] = useState(base.status);

  const setLeg = (idx, patch) => setLegs(legs.map((l, i) => i === idx ? { ...l, ...patch } : l));
  const setLegFee = (idx, patch) => setLegs(legs.map((l, i) => i === idx ? { ...l, fee: { ...l.fee, ...patch } } : l));
  const addLeg = () => setLegs([...legs, { n: legs.length + 1, type: "transfer", from: "Bedrock", to: "Bedrock", ccy: "USD", provider: "PRV-004", fee: { base: "gross_pct", value: 0.25 } }]);
  const removeLeg = (idx) => {
    setLegs(legs.filter((_, i) => i !== idx).map((l, i) => ({ ...l, n: i + 1 })));
    setSelectedLegIdx(Math.max(0, selectedLegIdx - 1));
  };
  const moveLeg = (idx, dir) => {
    const next = [...legs];
    const j = idx + dir;
    if (j < 0 || j >= next.length) return;
    [next[idx], next[j]] = [next[j], next[idx]];
    setLegs(next.map((l, i) => ({ ...l, n: i + 1 })));
    setSelectedLegIdx(j);
  };
  const addRouteFee = (kind) => {
    setRouteFees([...routeFees, { id: `rf-${Date.now()}`, label: kind === "internal" ? "New internal cost" : "New charged fee", kind, base: "gross_pct", value: 0.1, note: "" }]);
  };
  const setRouteFee = (id, patch) => setRouteFees(routeFees.map(f => f.id === id ? { ...f, ...patch } : f));
  const removeRouteFee = (id) => setRouteFees(routeFees.filter(f => f.id !== id));

  // Economics
  const legFees = useMemo(() => legs.map(l => calcLegFee(l.fee, sampleAmount)), [legs, sampleAmount]);
  const chargedFees = useMemo(() => routeFees.filter(f => f.kind === "charged").map(f => ({ ...f, amt: calcLegFee(f, sampleAmount) })), [routeFees, sampleAmount]);
  const internalFees = useMemo(() => routeFees.filter(f => f.kind === "internal").map(f => ({ ...f, amt: calcLegFee(f, sampleAmount) })), [routeFees, sampleAmount]);

  const legFeeTotal = legFees.reduce((a, b) => a + b, 0);
  const chargedTotal = chargedFees.reduce((a, b) => a + b.amt, 0);
  const internalTotal = internalFees.reduce((a, b) => a + b.amt, 0);

  const clientPays = sampleAmount + chargedTotal;
  const costToBedrock = internalTotal + legFeeTotal;
  const cleanOut = sampleAmount - legFeeTotal; // what reaches the beneficiary
  const netMargin = clientPays - costToBedrock - cleanOut;
  const effectiveBps = (netMargin / sampleAmount) * 10000;

  // Validation
  const checks = useMemo(() => {
    const results = [];
    results.push({ ok: legs.every(l => l.provider), label: "Every leg has a provider" });
    // currency continuity
    let ok = true;
    for (let i = 0; i < legs.length - 1; i++) {
      const a = legs[i].ccy.split("→").pop();
      const b = legs[i + 1].ccy.split("→")[0];
      if (a !== b) { ok = false; break; }
    }
    results.push({ ok, label: "Currencies connect between legs" });
    results.push({ ok: PARTICIPANTS.filter(p => p.req).every(p => p.reqOk), label: "All bound participants have valid requisites" });
    results.push({ ok: effectiveBps >= 15 && effectiveBps <= 200, label: `Margin within policy (15 ≤ ${effectiveBps.toFixed(0)} ≤ 200 bps)`, warn: effectiveBps < 15 || effectiveBps > 200 });
    return results;
  }, [legs, effectiveBps]);

  const sel = legs[selectedLegIdx] || legs[0];
  const selProvider = PROVIDERS.find(p => p.id === sel?.provider);

  /* ----------------- Tabs for the main pane ----------------- */
  const [tab, setTab] = useState("flow");

  return (
    <>
      <div className="detail-header">
        <div className="detail-header-left">
          <span className="avatar lg muted"><Icon name="route" size={18} /></span>
          <div>
            <h1 className="detail-title">
              {name}
              <Badge tone={status === "live" ? "pos" : "warn"} dot>{status}</Badge>
            </h1>
            <div className="detail-id">
              <span className="mono">{routeId}</span><span>·</span>
              <span>v3 (draft)</span><span>·</span>
              <span>{legs.length} legs</span><span>·</span>
              <span>{routeFees.length} route-level costs</span><span>·</span>
              <span>{base.uses} deals have used v2</span>
            </div>
          </div>
        </div>
        <div className="page-head-actions">
          <Btn variant="ghost" onClick={onBack}>Cancel</Btn>
          <Btn variant="secondary" icon="copy">Duplicate</Btn>
          <Btn variant="secondary" icon="file">Save as template</Btn>
          <Btn variant="primary" icon="check">Accept &amp; use on DL-4401</Btn>
        </div>
      </div>

      {/* Mode strip */}
      <div className="route-mode-strip">
        <Segmented value={mode} onChange={setMode} options={[
          { value: "template",   label: "Template (reusable)" },
          { value: "deal-draft", label: "Draft for deal DL-4401" },
        ]} />
        <div className="route-mode-hint">
          {mode === "template"
            ? "Saves as a reusable shape. Deals pick it up and may override individual legs."
            : "Attached to one deal. Accepting will freeze a calculation snapshot as the commercial promise."}
        </div>
      </div>

      {helpOpen && <HelpBanner onDismiss={() => setHelpOpen(false)} />}

      {/* Progress stepper */}
      <div className="route-stepper">
        <button type="button" className={cx("route-step", tab === "participants" && "active", "done")} onClick={() => setTab("participants")}>
          <span className="route-step-num">1</span>
          <div>
            <div className="route-step-title">Participants</div>
            <div className="route-step-sub">{PARTICIPANTS.filter(p => p.name !== "— None —").length} bound · all requisites OK</div>
          </div>
          <Icon name="check" size={14} />
        </button>
        <div className="route-step-sep" />
        <button type="button" className={cx("route-step", tab === "flow" && "active", "done")} onClick={() => setTab("flow")}>
          <span className="route-step-num">2</span>
          <div>
            <div className="route-step-title">Money legs</div>
            <div className="route-step-sub">{legs.length} legs · RUB → USD → USD → USD</div>
          </div>
          <Icon name="check" size={14} />
        </button>
        <div className="route-step-sep" />
        <button type="button" className={cx("route-step", tab === "costs" && "active", "done")} onClick={() => setTab("costs")}>
          <span className="route-step-num">3</span>
          <div>
            <div className="route-step-title">Cost &amp; pricing</div>
            <div className="route-step-sub">{routeFees.length + legs.length} line items · {effectiveBps.toFixed(0)} bps margin</div>
          </div>
          <Icon name="check" size={14} />
        </button>
      </div>

      <div className="route-layout">
        {/* MAIN */}
        <div className="route-main-pane">
          {tab === "participants" && (
            <Card title="Who's involved" sub="Roles the money moves between — each needs a valid requisite before you can execute">
              <div className="participants-list">
                {PARTICIPANTS.map(p => (
                  <div key={p.role} className="participant-row">
                    <div className="participant-role">
                      <div className="eyebrow">{p.label}</div>
                      {p.badge && <Badge tone="info" outline>{p.badge}</Badge>}
                    </div>
                    <div className="participant-body">
                      <div className="participant-name">{p.name}</div>
                      <div className="participant-kind">{p.kind}</div>
                    </div>
                    <div className="participant-req">
                      {p.req ? (
                        <>
                          <div className="hstack" style={{ gap: 6 }}>
                            <Icon name={p.reqOk ? "check" : "info"} size={13} style={{ color: p.reqOk ? "var(--pos)" : "var(--warn)" }} />
                            <span style={{ fontSize: 12.5, fontWeight: 500 }}>{p.reqLabel}</span>
                          </div>
                          <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>{p.req}</div>
                        </>
                      ) : (
                        <div style={{ fontSize: 12, color: "var(--text-faint)" }}>—</div>
                      )}
                    </div>
                    <div className="hstack" style={{ gap: 4 }}>
                      <Btn variant="ghost" size="sm" icon="edit">Change</Btn>
                    </div>
                  </div>
                ))}
              </div>
              <div className="hstack" style={{ marginTop: 14, justifyContent: "flex-end" }}>
                <Btn variant="ghost" size="sm" icon="plus">Add sub-agent</Btn>
                <Btn variant="ghost" size="sm" icon="plus">Add co-signer</Btn>
              </div>
            </Card>
          )}

          {tab === "flow" && (
            <>
              <Card title="Money flow" sub="Each leg moves money between two participants. Click a leg to configure it." flush>
                <div className="route-flow-v2">
                  {legs.map((leg, i) => {
                    const prov = PROVIDERS.find(p => p.id === leg.provider);
                    const isSel = i === selectedLegIdx;
                    const [ccyFrom, ccyTo] = leg.ccy.includes("→") ? leg.ccy.split("→") : [leg.ccy, leg.ccy];
                    return (
                      <React.Fragment key={i}>
                        <div className={cx("route-leg-v2", isSel && "selected")} onClick={() => setSelectedLegIdx(i)}>
                          <div className="route-leg-v2-rail">
                            <div className="route-leg-v2-n mono">LEG {leg.n}</div>
                            <Badge tone={legTypeTone(leg.type)} dot>
                              <Icon name={legTypeIcon(leg.type)} size={11} /> {LEG_TYPES.find(x => x.value === leg.type)?.label}
                            </Badge>
                          </div>
                          <div className="route-leg-v2-body">
                            <div className="route-leg-v2-flow">
                              <div className="route-leg-v2-party">
                                <div className="eyebrow">From</div>
                                <div className="route-leg-v2-name">{leg.from}</div>
                              </div>
                              <div className="route-leg-v2-arrow">
                                <div className="route-leg-v2-arrow-line" />
                                <div className="route-leg-v2-arrow-badge mono">{ccyFrom}{ccyFrom !== ccyTo ? ` → ${ccyTo}` : ""}</div>
                                <Icon name="arrow_right" size={14} />
                              </div>
                              <div className="route-leg-v2-party">
                                <div className="eyebrow">To</div>
                                <div className="route-leg-v2-name">{leg.to}</div>
                              </div>
                            </div>
                            <div className="route-leg-v2-meta">
                              <div className="route-leg-v2-chip">
                                <Icon name="building" size={11} />
                                {prov?.name}
                              </div>
                              <div className="route-leg-v2-chip">
                                <Icon name="dollar" size={11} />
                                {leg.fee.base === "gross_pct" && `${leg.fee.value}% of gross`}
                                {leg.fee.base === "spread_bps" && `${leg.fee.value} bps spread`}
                                {leg.fee.base === "fixed_ccy" && `${leg.fee.value} ${leg.fee.ccy || "USD"} fixed`}
                                <span className="mono" style={{ marginLeft: 6, color: "var(--text)" }}>
                                  = <Money value={legFees[i]} ccy="USD" muteUnit />
                                </span>
                              </div>
                              <div className="route-leg-v2-chip ghost">
                                <Icon name="clock" size={11} />
                                Same business day
                              </div>
                            </div>
                          </div>
                          <div className="route-leg-v2-actions">
                            <button className="icon-btn" onClick={e => { e.stopPropagation(); moveLeg(i, -1); }} title="Move up"><Icon name="chev_up" size={12} /></button>
                            <button className="icon-btn" onClick={e => { e.stopPropagation(); moveLeg(i, 1); }} title="Move down"><Icon name="chev_down" size={12} /></button>
                            <button className="icon-btn danger" onClick={e => { e.stopPropagation(); removeLeg(i); }} title="Remove"><Icon name="trash" size={12} /></button>
                          </div>
                        </div>
                        {i < legs.length - 1 && <div className="route-flow-v2-connector" />}
                      </React.Fragment>
                    );
                  })}
                  <button className="route-flow-v2-add" onClick={addLeg}>
                    <Icon name="plus" size={14} /> Add leg
                  </button>
                </div>
              </Card>

              {/* Inline editor for selected leg */}
              <Card
                title={<>
                  <span className="mono" style={{ fontSize: 11, color: "var(--text-faint)", marginRight: 8 }}>LEG {sel?.n}</span>
                  Configure · {LEG_TYPES.find(x => x.value === sel?.type)?.label}
                </>}
                sub={legTypeDesc(sel?.type)}>
                {sel && (
                  <div className="vstack" style={{ gap: 14 }}>
                    <Field label="Leg type" required>
                      <div className="segmented" style={{ width: "100%" }}>
                        {LEG_TYPES.map(t => (
                          <button key={t.value} type="button"
                            className={cx("segmented-item", sel.type === t.value && "active")}
                            onClick={() => setLeg(selectedLegIdx, { type: t.value })}>
                            <Icon name={legTypeIcon(t.value)} size={12} /> {t.label}
                          </button>
                        ))}
                      </div>
                    </Field>
                    <div className="field-row two">
                      <Field label="From (sender)" required>
                        <Input value={sel.from} onChange={e => setLeg(selectedLegIdx, { from: e.target.value })} />
                      </Field>
                      <Field label="To (receiver)" required>
                        <Input value={sel.to} onChange={e => setLeg(selectedLegIdx, { to: e.target.value })} />
                      </Field>
                    </div>
                    <div className="field-row two">
                      <Field label="Currency" required hint={sel.type === "fx" ? "Use format RUB→USD for FX" : "ISO code"}>
                        <Input value={sel.ccy} onChange={e => setLeg(selectedLegIdx, { ccy: e.target.value })} />
                      </Field>
                      <Field label="Provider" required>
                        <Select value={sel.provider} onChange={e => setLeg(selectedLegIdx, { provider: e.target.value })}>
                          {PROVIDERS.map(p => <option key={p.id} value={p.id}>{p.name} · {p.kind}</option>)}
                        </Select>
                      </Field>
                    </div>
                    <div className="divider" />
                    <div className="field-row two">
                      <Field label="Provider fee basis" required>
                        <Select value={sel.fee.base} onChange={e => setLegFee(selectedLegIdx, { base: e.target.value })}>
                          {FEE_BASES.map(f => <option key={f.value} value={f.value}>{f.label}</option>)}
                        </Select>
                      </Field>
                      <Field label="Fee value" required>
                        <Input type="number" step="0.01" value={sel.fee.value}
                          onChange={e => setLegFee(selectedLegIdx, { value: +e.target.value })}
                          suffix={sel.fee.base === "gross_pct" ? "%" : sel.fee.base === "spread_bps" ? "bps" : sel.fee.ccy || "USD"} />
                      </Field>
                    </div>
                    <div className="callout">
                      <Icon name="info" size={14} />
                      <div style={{ fontSize: 12 }}>
                        On a <Money value={sampleAmount} ccy="USD" muteUnit /> deal this leg costs <b><Money value={legFees[selectedLegIdx]} ccy="USD" muteUnit /></b>.
                        Provider fees are <b>internal</b> (Bedrock absorbs them) unless you move this line into "Charged to customer".
                      </div>
                    </div>
                  </div>
                )}
              </Card>
            </>
          )}

          {tab === "costs" && (
            <>
              <Card title="Cost components · Route-level"
                    sub="Line items on top of provider fees. Classify each as charged-to-customer, internal (Bedrock's cost), or sub-agent commission.">
                <div className="cost-groups">
                  <div className="cost-group">
                    <div className="cost-group-head">
                      <div className="hstack">
                        <Badge tone="pos" outline dot>Charged to customer</Badge>
                        <span style={{ color: "var(--text-muted)", fontSize: 12 }}>Added to the price</span>
                      </div>
                      <Btn variant="ghost" size="sm" icon="plus" onClick={() => addRouteFee("charged")}>Add</Btn>
                    </div>
                    {chargedFees.length === 0 && <div className="cost-group-empty">No charged fees yet</div>}
                    {chargedFees.map(f => (
                      <div key={f.id} className="cost-row">
                        <Input value={f.label} onChange={e => setRouteFee(f.id, { label: e.target.value })} />
                        <Select value={f.base} onChange={e => setRouteFee(f.id, { base: e.target.value })}>
                          {FEE_BASES.map(x => <option key={x.value} value={x.value}>{x.label}</option>)}
                        </Select>
                        <Input type="number" value={f.value} onChange={e => setRouteFee(f.id, { value: +e.target.value })}
                               suffix={f.base === "gross_pct" ? "%" : f.base === "spread_bps" ? "bps" : (f.ccy || "USD")} />
                        <div className="cost-row-amt mono"><Money value={f.amt} ccy="USD" muteUnit /></div>
                        <IconBtn name="trash" onClick={() => removeRouteFee(f.id)} />
                      </div>
                    ))}
                  </div>

                  <div className="cost-group">
                    <div className="cost-group-head">
                      <div className="hstack">
                        <Badge tone="warn" outline dot>Internal (Bedrock absorbs)</Badge>
                        <span style={{ color: "var(--text-muted)", fontSize: 12 }}>Eats into margin</span>
                      </div>
                      <Btn variant="ghost" size="sm" icon="plus" onClick={() => addRouteFee("internal")}>Add</Btn>
                    </div>
                    {internalFees.length === 0 && <div className="cost-group-empty">No internal costs yet</div>}
                    {internalFees.map(f => (
                      <div key={f.id} className="cost-row">
                        <Input value={f.label} onChange={e => setRouteFee(f.id, { label: e.target.value })} />
                        <Select value={f.base} onChange={e => setRouteFee(f.id, { base: e.target.value })}>
                          {FEE_BASES.map(x => <option key={x.value} value={x.value}>{x.label}</option>)}
                        </Select>
                        <Input type="number" value={f.value} onChange={e => setRouteFee(f.id, { value: +e.target.value })}
                               suffix={f.base === "gross_pct" ? "%" : f.base === "spread_bps" ? "bps" : (f.ccy || "USD")} />
                        <div className="cost-row-amt mono"><Money value={f.amt} ccy="USD" muteUnit /></div>
                        <IconBtn name="trash" onClick={() => removeRouteFee(f.id)} />
                      </div>
                    ))}
                  </div>
                </div>
              </Card>

              <Card title="Per-leg provider fees" sub="Read-only here — edit on the Money flow tab">
                <div className="vstack" style={{ gap: 0 }}>
                  <div className="cost-row header">
                    <div>Leg</div><div>Type</div><div>Basis</div><div style={{ textAlign: "right" }}>Amount</div><div />
                  </div>
                  {legs.map((l, i) => (
                    <div key={i} className="cost-row readonly">
                      <div className="hstack" style={{ gap: 8 }}>
                        <span className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>L{l.n}</span>
                        <span style={{ fontSize: 12.5 }}>{LEG_TYPES.find(t => t.value === l.type)?.label}</span>
                      </div>
                      <div style={{ fontSize: 12 }}>{PROVIDERS.find(p => p.id === l.provider)?.name}</div>
                      <div style={{ fontSize: 12 }}>{FEE_BASES.find(b => b.value === l.fee.base)?.label} · {l.fee.value}</div>
                      <div className="cost-row-amt mono"><Money value={legFees[i]} ccy="USD" muteUnit /></div>
                      <div />
                    </div>
                  ))}
                </div>
              </Card>
            </>
          )}

          {/* Metadata always available */}
          <Card title="Route metadata">
            <div className="field-row two">
              <Field label="Name" required>
                <Input value={name} onChange={e => setName(e.target.value)} />
              </Field>
              <Field label="Status">
                <Select value={status} onChange={e => setStatus(e.target.value)}>
                  <option value="live">Live</option>
                  <option value="draft">Draft</option>
                  <option value="archived">Archived</option>
                </Select>
              </Field>
            </div>
            <div className="field-row three" style={{ marginTop: 12 }}>
              <Field label="Corridor">
                <Select defaultValue="ru-ae"><option value="ru-ae">RU → AE</option><option>EU → RU</option><option>SG → AE</option></Select>
              </Field>
              <Field label="Settlement target" hint="Typical end-to-end time">
                <Input defaultValue="T+1" />
              </Field>
              <Field label="Internal notes">
                <Input defaultValue="Primary route for Nordmax-style trades" />
              </Field>
            </div>
          </Card>
        </div>

        {/* SIDE: sticky economics rail */}
        <aside className="route-side-pane">
          <Card title="Live economics" sub="Recalculates on every edit">
            <Field label="Sample gross amount">
              <Input type="number" value={sampleAmount} onChange={e => setSampleAmount(+e.target.value || 0)} suffix="USD" />
            </Field>

            <div className="divider" />

            <div className="econ-block">
              <div className="econ-row big">
                <div>
                  <div className="econ-label">Client pays</div>
                  <div className="econ-sub">Gross + charged fees</div>
                </div>
                <div className="mono econ-value"><Money value={clientPays} ccy="USD" muteUnit /></div>
              </div>
              {chargedFees.map(f => (
                <div key={f.id} className="econ-row sub">
                  <span>+ {f.label}</span>
                  <span className="mono"><Money value={f.amt} ccy="USD" muteUnit /></span>
                </div>
              ))}
            </div>

            <div className="divider" />

            <div className="econ-block">
              <div className="econ-row big neg">
                <div>
                  <div className="econ-label">Cost to Bedrock</div>
                  <div className="econ-sub">Provider fees + internal costs</div>
                </div>
                <div className="mono econ-value"><Money value={-costToBedrock} ccy="USD" signed signColor muteUnit /></div>
              </div>
              <div className="econ-row sub">
                <span>− Leg provider fees ({legs.length})</span>
                <span className="mono"><Money value={legFeeTotal} ccy="USD" muteUnit /></span>
              </div>
              {internalFees.map(f => (
                <div key={f.id} className="econ-row sub">
                  <span>− {f.label}</span>
                  <span className="mono"><Money value={f.amt} ccy="USD" muteUnit /></span>
                </div>
              ))}
            </div>

            <div className="divider" />

            <div className="econ-block">
              <div className="econ-row big">
                <div>
                  <div className="econ-label">Beneficiary receives</div>
                  <div className="econ-sub">Clean amount out</div>
                </div>
                <div className="mono econ-value"><Money value={cleanOut} ccy="USD" muteUnit /></div>
              </div>
            </div>

            <div className="econ-margin">
              <div>
                <div className="econ-label" style={{ color: "var(--pos)" }}>Net margin</div>
                <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>{effectiveBps.toFixed(1)} bps of gross</div>
              </div>
              <div className="mono econ-margin-value"><Money value={netMargin} ccy="USD" muteUnit /></div>
            </div>
          </Card>

          <Card title="Validation">
            <div className="vstack" style={{ gap: 8, fontSize: 12.5 }}>
              {checks.map((c, i) => (
                <div key={i} className="hstack" style={{ gap: 8 }}>
                  {c.ok
                    ? <span className="check-dot ok"><Icon name="check" size={10} /></span>
                    : <span className={cx("check-dot", c.warn ? "warn" : "neg")}>!</span>}
                  <span style={{ flex: 1 }}>{c.label}</span>
                </div>
              ))}
            </div>
          </Card>

          <Card title="Version &amp; provenance">
            <div className="vstack" style={{ gap: 8, fontSize: 12 }}>
              <div className="hstack" style={{ justifyContent: "space-between" }}>
                <span style={{ color: "var(--text-muted)" }}>Current version</span>
                <span className="mono">v3 · draft</span>
              </div>
              <div className="hstack" style={{ justifyContent: "space-between" }}>
                <span style={{ color: "var(--text-muted)" }}>Last accepted</span>
                <span className="mono">v2 · Mar 14</span>
              </div>
              <div className="hstack" style={{ justifyContent: "space-between" }}>
                <span style={{ color: "var(--text-muted)" }}>Deals on v2</span>
                <span className="mono">312</span>
              </div>
              <div className="divider" />
              <Btn variant="ghost" size="sm" icon="file" className="btn-block">View change diff vs v2</Btn>
            </div>
          </Card>
        </aside>
      </div>
    </>
  );
};

window.RouteBuilderScreen = RouteBuilderScreen;
