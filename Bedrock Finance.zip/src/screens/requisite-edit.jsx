/* global React, Icon, Btn, Badge, Card, CardSaveFoot, RequisiteForm, RequisitePreview, buildRequisiteDraft */
const { useState } = React;
const { PROVIDERS, REQUISITES } = window.BEDROCK_DATA;

// Holder options for the full-page editor — pull from all known parties.
// In the CRM tab this is locked to the enclosing counterparty.
const holderOptionsAll = () => {
  const { CUSTOMERS, COUNTERPARTIES } = window.BEDROCK_DATA;
  const orgs = [
    { value: "ORG-AE", label: "Bedrock AE Holding", holderKind: "organization", group: "Organizations", icon: "building", sub: "AE" },
    { value: "ORG-RU", label: "Bedrock RU Invest",  holderKind: "organization", group: "Organizations", icon: "building", sub: "RU" },
    { value: "ORG-EU", label: "Bedrock EU GmbH",    holderKind: "organization", group: "Organizations", icon: "building", sub: "DE" },
    { value: "ORG-SG", label: "Bedrock SG Pte",     holderKind: "organization", group: "Organizations", icon: "building", sub: "SG" },
  ];
  const cus = CUSTOMERS.map(c => ({
    value: c.id, label: c.en || c.base, holderKind: "customer", group: "Customers", icon: "user", sub: c.country,
  }));
  const cps = COUNTERPARTIES.map(c => ({
    value: c.id, label: c.en || c.base, holderKind: "counterparty", group: "Counterparties", icon: "briefcase", sub: c.country,
  }));
  return [...orgs, ...cus, ...cps];
};

const RequisiteEditorScreen = ({ requisiteId, onBack }) => {
  const existing = REQUISITES.find(r => r.id === requisiteId);
  const [draft, setDraft] = useState(() => existing ? { ...existing } : buildRequisiteDraft({
    holderRef: { kind: "organization", id: "ORG-AE", name: "Bedrock AE Holding", country: "AE" },
  }));
  const [dirty, setDirty] = useState(false);

  const update = (next) => { setDraft(next); setDirty(true); };

  const provider = PROVIDERS.find(p => p.id === draft.providerId);
  const holderName = draft.holderRef?.name || "—";

  return (
    <>
      <div className="detail-header">
        <div className="detail-header-left">
          <span className="avatar lg muted"><Icon name="folder" size={18} /></span>
          <div>
            <h1 className="detail-title">
              {existing ? existing.id : "New requisite"}
              <Badge tone="warn" dot>{existing ? "Editing" : "Draft"}</Badge>
              {draft.primary && <Badge tone="info" dot>Primary</Badge>}
            </h1>
            <div className="detail-id">
              <span>{holderName}</span><span>·</span>
              <span>{provider?.name || "—"}</span><span>·</span>
              <span className="mono">{draft.ccy}</span>
            </div>
          </div>
        </div>
        <div className="page-head-actions">
          <Btn variant="ghost" onClick={onBack}>Cancel</Btn>
          <Btn variant="secondary" icon="shield">Run verification</Btn>
          <Btn variant="primary" icon="check" disabled={!dirty && !!existing}>Save requisite</Btn>
        </div>
      </div>

      <div className="detail-grid">
        <div className="detail-main">
          <Card>
            <RequisiteForm
              value={draft}
              onChange={update}
              holderOptions={holderOptionsAll()}
            />
          </Card>
        </div>

        <div className="detail-side">
          <Card title="Preview">
            <RequisitePreview value={draft} />
          </Card>
          <Card title="Field map">
            <div className="vstack" style={{ gap: 6, fontSize: 12 }}>
              <div style={{ color: "var(--text-muted)" }}>Inherited from provider</div>
              {provider?.kind === "ru_bank" && <div className="mono" style={{ fontSize: 11.5 }}>bic · corr · inn · kpp</div>}
              {provider?.kind === "swift_bank" && <div className="mono" style={{ fontSize: 11.5 }}>swift · iban_prefix · intermediary</div>}
              {provider?.kind === "blockchain" && <div className="mono" style={{ fontSize: 11.5 }}>network · confirmations</div>}
              <div style={{ color: "var(--text-muted)", marginTop: 6 }}>Set on this requisite</div>
              {provider?.kind === "ru_bank" && <div className="mono" style={{ fontSize: 11.5 }}>account · holder_name · purpose</div>}
              {provider?.kind === "swift_bank" && <div className="mono" style={{ fontSize: 11.5 }}>iban · holder · address · charges · purpose_code</div>}
              {provider?.kind === "blockchain" && <div className="mono" style={{ fontSize: 11.5 }}>wallet_address {["TON","XRP"].includes(provider?.network) ? "· memo" : ""}</div>}
              {provider?.kind === "cash_desk" && <div className="mono" style={{ fontSize: 11.5 }}>desk_ref · recipient_id</div>}
            </div>
          </Card>
          {dirty && <Card><CardSaveFoot dirty onSave={() => setDirty(false)} onReset={() => setDirty(false)} /></Card>}
        </div>
      </div>
    </>
  );
};

window.RequisiteEditorScreen = RequisiteEditorScreen;
