/* global React, Icon, Btn, IconBtn, Badge, Card, cx, Field, Input, Select, Segmented, Checkbox, Money, Num */
const { useState } = React;
const { TREASURY_DEAL, ROUTE_TEMPLATES, PROVIDERS, LEG_TYPES } = window.BEDROCK_DATA;

const opIcon = (k) => ({
  doc: "file", money_in: "download", money_out: "upload",
  fx: "exchange", proof: "shield", payout: "upload", close: "check",
}[k] || "activity");

const opTone = (s) => ({
  done: "pos", in_flight: "warn", pending: "warn", queued: "default", blocked: "neg",
}[s] || "default");

const OP_KINDS = [
  { value: "money_in",  label: "Money in",  icon: "download", desc: "Incoming payment received on our account" },
  { value: "money_out", label: "Money out", icon: "upload",   desc: "Outgoing transfer from our account" },
  { value: "fx",        label: "FX",        icon: "exchange", desc: "Convert between two currencies" },
  { value: "payout",    label: "Payout",    icon: "upload",   desc: "Pay beneficiary under the deal" },
  { value: "doc",       label: "Document",  icon: "file",     desc: "Create or send a document (invoice, act…)" },
  { value: "proof",     label: "Proof",     icon: "shield",   desc: "Attach proof of an external event" },
  { value: "close",     label: "Close",     icon: "check",    desc: "Finalise the deal — GL postings + statement" },
];

/* ----------------------------- Add operation sheet ----------------------------- */

const AddOperationSheet = ({ onClose, onAdd }) => {
  const [kind, setKind] = useState("money_out");
  const [leg, setLeg] = useState("2");
  const [title, setTitle] = useState("Pay beneficiary");

  const setKindAndDefaults = (k) => {
    setKind(k);
    setTitle({
      money_in: "Receive payment from customer",
      money_out: "Outgoing transfer",
      fx: "FX conversion",
      payout: "Pay beneficiary",
      doc: "Send document to customer",
      proof: "Attach proof of external event",
      close: "Close deal",
    }[k] || "");
  };

  return (
    <div className="sheet-overlay" onMouseDown={onClose}>
      <div className="sheet" onMouseDown={e => e.stopPropagation()}>
        <div className="sheet-head">
          <div>
            <div className="eyebrow">Deal DL-4401 · Nordmax Trading → Lotus Global</div>
            <div style={{ fontSize: 16, fontWeight: 600, marginTop: 2 }}>Add operation</div>
          </div>
          <IconBtn name="x" onClick={onClose} />
        </div>

        <div className="sheet-body">
          <div className="vstack" style={{ gap: 18 }}>
            <div>
              <div className="eyebrow" style={{ marginBottom: 8 }}>1 · Kind of operation</div>
              <div className="op-kind-grid">
                {OP_KINDS.map(k => (
                  <button key={k.value}
                          type="button"
                          className={cx("op-kind-card", kind === k.value && "active")}
                          onClick={() => setKindAndDefaults(k.value)}>
                    <div className="op-kind-card-head">
                      <span className="op-kind-icon"><Icon name={k.icon} size={14} /></span>
                      <span style={{ fontWeight: 500, fontSize: 13 }}>{k.label}</span>
                    </div>
                    <div style={{ fontSize: 11.5, color: "var(--text-muted)", lineHeight: 1.4 }}>{k.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="eyebrow" style={{ marginBottom: 8 }}>2 · Basics</div>
              <div className="field-row two">
                <Field label="Title" required>
                  <Input value={title} onChange={e => setTitle(e.target.value)} />
                </Field>
                <Field label="Attach to leg" hint="Which leg of the route this operation fulfils">
                  <Select value={leg} onChange={e => setLeg(e.target.value)}>
                    <option value="1">LEG 1 · Collect from customer (RUB)</option>
                    <option value="2">LEG 2 · FX RUB → USD</option>
                    <option value="3">LEG 3 · Internal transfer RU → AE</option>
                    <option value="4">LEG 4 · Payout to beneficiary (USD)</option>
                    <option value="">— Not tied to a leg —</option>
                  </Select>
                </Field>
              </div>
            </div>

            {/* Kind-specific fields */}
            {kind === "money_in" && (
              <div>
                <div className="eyebrow" style={{ marginBottom: 8 }}>3 · Receipt details</div>
                <div className="field-row three">
                  <Field label="Amount expected" required>
                    <Input defaultValue="13 126 568.00" suffix="RUB" />
                  </Field>
                  <Field label="On account">
                    <Select><option>Bedrock RU · Raiffeisen · 40702-0811</option><option>Bedrock RU · VTB · 40702-2290</option></Select>
                  </Field>
                  <Field label="Expected by">
                    <Input type="date" defaultValue="2026-04-19" />
                  </Field>
                </div>
                <Field label="Match against">
                  <Select><option>INV-2201 · Nordmax Trading · 13 126 568.00 RUB</option><option>— Create new invoice —</option></Select>
                </Field>
              </div>
            )}
            {kind === "money_out" && (
              <div>
                <div className="eyebrow" style={{ marginBottom: 8 }}>3 · Transfer details</div>
                <div className="field-row three">
                  <Field label="From" required>
                    <Select><option>Bedrock RU · Raiffeisen · RUB</option><option>Bedrock RU · VTB · RUB</option></Select>
                  </Field>
                  <Field label="To" required>
                    <Select><option>Bedrock AE · Emirates NBD · USD</option><option>Bedrock AE · Wio · USD</option></Select>
                  </Field>
                  <Field label="Amount">
                    <Input defaultValue="142 000.00" suffix="USD" />
                  </Field>
                </div>
                <div className="field-row two">
                  <Field label="Value date">
                    <Input type="date" defaultValue="2026-04-20" />
                  </Field>
                  <Field label="Reference">
                    <Input defaultValue="DL-4401 · internal tfr · inv 2201" />
                  </Field>
                </div>
              </div>
            )}
            {kind === "fx" && (
              <div>
                <div className="eyebrow" style={{ marginBottom: 8 }}>3 · FX details</div>
                <div className="field-row three">
                  <Field label="Pair" required>
                    <Select><option>RUB → USD</option><option>USD → AED</option><option>RUB → CNY</option></Select>
                  </Field>
                  <Field label="Sell amount">
                    <Input defaultValue="13 126 568.00" suffix="RUB" />
                  </Field>
                  <Field label="Rate source">
                    <Select><option>MOEX · live + 0.25%</option><option>Raiffeisen fix</option><option>Manual</option></Select>
                  </Field>
                </div>
              </div>
            )}
            {kind === "payout" && (
              <div>
                <div className="eyebrow" style={{ marginBottom: 8 }}>3 · Payout details</div>
                <div className="field-row three">
                  <Field label="Beneficiary">
                    <Input defaultValue="Lotus Global FZE" disabled />
                  </Field>
                  <Field label="Requisite">
                    <Select><option>REQ-5012 · Emirates NBD · IBAN · USD</option></Select>
                  </Field>
                  <Field label="Amount">
                    <Input defaultValue="140 040.00" suffix="USD" />
                  </Field>
                </div>
                <Field label="Purpose of payment">
                  <Input defaultValue="Payment under contract DL-4401 / INV-2201" />
                </Field>
              </div>
            )}
            {kind === "doc" && (
              <div>
                <div className="eyebrow" style={{ marginBottom: 8 }}>3 · Document</div>
                <div className="field-row two">
                  <Field label="Type" required>
                    <Select><option>Invoice</option><option>Contract</option><option>Act of works</option><option>Closing statement</option></Select>
                  </Field>
                  <Field label="Template">
                    <Select><option>EN/RU bilingual · v3</option><option>RU-only · v2</option></Select>
                  </Field>
                </div>
              </div>
            )}
            {kind === "proof" && (
              <div>
                <div className="eyebrow" style={{ marginBottom: 8 }}>3 · Proof</div>
                <Field label="What proves what?">
                  <Select><option>SWIFT MT103 confirming LEG 3 transfer</option><option>Bank statement line</option><option>Customer acknowledgment</option></Select>
                </Field>
                <Field label="Expected by">
                  <Input type="date" defaultValue="2026-04-20" />
                </Field>
              </div>
            )}
            {kind === "close" && (
              <div className="callout">
                <Icon name="info" size={14} />
                <div style={{ fontSize: 12 }}>
                  A single <b>close</b> operation finalises the deal. It auto-generates the closing statement from all prior operations and posts GL entries. Only one close per deal.
                </div>
              </div>
            )}

            <div>
              <div className="eyebrow" style={{ marginBottom: 8 }}>4 · Assignee &amp; schedule</div>
              <div className="field-row three">
                <Field label="Assign to">
                  <Select><option>Dina T.</option><option>Priya M.</option><option>Arman K.</option><option>— Unassigned —</option></Select>
                </Field>
                <Field label="When">
                  <Input type="date" defaultValue="2026-04-20" />
                </Field>
                <Field label="Priority">
                  <Segmented value="normal" onChange={() => {}} options={[
                    { value: "low", label: "Low" },
                    { value: "normal", label: "Normal" },
                    { value: "urgent", label: "Urgent" },
                  ]} />
                </Field>
              </div>
            </div>
          </div>
        </div>

        <div className="sheet-foot">
          <div style={{ fontSize: 11.5, color: "var(--text-muted)" }}>
            Operation will be appended to the timeline after <b>OP-5</b> and queued as <b>pending</b>.
          </div>
          <div className="hstack" style={{ gap: 8 }}>
            <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
            <Btn variant="secondary" icon="plus" onClick={() => onAdd(kind)}>Add &amp; add another</Btn>
            <Btn variant="primary" icon="check" onClick={() => onAdd(kind)}>Add to deal</Btn>
          </div>
        </div>
      </div>
    </div>
  );
};

/* ----------------------------- Workbench ----------------------------- */

const TreasuryDealWorkbench = ({ onBack }) => {
  const d = TREASURY_DEAL;
  const [selectedOp, setSelectedOp] = useState("OP-5");
  const [adding, setAdding] = useState(false);
  const [opFilter, setOpFilter] = useState("all");

  const op = d.operations.find(o => o.id === selectedOp);
  const route = ROUTE_TEMPLATES.find(r => r.id === d.route);

  const done = d.operations.filter(o => o.status === "done").length;
  const total = d.operations.length;

  const visibleOps = opFilter === "pending"
    ? d.operations.filter(o => o.status === "pending" || o.status === "in_flight")
    : d.operations;

  return (
    <>
      <div className="detail-header">
        <div className="detail-header-left">
          <span className="avatar lg muted"><Icon name="briefcase" size={18} /></span>
          <div>
            <h1 className="detail-title">
              Deal workbench · {d.id}
              <Badge tone="info" dot>Funding</Badge>
            </h1>
            <div className="detail-id">
              <span>{d.customer}</span><span>→</span>
              <span>{d.beneficiary}</span><span>·</span>
              <span className="mono"><Money value={d.gross} ccy={d.ccy} muteUnit /></span><span>·</span>
              <span>Route {d.route}</span>
            </div>
          </div>
        </div>
        <div className="page-head-actions">
          <Btn variant="ghost" icon="external">Open in CRM</Btn>
          <Btn variant="secondary" icon="file">Draft document</Btn>
          <Btn variant="primary" icon="plus" onClick={() => setAdding(true)}>Add operation</Btn>
        </div>
      </div>

      <div className="workbench-summary">
        <div className="workbench-summary-item">
          <div className="eyebrow">Progress</div>
          <div style={{ fontSize: 16, fontWeight: 600 }}>{done} / {total}</div>
          <div className="workbench-progress-bar"><div style={{ width: `${done/total*100}%` }} /></div>
        </div>
        <div className="workbench-summary-item">
          <div className="eyebrow">Money in (received)</div>
          <div className="mono" style={{ fontSize: 16, fontWeight: 500, color: "var(--pos)" }}><Money value={142_000} ccy="USD" signed signColor muteUnit /></div>
        </div>
        <div className="workbench-summary-item">
          <div className="eyebrow">Money out (scheduled)</div>
          <div className="mono" style={{ fontSize: 16, fontWeight: 500 }}><Money value={-140_040} ccy="USD" signed signColor muteUnit /></div>
        </div>
        <div className="workbench-summary-item">
          <div className="eyebrow">Margin captured</div>
          <div className="mono" style={{ fontSize: 16, fontWeight: 500, color: "var(--pos)" }}><Money value={1_240} ccy="USD" muteUnit /></div>
        </div>
        <div className="workbench-summary-item">
          <div className="eyebrow">Documents</div>
          <div style={{ fontSize: 16, fontWeight: 600 }}>3 <span style={{ color: "var(--text-muted)", fontWeight: 400, fontSize: 12 }}>· 1 pending</span></div>
        </div>
      </div>

      <div className="workbench-layout">
        {/* LEFT: current operation editor + attachments + deal context stacked */}
        <div className="workbench-main-pane">
          <Card
            title={<>
              <span className="op-title-prefix mono">{op?.id}</span>
              <span>{op?.title}</span>
              <Badge tone={opTone(op?.status)} dot>{op?.status?.replace("_", " ")}</Badge>
            </>}
            sub={op?.meta}
            actions={<>
              <Btn variant="ghost" size="sm" icon="edit">Edit</Btn>
              <Btn variant="ghost" size="sm" icon="dots_vertical" />
            </>}>
            {op?.kind === "money_in" && (
              <div className="vstack" style={{ gap: 14 }}>
                <div className="field-row three">
                  <Field label="Amount received" required>
                    <Input defaultValue="13 126 568.00" suffix="RUB" />
                  </Field>
                  <Field label="On account">
                    <Select><option>Bedrock RU · Raiffeisen · 40702-0811</option></Select>
                  </Field>
                  <Field label="Value date">
                    <Input type="date" defaultValue="2026-04-19" />
                  </Field>
                </div>
                <Field label="Match against invoice">
                  <Select><option>INV-2201 · Nordmax Trading · 13 126 568.00 RUB · open</option></Select>
                </Field>
                <div className="callout">
                  <Icon name="check" size={14} />
                  <div style={{ fontSize: 12 }}>
                    Amount matches invoice within 0.00 RUB tolerance. <b>Auto-reconciled</b>.
                  </div>
                </div>
                <div className="hstack" style={{ gap: 8 }}>
                  <Btn variant="secondary" icon="upload">Attach proof of incoming</Btn>
                  <Btn variant="primary" icon="check">Confirm receipt</Btn>
                </div>
              </div>
            )}

            {op?.kind === "money_out" && (
              <div className="vstack" style={{ gap: 14 }}>
                <div className="field-row three">
                  <Field label="From account" required>
                    <Select><option>Bedrock RU · Raiffeisen</option></Select>
                  </Field>
                  <Field label="To account" required>
                    <Select><option>Bedrock AE · Emirates NBD</option></Select>
                  </Field>
                  <Field label="Amount">
                    <Input defaultValue="142 000.00" suffix="USD" />
                  </Field>
                </div>
                <div className="field-row two">
                  <Field label="Value date" required>
                    <Input type="date" defaultValue="2026-04-20" />
                  </Field>
                  <Field label="Reference">
                    <Input defaultValue="DL-4401 · internal tfr · inv 2201" />
                  </Field>
                </div>
                <div className="op-upload">
                  <Icon name="upload" size={24} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>Drop SWIFT MT103 copy here</div>
                    <div style={{ fontSize: 12, color: "var(--text-muted)" }}>PDF or image. Gets attached to this operation as proof of payment.</div>
                  </div>
                  <Btn variant="secondary" size="sm">Browse</Btn>
                </div>
                <div className="hstack" style={{ gap: 8 }}>
                  <Btn variant="ghost">Mark as sent (no proof yet)</Btn>
                  <Btn variant="primary" icon="check">Attach &amp; mark sent</Btn>
                </div>
              </div>
            )}

            {op?.kind === "fx" && (
              <div className="vstack" style={{ gap: 14 }}>
                <div className="field-row three">
                  <Field label="Pair" required>
                    <Select><option>RUB → USD</option></Select>
                  </Field>
                  <Field label="Rate used">
                    <Input defaultValue="92.4400" />
                  </Field>
                  <Field label="Source">
                    <Input defaultValue="MOEX · live · locked 09:18" disabled />
                  </Field>
                </div>
                <div className="field-row two">
                  <Field label="Sell">
                    <Input defaultValue="13 126 568.00 RUB" disabled />
                  </Field>
                  <Field label="Buy">
                    <Input defaultValue="142 000.00 USD" disabled />
                  </Field>
                </div>
              </div>
            )}

            {op?.kind === "doc" && (
              <div className="vstack" style={{ gap: 14 }}>
                <div className="field-row two">
                  <Field label="Document type">
                    <Select><option>Invoice</option><option>Contract</option><option>Act of works</option><option>Closing statement</option></Select>
                  </Field>
                  <Field label="Template">
                    <Select><option>EN/RU bilingual · v3</option></Select>
                  </Field>
                </div>
                <Field label="Attached file">
                  <Input defaultValue="INV-2201.pdf" suffix="↓ download" />
                </Field>
                <div className="hstack" style={{ gap: 8 }}>
                  <Btn variant="secondary" icon="download">Download</Btn>
                  <Btn variant="secondary" icon="edit">Open in editor</Btn>
                  <Btn variant="primary" icon="external">Send to customer</Btn>
                </div>
              </div>
            )}

            {op?.kind === "proof" && (
              <div className="vstack" style={{ gap: 14 }}>
                <div className="callout warn">
                  <Icon name="info" size={14} />
                  <div style={{ fontSize: 12 }}>
                    Waiting for SWIFT MT103 confirmation from Raiffeisen. Expected before EOD.
                  </div>
                </div>
                <div className="op-upload">
                  <Icon name="upload" size={24} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>Attach MT103 copy</div>
                    <div style={{ fontSize: 12, color: "var(--text-muted)" }}>PDF, image, or e-doc. Signals LEG 3 can start.</div>
                  </div>
                  <Btn variant="primary" size="sm" icon="upload">Upload</Btn>
                </div>
              </div>
            )}

            {op?.kind === "payout" && (
              <div className="vstack" style={{ gap: 14 }}>
                <div className="field-row three">
                  <Field label="Beneficiary">
                    <Input defaultValue="Lotus Global FZE" disabled />
                  </Field>
                  <Field label="Requisite">
                    <Select><option>REQ-5012 · Emirates NBD · IBAN · USD</option></Select>
                  </Field>
                  <Field label="Amount">
                    <Input defaultValue="140 040.00" suffix="USD" />
                  </Field>
                </div>
                <Field label="Purpose of payment">
                  <Input defaultValue="Payment under contract DL-4401 / INV-2201 / goods &amp; services" />
                </Field>
                <div className="hstack" style={{ gap: 8 }}>
                  <Btn variant="secondary" icon="calendar">Reschedule</Btn>
                  <Btn variant="primary" icon="upload">Execute payout</Btn>
                </div>
              </div>
            )}

            {op?.kind === "close" && (
              <div className="vstack" style={{ gap: 14 }}>
                <div style={{ fontSize: 13 }}>All prior operations must be marked <b>done</b> before closing.</div>
                <Field label="Closing statement">
                  <Select><option>Auto-generate from operations</option></Select>
                </Field>
                <div className="hstack" style={{ gap: 8 }}>
                  <Btn variant="secondary" icon="file">Preview GL postings</Btn>
                  <Btn variant="primary" icon="check" disabled>Close deal</Btn>
                </div>
              </div>
            )}
          </Card>

          <Card title="Attachments on this operation">
            <div className="vstack" style={{ gap: 6 }}>
              {op?.status === "done" ? (
                <>
                  <div className="hstack attach-row">
                    <Icon name="file" size={14} />
                    <span style={{ flex: 1, fontSize: 12.5 }}>MT103_DL4401_leg2.pdf</span>
                    <span className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>142 kb</span>
                    <IconBtn name="download" />
                  </div>
                  <div className="hstack attach-row">
                    <Icon name="file" size={14} />
                    <span style={{ flex: 1, fontSize: 12.5 }}>Raiffeisen_confirmation.pdf</span>
                    <span className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>88 kb</span>
                    <IconBtn name="download" />
                  </div>
                </>
              ) : (
                <div style={{ color: "var(--text-muted)", fontSize: 12.5, padding: "16px 0", textAlign: "center" }}>
                  No attachments yet
                </div>
              )}
            </div>
          </Card>

          <div className="workbench-context-grid">
            <Card title="Route in effect" sub={route?.name}>
              <div className="vstack" style={{ gap: 8 }}>
                {route?.legs.map(l => (
                  <div key={l.n} className="hstack route-leg-row">
                    <span className="mono" style={{ width: 36, color: "var(--text-muted)", fontSize: 11 }}>L{l.n}</span>
                    <Icon name={({ collect: "download", fx: "exchange", transfer: "arrow_right", payout: "upload" })[l.type]} size={12} />
                    <span style={{ flex: 1, fontSize: 12.5 }}>{LEG_TYPES.find(t => t.value === l.type)?.label}</span>
                    <span className="mono" style={{ fontSize: 11 }}>{l.ccy}</span>
                  </div>
                ))}
              </div>
            </Card>
            <Card title="Parties">
              <div className="vstack" style={{ gap: 10, fontSize: 12.5 }}>
                <div>
                  <div className="kv-label">Customer</div>
                  <div style={{ fontWeight: 500 }}>{d.customer}</div>
                  <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>REQ-5013 · VTB · RUB</div>
                </div>
                <div className="divider" />
                <div>
                  <div className="kv-label">Beneficiary</div>
                  <div style={{ fontWeight: 500 }}>{d.beneficiary}</div>
                  <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>REQ-5012 · Emirates NBD · USD</div>
                </div>
              </div>
            </Card>
            <Card title="Cashflow">
              <div className="vstack" style={{ gap: 6, fontSize: 12.5 }}>
                <div className="hstack" style={{ justifyContent: "space-between" }}>
                  <span style={{ color: "var(--text-muted)" }}>In</span>
                  <Money value={142_000} ccy="USD" signed signColor muteUnit />
                </div>
                <div className="hstack" style={{ justifyContent: "space-between" }}>
                  <span style={{ color: "var(--text-muted)" }}>Out (scheduled)</span>
                  <Money value={-140_040} ccy="USD" signed signColor muteUnit />
                </div>
                <div className="divider" />
                <div className="hstack" style={{ justifyContent: "space-between", fontWeight: 500 }}>
                  <span>Net margin</span>
                  <Money value={1_240} ccy="USD" signed signColor muteUnit />
                </div>
                <div className="hstack" style={{ justifyContent: "space-between", color: "var(--text-muted)" }}>
                  <span>of which fees</span>
                  <Money value={1_960} ccy="USD" muteUnit />
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* RIGHT: operations timeline */}
        <aside className="workbench-timeline-pane">
          <div className="workbench-pane-head">
            <div className="hstack">
              <div style={{ fontWeight: 600, fontSize: 13 }}>Operations</div>
              <Badge mono outline>{total}</Badge>
            </div>
            <Segmented value={opFilter} onChange={setOpFilter} options={[
              { value: "all", label: "All" },
              { value: "pending", label: "Pending", count: d.operations.filter(o => o.status === "pending" || o.status === "in_flight").length },
            ]} />
          </div>
          <div className="workbench-timeline">
            {visibleOps.map((o) => {
              const sel = selectedOp === o.id;
              return (
                <div key={o.id} className={cx("op-row", sel && "selected")} onClick={() => setSelectedOp(o.id)}>
                  <div className={cx("op-dot", o.status)}>
                    <Icon name={opIcon(o.kind)} size={12} />
                  </div>
                  <div className="op-body">
                    <div className="op-row-head">
                      <span className="mono op-row-id">{o.id}</span>
                      <Badge tone={opTone(o.status)} dot>{o.status.replace("_", " ")}</Badge>
                    </div>
                    <div className="op-title-text">{o.title}</div>
                    <div className="op-meta mono">{o.meta}</div>
                    <div className="op-foot">
                      <Icon name="calendar" size={10} />
                      <span>{o.when}</span>
                      {o.actor !== "—" && <><span>·</span><Icon name="user" size={10} /><span>{o.actor}</span></>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="workbench-timeline-foot">
            <Btn variant="secondary" icon="plus" className="btn-block" onClick={() => setAdding(true)}>Add operation</Btn>
          </div>
        </aside>
      </div>

      {adding && <AddOperationSheet onClose={() => setAdding(false)} onAdd={() => setAdding(false)} />}
    </>
  );
};

window.TreasuryDealWorkbench = TreasuryDealWorkbench;
