/* global React, Icon, Btn, IconBtn, Badge, Card, cx, CountryPill, Money */
const { useState } = React;
const { ROUTES, REQUISITES } = window.BEDROCK_DATA;

const RouteFlowDiagram = ({ flow }) => (
  <div className="route-flow">
    {flow.map((node, i) => (
      <React.Fragment key={i}>
        <div className={cx("route-flow-node", node.role === "Bedrock" && "bedrock", node.role === "Customer" && "endpoint start", node.role === "Beneficiary" && "endpoint end")}>
          <div className="route-flow-role">{node.role}</div>
          <div className="route-flow-title">{node.title}</div>
          <div className="route-flow-sub">{node.sub}</div>
          {node.fee && <div className="route-flow-fee mono">{node.fee}</div>}
        </div>
        {i < flow.length - 1 && (
          <div className="route-flow-arrow">
            <svg viewBox="0 0 40 10" width="40" height="10" preserveAspectRatio="none">
              <path d="M0 5 L36 5 M32 1 L36 5 L32 9" stroke="currentColor" strokeWidth="1.2" fill="none" />
            </svg>
          </div>
        )}
      </React.Fragment>
    ))}
  </div>
);

const parseFeeOnAmount = (feeStr, amount) => {
  if (!feeStr) return 0;
  if (feeStr.endsWith("%")) return amount * parseFloat(feeStr) / 100;
  if (feeStr.endsWith(" bps")) return amount * parseFloat(feeStr) / 10000;
  if (feeStr.startsWith("$")) return parseFloat(feeStr.slice(1));
  return 0;
};

const RouteCostPreview = ({ route, sampleGross = 100_000 }) => {
  const ccy = route.in_ccy === "RUB" || route.in_ccy === "ZAR" ? "USD" : route.in_ccy;
  // Sample flows — compute per-leg fee on a notional USD-equivalent
  const legs = route.flow.filter(n => n.fee);
  let running = sampleGross;
  const rows = legs.map(l => {
    const fee = parseFeeOnAmount(l.fee, running);
    running -= fee;
    return { label: l.title, fee, feeStr: l.fee };
  });
  const feeTotal = rows.reduce((s, r) => s + r.fee, 0);
  const marginBps = parseFloat(route.margin) * 100;
  const marginAbs = sampleGross * marginBps / 10000;
  const costTotal = feeTotal + marginAbs;
  const costPct = (costTotal / sampleGross) * 100;

  return (
    <div className="route-cost">
      <div className="route-cost-gross">
        <div className="eyebrow">Sample gross amount</div>
        <div className="mono" style={{ fontSize: 16, fontWeight: 600 }}>
          <Money value={sampleGross} ccy={ccy} muteUnit />
        </div>
      </div>
      <div className="route-cost-rows">
        {rows.map((r, i) => (
          <div key={i} className="route-cost-row">
            <span className="route-cost-label">{r.label}</span>
            <span className="route-cost-fee mono">{r.feeStr}</span>
            <span className="route-cost-amt mono">−<Money value={r.fee} ccy={ccy} muteUnit /></span>
          </div>
        ))}
        <div className="route-cost-row subtotal">
          <span className="route-cost-label">Fee subtotal</span>
          <span></span>
          <span className="route-cost-amt mono">−<Money value={feeTotal} ccy={ccy} muteUnit /></span>
        </div>
        <div className="route-cost-row">
          <span className="route-cost-label">Bedrock margin</span>
          <span className="route-cost-fee mono">{marginBps.toFixed(0)} bps</span>
          <span className="route-cost-amt mono">−<Money value={marginAbs} ccy={ccy} muteUnit /></span>
        </div>
        <div className="route-cost-row total">
          <span className="route-cost-label">Cost to customer</span>
          <span className="route-cost-fee mono" style={{ color: "var(--text-muted)" }}>{costPct.toFixed(2)}%</span>
          <span className="route-cost-amt mono"><Money value={costTotal} ccy={ccy} muteUnit /></span>
        </div>
        <div className="route-cost-row net">
          <span className="route-cost-label">Net to beneficiary</span>
          <span></span>
          <span className="route-cost-amt mono" style={{ color: "var(--pos)" }}><Money value={sampleGross - costTotal} ccy={ccy} muteUnit /></span>
        </div>
      </div>
    </div>
  );
};

const RoutesScreen = () => {
  const [selected, setSelected] = useState("RT-081");
  const route = ROUTES.find(r => r.id === selected) || ROUTES[0];
  return (
    <>
      <div className="page-head">
        <div>
          <h1 className="page-title">Payment routes</h1>
          <div className="page-sub">Reusable templates composed from legs, providers, and fee rules</div>
        </div>
        <div className="page-head-actions">
          <Btn variant="secondary" icon="copy">Duplicate</Btn>
          <Btn variant="primary" icon="plus">New route</Btn>
        </div>
      </div>

      <div className="routes-split">
        {/* Left: route list */}
        <div className="routes-list">
          {ROUTES.map(r => (
            <button key={r.id}
              className={cx("route-row", selected === r.id && "selected")}
              onClick={() => setSelected(r.id)}>
              <div className="route-row-main">
                <div className="route-row-name">{r.name}</div>
                <div className="route-row-meta">
                  <span className="mono">{r.id}</span>
                  <span>·</span>
                  <span>{r.legs} legs</span>
                  <span>·</span>
                  <span>{r.corridor}</span>
                </div>
              </div>
              <div className="route-row-stats">
                <div className="route-row-stat">
                  <div className="eyebrow">Margin</div>
                  <div className="mono" style={{ fontSize: 12.5 }}>{r.margin}</div>
                </div>
                <div className="route-row-stat">
                  <div className="eyebrow">Uses 30d</div>
                  <div className="mono" style={{ fontSize: 12.5 }}>{r.uses}</div>
                </div>
                <Badge tone={r.status === "live" ? "pos" : "warn"} dot>{r.status}</Badge>
              </div>
            </button>
          ))}
        </div>

        {/* Right: preview pane */}
        <div className="routes-preview">
          <div className="routes-preview-head">
            <div>
              <div className="hstack" style={{ gap: 8 }}>
                <h3 style={{ fontSize: 15, fontWeight: 600, margin: 0 }}>{route.name}</h3>
                <Badge tone={route.status === "live" ? "pos" : "warn"} dot>{route.status}</Badge>
              </div>
              <div className="route-row-meta" style={{ marginTop: 4 }}>
                <span className="mono">{route.id}</span>
                <span>·</span>
                <span>{route.legs} legs</span>
                <span>·</span>
                <span>Settles in {route.settlement}</span>
              </div>
            </div>
            <div className="hstack">
              <Btn variant="ghost" size="sm" icon="edit">Edit</Btn>
              <Btn variant="secondary" size="sm" icon="play">Use in deal</Btn>
            </div>
          </div>

          <Card title="Route" sub="Money flow across legs">
            <RouteFlowDiagram flow={route.flow} />
          </Card>

          <Card title="Cost preview" sub="Live fees + margin applied to a sample amount">
            <RouteCostPreview route={route} />
          </Card>
        </div>
      </div>
    </>
  );
};

const REQ_PROVIDERS = window.BEDROCK_DATA.PROVIDERS;
const reqProvider = (id) => REQ_PROVIDERS.find(p => p.id === id);
const reqNumber = (r) => r.iban || r.account || r.walletAddress || r.walletId || r.cardMasked || r.deskRef || "—";
const reqScheme = (r) => {
  const p = reqProvider(r.providerId);
  if (!p) return "—";
  return ({
    ru_bank: "RU account",
    swift_bank: "IBAN/SWIFT",
    blockchain: p.network,
    psp: "PSP",
    e_wallet: "E-wallet",
    card_processor: "Card",
    cash_desk: "Cash desk",
  })[p.kind] || p.kind;
};

const RequisitesScreen = () => (
  <>
    <div className="page-head">
      <div>
        <h1 className="page-title">Requisites</h1>
        <div className="page-sub">{REQUISITES.length} banking requisites across parties</div>
      </div>
      <div className="page-head-actions">
        <Btn variant="secondary" icon="download">Export</Btn>
        <Btn variant="primary" icon="plus">New requisite</Btn>
      </div>
    </div>
    <div className="table-wrap">
      <table className="table">
        <thead><tr>
          <th>ID</th><th>Holder</th><th>Provider</th><th>Scheme</th>
          <th>Number</th><th>CCY</th><th>Primary</th><th>Status</th><th style={{ width: 40 }}></th>
        </tr></thead>
        <tbody>
          {REQUISITES.map(r => {
            const p = reqProvider(r.providerId);
            return (
              <tr key={r.id}>
                <td className="mono muted">{r.id}</td>
                <td>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <span>{r.holderRef?.name || "—"}</span>
                    {r.holderRef?.country && <span className="muted" style={{ fontSize: 11 }}>{r.holderRef.country}</span>}
                  </div>
                </td>
                <td>{p?.name || "—"}</td>
                <td><Badge mono outline>{reqScheme(r)}</Badge></td>
                <td className="mono" style={{ fontSize: 12 }}>{reqNumber(r)}</td>
                <td><span className="mono">{r.ccy}</span></td>
                <td>{r.primary ? <Icon name="check" size={14} /> : <span style={{ color: "var(--text-faint)" }}>—</span>}</td>
                <td>
                  {r.status === "verified" && <Badge tone="pos" dot>Verified</Badge>}
                  {r.status === "pending" && <Badge tone="warn" dot>Pending</Badge>}
                  {r.status === "expired" && <Badge tone="neg" dot>Expired</Badge>}
                  {r.status === "draft" && <Badge tone="default" dot>Draft</Badge>}
                </td>
                <td><IconBtn name="dots_vertical" /></td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  </>
);

window.RoutesScreen = RoutesScreen;
window.RequisitesScreen = RequisitesScreen;
