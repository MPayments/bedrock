/* global React, Icon, Btn, IconBtn, Badge, Segmented, Card, cx, CountryPill, Money, Field, Input, Select, DealCreateDialog */
const { useState } = React;
const { DEALS, STAGE_LABEL, STAGE_BADGE } = window.BEDROCK_DATA;

/* =======================================================
   Deals list
======================================================= */
const DealsScreen = ({ onOpen }) => {
  const [seg, setSeg] = useState("all");
  const [createOpen, setCreateOpen] = useState(false);
  const rows = DEALS.filter(d => seg === "all" || d.stage === seg);

  const stageCounts = DEALS.reduce((a, d) => (a[d.stage] = (a[d.stage] || 0) + 1, a), {});

  return (
    <>
      <div className="page-head">
        <div>
          <h1 className="page-title">Deals</h1>
          <div className="page-sub">Pipeline · {DEALS.length} deals · ${DEALS.reduce((a, d) => a + d.amount, 0).toLocaleString()} gross</div>
        </div>
        <div className="page-head-actions">
          <Btn variant="ghost" icon="download">Export</Btn>
          <Btn variant="secondary" icon="filter">Filters</Btn>
          <Btn variant="primary" icon="plus" onClick={() => setCreateOpen(true)}>New deal</Btn>
        </div>
      </div>

      <div className="kpi-grid">
        {[
          { label: "Open", value: DEALS.filter(d => d.stage !== "settled" && d.stage !== "rejected").length, sub: "deals" },
          { label: "Awaiting approval", value: DEALS.filter(d => d.stage === "approval").length, sub: "deals", tone: "warn" },
          { label: "Gross volume (month)", value: "$3.5M", sub: "+12% MoM", tone: "pos" },
          { label: "Net profit (month)", value: "$26.3K", sub: "+8% MoM", tone: "pos" },
        ].map((k, i) => (
          <div key={i} className="kpi">
            <div className="kpi-label">{k.label}</div>
            <div className={cx("kpi-value", k.tone)}>{k.value}</div>
            <div className="kpi-sub">{k.sub}</div>
          </div>
        ))}
      </div>

      <div className="table-wrap">
        <div className="table-toolbar">
          <div className="table-toolbar-left">
            <Segmented value={seg} onChange={setSeg} options={[
              { value: "all", label: "All", count: DEALS.length },
              { value: "pricing", label: "Pricing", count: stageCounts.pricing || 0 },
              { value: "calculating", label: "Calculating", count: stageCounts.calculating || 0 },
              { value: "approval", label: "Approval", count: stageCounts.approval || 0 },
              { value: "funding", label: "Funding", count: stageCounts.funding || 0 },
              { value: "settled", label: "Settled", count: stageCounts.settled || 0 },
            ]} />
          </div>
        </div>

        <table className="table">
          <thead>
            <tr>
              <th style={{ width: 100 }}>ID</th>
              <th>Customer → Beneficiary</th>
              <th className="right">Gross</th>
              <th className="right">Fee</th>
              <th className="right">Net profit</th>
              <th>Stage</th>
              <th>Due</th>
              <th style={{ width: 60 }}>Owner</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(d => (
              <tr key={d.id} onClick={onOpen}>
                <td className="mono muted">{d.id}</td>
                <td>
                  <div style={{ fontWeight: 500 }}>{d.customer}</div>
                  <div style={{ fontSize: 12, color: "var(--text-muted)" }}>→ {d.beneficiary} · {d.corridor}</div>
                </td>
                <td className="right mono"><Money value={d.amount} ccy={d.ccy} muteUnit={false} /></td>
                <td className="right"><Money value={d.fee} ccy={d.ccy} muteUnit={false} /></td>
                <td className="right"><Money value={d.profit} ccy="USD" signed signColor muteUnit={false} /></td>
                <td><Badge tone={STAGE_BADGE[d.stage]} dot>{STAGE_LABEL[d.stage]}</Badge></td>
                <td className="mono muted" style={{ fontSize: 12 }}>{d.due}</td>
                <td><span className="avatar sm muted">{d.owner}</span></td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="table-foot">
          <span>{rows.length} of {DEALS.length} · showing all stages</span>
          <span>Density: comfortable</span>
        </div>
      </div>

      <DealCreateDialog open={createOpen} onClose={() => setCreateOpen(false)} onCreated={() => setCreateOpen(false)} />
    </>
  );
};

/* =======================================================
   Stage-specific content panes
======================================================= */

const PricingPane = () => {
  const [benRequisite, setBenRequisite] = useState({
    name: "Lotus Global FZE",
    country: "AE",
    bank: "First Abu Dhabi Bank",
    iban: "AE070331234567890123456",
    swift: "FABMAEAA",
    address: "Office 2201, Emirates Towers, Sheikh Zayed Rd, Dubai, UAE",
  });

  return (
    <div className="stage-pane">
      <Card title="1 · Beneficiary intake" sub="Captured on deal creation — complete missing fields before pricing">
        <div className="vstack" style={{ gap: 14 }}>
          <div className="field-row two">
            <Field label="Beneficiary name" required>
              <Input value={benRequisite.name} onChange={e => setBenRequisite({ ...benRequisite, name: e.target.value })} />
            </Field>
            <Field label="Country" required>
              <Input value={benRequisite.country} onChange={e => setBenRequisite({ ...benRequisite, country: e.target.value })} />
            </Field>
          </div>
          <div className="field-row two">
            <Field label="Bank" required>
              <Input value={benRequisite.bank} onChange={e => setBenRequisite({ ...benRequisite, bank: e.target.value })} />
            </Field>
            <Field label="SWIFT / BIC" required>
              <Input value={benRequisite.swift} onChange={e => setBenRequisite({ ...benRequisite, swift: e.target.value })} />
            </Field>
          </div>
          <Field label="IBAN / Account" required>
            <Input value={benRequisite.iban} onChange={e => setBenRequisite({ ...benRequisite, iban: e.target.value })} />
          </Field>
          <Field label="Beneficiary address" required hint="Printed on SWIFT 59">
            <textarea className="input" rows={2} value={benRequisite.address} onChange={e => setBenRequisite({ ...benRequisite, address: e.target.value })} />
          </Field>

          <div className="callout">
            <Icon name="check" size={14} style={{ color: "var(--pos)" }} />
            <div style={{ fontSize: 12 }}>
              All fields valid. SWIFT BIC resolves to <b>First Abu Dhabi Bank · Dubai</b>. Sanctions screen <b className="mono" style={{ color: "var(--pos)" }}>CLEAN</b> (ran Apr 18).
            </div>
          </div>
        </div>
      </Card>

      <Card title="2 · Initial offer to customer" sub="Indicative rate and fee — customer must accept before we calculate">
        <div className="kv-grid" style={{ gridTemplateColumns: "repeat(3, 1fr)" }}>
          <div><div className="kv-label">Gross in</div><div className="kv-value mono">13 126 568.00 RUB</div></div>
          <div><div className="kv-label">Proposed all-in rate</div><div className="kv-value mono">93.7214</div></div>
          <div><div className="kv-label">Beneficiary receives</div><div className="kv-value mono">140 040.00 USD</div></div>
          <div><div className="kv-label">Proposed fee</div><div className="kv-value mono">1 960.00 USD</div></div>
          <div><div className="kv-label">Bedrock margin (est.)</div><div className="kv-value mono" style={{ color: "var(--pos)" }}>+1 240.00 USD</div></div>
          <div><div className="kv-label">Rate valid until</div><div className="kv-value mono">Apr 19 · 18:00 MSK</div></div>
        </div>
        <div className="hstack" style={{ marginTop: 14, gap: 8, justifyContent: "flex-end" }}>
          <Btn variant="ghost" icon="edit">Edit proposal</Btn>
          <Btn variant="secondary" icon="mail">Send to customer</Btn>
          <Btn variant="primary" icon="arrow_right">Customer accepted → Calculating</Btn>
        </div>
      </Card>

      <Card title="Activity">
        <div className="vstack" style={{ gap: 10, fontSize: 12.5 }}>
          {[
            { who: "AE", what: "Created deal from template", when: "Apr 18 · 10:05" },
            { who: "AE", what: "Attached beneficiary Lotus Global FZE", when: "Apr 18 · 10:08" },
            { who: "SY", what: "Generated initial offer · rate 93.7214", when: "Apr 18 · 10:14" },
            { who: "System", what: "Sanctions screen passed for Lotus Global FZE", when: "Apr 18 · 10:15" },
          ].map((a, i) => (
            <div key={i} className="hstack" style={{ gap: 10 }}>
              <span className="avatar sm muted">{a.who}</span>
              <span style={{ flex: 1 }}>{a.what}</span>
              <span className="mono" style={{ color: "var(--text-muted)", fontSize: 11 }}>{a.when}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

const CalculatingPane = () => {
  const [amount, setAmount] = useState(142000);
  const [route, setRoute] = useState("RT-081");
  const [feeBps, setFeeBps] = useState(138);

  const baseRate = 92.44;
  const feeAbs = amount * (feeBps / 10000);
  const allIn = amount + feeAbs;
  const allInRate = baseRate * (1 + feeBps / 10000);
  const initialOfferRate = 93.7214;
  const withinPromise = allInRate <= initialOfferRate + 0.0001;

  const feeRows = [
    { c: "Acquiring fee", p: "Raiffeisen RU", basis: "0.35%", amt: 497 },
    { c: "Cross-border transfer", p: "Bedrock RU→AE", basis: "0.60%", amt: 852 },
    { c: "Beneficiary payout", p: "Emirates NBD", basis: "fixed", amt: 85 },
    { c: "FX spread", p: "EBS (USD/RUB)", basis: "8 bps", amt: 113.60 },
    { c: "Margin", p: "Bedrock", basis: "0.29%", amt: 411.80 },
  ];

  return (
    <div className="stage-pane">
      {/* Customer promise banner */}
      <div className={cx("callout", !withinPromise && "warn")}
        style={{ background: withinPromise ? "var(--pos-bg)" : "var(--warn-bg)",
                 borderColor: withinPromise ? "oklch(0.88 0.06 155)" : "oklch(0.88 0.06 75)" }}>
        <Icon name={withinPromise ? "check" : "alert"} size={14}
          style={{ color: withinPromise ? "var(--pos)" : "var(--warn)" }} />
        <div style={{ fontSize: 12.5 }}>
          Customer accepted indicative offer on <b>Apr 18 · 11:40</b> at rate{" "}
          <b className="mono">{initialOfferRate.toFixed(4)}</b>. Final all-in rate must not exceed this value.
          {withinPromise
            ? <> Current: <b className="mono" style={{ color: "var(--pos)" }}>{allInRate.toFixed(4)}</b> ✓ within promise.</>
            : <> Current: <b className="mono" style={{ color: "var(--warn)" }}>{allInRate.toFixed(4)}</b> — over promise, re-quote required.</>}
        </div>
      </div>

      {/* Inputs */}
      <Card title="Inputs" sub="Change any input — totals recalculate below">
        <div className="field-row three">
          <Field label="Gross amount" required>
            <Input type="number" value={amount} onChange={e => setAmount(+e.target.value || 0)} prefix="USD" />
          </Field>
          <Field label="Settlement currency">
            <Select defaultValue="USD"><option>USD</option><option>EUR</option><option>AED</option></Select>
          </Field>
          <Field label="Route template">
            <Select value={route} onChange={e => setRoute(e.target.value)}>
              <option value="RT-081">RT-081 · RU→AE standard (3 legs)</option>
              <option value="RT-082">RT-082 · EU→RU priority</option>
            </Select>
          </Field>
        </div>
        <div className="field-row three" style={{ marginTop: 12 }}>
          <Field label="Base rate source">
            <Select defaultValue="moex"><option value="moex">MOEX + EBS · live</option><option value="cbr">CBR + EBS</option></Select>
          </Field>
          <Field label="Base rate (USD/RUB)">
            <Input defaultValue="92.4400" suffix="live" />
          </Field>
          <Field label="Fee (bps)" hint="1 bps = 0.01%">
            <Input type="number" value={feeBps} onChange={e => setFeeBps(+e.target.value || 0)} suffix="bps" />
          </Field>
        </div>
      </Card>

      {/* Fee breakdown */}
      <Card title="Fee breakdown" sub={`Per-leg fees from route template ${route}`}>
        <table className="table" style={{ border: "none" }}>
          <thead><tr>
            <th>Component</th><th>Provider</th><th className="right">Basis</th><th className="right">Amount</th>
          </tr></thead>
          <tbody>
            {feeRows.map((r, i) => (
              <tr key={i} style={{ cursor: "default" }}>
                <td>{r.c}</td>
                <td style={{ color: "var(--text-muted)" }}>{r.p}</td>
                <td className="right"><span className="mono">{r.basis}</span></td>
                <td className="right"><Money value={r.amt} ccy="USD" muteUnit /></td>
              </tr>
            ))}
            <tr style={{ cursor: "default" }}>
              <td colSpan={3} style={{ fontWeight: 600, textAlign: "right" }}>Total fee</td>
              <td className="right" style={{ fontWeight: 600 }}><Money value={feeAbs} ccy="USD" muteUnit /></td>
            </tr>
          </tbody>
        </table>
      </Card>

      {/* Quote summary — inline (we're inside the deal detail's main column) */}
      <Card title="Quote" sub="What the customer sees · what Bedrock earns">
        <div className="kv-grid" style={{ gridTemplateColumns: "repeat(4, 1fr)" }}>
          <div>
            <div className="kv-label">Customer pays</div>
            <div className="mono" style={{ fontSize: 22, letterSpacing: "-0.015em", fontWeight: 500 }}>
              <Money value={allIn} ccy="USD" muteUnit />
            </div>
          </div>
          <div>
            <div className="kv-label">All-in rate</div>
            <div className="kv-value mono" style={{ fontSize: 18 }}>{allInRate.toFixed(4)}</div>
            <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>base {baseRate.toFixed(4)} · +{feeBps} bps</div>
          </div>
          <div>
            <div className="kv-label">Total fee</div>
            <div className="kv-value mono" style={{ fontSize: 18 }}><Money value={feeAbs} ccy="USD" muteUnit /></div>
          </div>
          <div>
            <div className="kv-label">Net profit to Bedrock</div>
            <div className="mono" style={{ fontSize: 18, color: "var(--pos)", fontWeight: 500 }}>
              <Money value={feeAbs * 0.63} ccy="USD" signed signColor muteUnit />
            </div>
            <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>after provider costs</div>
          </div>
        </div>
      </Card>

      {/* Validity + actions */}
      <Card title="Validity & lock">
        <div className="kv-grid" style={{ gridTemplateColumns: "repeat(3, 1fr)" }}>
          <div><div className="kv-label">Rate locked until</div><div className="kv-value mono">Apr 20, 16:45 MSK</div></div>
          <div><div className="kv-label">Quote expires</div><div className="kv-value mono">in 3h 12m</div></div>
          <div><div className="kv-label">Funding deadline</div><div className="kv-value mono">Apr 22 EOD</div></div>
        </div>
        <div className="hstack" style={{ marginTop: 16, gap: 8, justifyContent: "flex-end" }}>
          <Btn variant="ghost" icon="copy">Duplicate calc</Btn>
          <Btn variant="secondary" icon="download">PDF for customer</Btn>
          <Btn variant="secondary" icon="mail">Send to customer</Btn>
          <Btn variant="primary" icon="lock" disabled={!withinPromise}>Accept calculation → Approval</Btn>
        </div>
      </Card>
    </div>
  );
};

const ApprovalPane = () => (
  <div className="stage-pane">
    <Card title="Calculation · locked" sub="Commercial promise frozen — approvers must sign before funding">
      <div className="approval-summary">
        <div><div className="kv-label">Customer pays</div><div className="kv-value-lg mono">13 308 438.00 <span style={{ color: "var(--text-muted)", fontSize: 13 }}>RUB</span></div></div>
        <div><div className="kv-label">Beneficiary receives</div><div className="kv-value-lg mono">140 040.00 <span style={{ color: "var(--text-muted)", fontSize: 13 }}>USD</span></div></div>
        <div><div className="kv-label">Net margin</div><div className="kv-value-lg mono" style={{ color: "var(--pos)" }}>+1 240.00 <span style={{ color: "var(--text-muted)", fontSize: 13 }}>USD</span></div></div>
      </div>
    </Card>

    <Card title="Approvers" sub="Gated by deal size and customer risk tier">
      <div className="vstack" style={{ gap: 10 }}>
        {[
          { role: "Agent", who: "Anna Ermolova · AE desk", status: "approved", when: "Apr 19 · 09:22", note: "Verified pricing vs. policy" },
          { role: "Treasury", who: "Sergey Yanov · Treasury", status: "approved", when: "Apr 20 · 11:48", note: "Liquidity confirmed on Emirates NBD" },
          { role: "Compliance", who: "Marko Kovač · Compliance", status: "pending", when: "—", note: "Awaiting sanctions re-check (expires Apr 25)" },
        ].map((a, i) => (
          <div key={i} className="approval-row">
            <div style={{ width: 110, fontSize: 12, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.05em", fontWeight: 600 }}>{a.role}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 500 }}>{a.who}</div>
              <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 2 }}>{a.note}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <Badge tone={a.status === "approved" ? "pos" : "warn"} dot>{a.status}</Badge>
              <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 4 }}>{a.when}</div>
            </div>
          </div>
        ))}
      </div>
      <div className="hstack" style={{ marginTop: 14, gap: 8, justifyContent: "flex-end" }}>
        <Btn variant="secondary" icon="mail">Nudge Compliance</Btn>
        <Btn variant="primary" icon="check" disabled>Move to Funding (1 approver left)</Btn>
      </div>
    </Card>
  </div>
);

const FundingPane = () => (
  <div className="stage-pane">
    <Card title="Financials" sub="Final, committed — no further edits allowed">
      <div className="kv-grid">
        <div><div className="kv-label">Gross amount</div><div className="kv-value mono" style={{ fontSize: 18 }}><Money value={142_000} ccy="USD" muteUnit /></div></div>
        <div><div className="kv-label">Base rate (USD/RUB)</div><div className="kv-value mono" style={{ fontSize: 18 }}>92.4400</div></div>
        <div><div className="kv-label">Total fee</div><div className="kv-value mono" style={{ fontSize: 18 }}><Money value={1_960} ccy="USD" muteUnit /></div></div>
        <div><div className="kv-label">Net profit</div><div className="kv-value mono" style={{ fontSize: 18, color: "var(--pos)" }}><Money value={1_240} ccy="USD" signed signColor muteUnit /></div></div>
        <div><div className="kv-label">All-in rate to customer</div><div className="kv-value mono" style={{ fontSize: 18 }}>93.7214</div></div>
        <div><div className="kv-label">Margin</div><div className="kv-value mono" style={{ fontSize: 18 }}>1.38%</div></div>
      </div>
    </Card>

    <Card title="Payment legs" sub="3 legs · composed from route RT-081"
      actions={<Btn variant="secondary" size="sm" icon="external">Open treasury workbench</Btn>}>
      <div className="vstack" style={{ gap: 10 }}>
        {[
          { n: 1, from: "Customer · Nordmax", to: "Bedrock RU · Raiffeisen", ccy: "RUB", amount: 13_126_568, status: "received" },
          { n: 2, from: "Bedrock RU · Raiffeisen", to: "Bedrock AE · Emirates NBD", ccy: "USD", amount: 142_000, status: "in-flight" },
          { n: 3, from: "Bedrock AE · Emirates NBD", to: "Lotus Global · FAB", ccy: "USD", amount: 140_040, status: "queued" },
        ].map(l => (
          <div key={l.n} className="hstack" style={{ padding: "12px 14px", border: "1px solid var(--border)", borderRadius: 8, gap: 14 }}>
            <span className="mono" style={{ fontSize: 11, color: "var(--text-muted)", width: 32 }}>LEG {l.n}</span>
            <div style={{ minWidth: 200 }}>
              <div style={{ fontSize: 12.5, fontWeight: 500 }}>{l.from}</div>
              <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>sender</div>
            </div>
            <Icon name="arrow_right" size={14} />
            <div style={{ flex: 1, minWidth: 200 }}>
              <div style={{ fontSize: 12.5, fontWeight: 500 }}>{l.to}</div>
              <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>receiver</div>
            </div>
            <div style={{ textAlign: "right", minWidth: 140 }}>
              <Money value={l.amount} ccy={l.ccy} muteUnit />
            </div>
            <Badge tone={l.status === "received" ? "pos" : l.status === "in-flight" ? "warn" : "default"} dot>{l.status}</Badge>
          </div>
        ))}
      </div>
    </Card>
  </div>
);

const SettledPane = () => (
  <div className="stage-pane">
    <Card title="Closing statement" sub="All legs completed · deal posted to GL on Apr 21 · 16:02">
      <div className="kv-grid" style={{ gridTemplateColumns: "repeat(3, 1fr)" }}>
        <div><div className="kv-label">Settlement date</div><div className="kv-value mono" style={{ fontSize: 15 }}>Apr 21, 2026</div></div>
        <div><div className="kv-label">Actual T+n</div><div className="kv-value mono" style={{ fontSize: 15 }}>T+2</div></div>
        <div><div className="kv-label">Realized margin</div><div className="kv-value mono" style={{ fontSize: 15, color: "var(--pos)" }}>+1 214.00 USD</div></div>
        <div><div className="kv-label">Variance vs. plan</div><div className="kv-value mono" style={{ fontSize: 15 }}>−26.00 USD (−2.1%)</div></div>
        <div><div className="kv-label">Proof attached</div><div className="kv-value mono" style={{ fontSize: 13 }}>MT103 · 3 docs</div></div>
        <div><div className="kv-label">Customer invoice</div><div className="kv-value mono" style={{ fontSize: 13 }}>INV-2201 · paid</div></div>
      </div>
      <div className="hstack" style={{ marginTop: 14, gap: 8, justifyContent: "flex-end" }}>
        <Btn variant="ghost" icon="download">Download pack (PDF)</Btn>
        <Btn variant="secondary" icon="mail">Send statement to customer</Btn>
      </div>
    </Card>
  </div>
);

/* =======================================================
   Deal detail with clickable stages
======================================================= */
const DealDetailScreen = () => {
  const stages = [
    { key: "pricing",     label: "Pricing",     done: true,  note: "Offer accepted" },
    { key: "calculating", label: "Calculating", done: true,  note: "Calc locked" },
    { key: "approval",    label: "Approval",    done: true,  note: "2 of 3 approvers" },
    { key: "funding",     label: "Funding",     done: false, note: "Active", active: true },
    { key: "settled",     label: "Settled",     done: false, note: "Scheduled" },
  ];
  const currentIdx = stages.findIndex(s => s.active);
  const [viewIdx, setViewIdx] = useState(currentIdx);

  const pane = {
    pricing: <PricingPane />,
    calculating: <CalculatingPane />,
    approval: <ApprovalPane />,
    funding: <FundingPane />,
    settled: <SettledPane />,
  }[stages[viewIdx].key];

  return (
    <>
      <div className="detail-header">
        <div className="detail-header-left">
          <div>
            <h1 className="detail-title">
              Nordmax Trading → Lotus Global
              <Badge tone="info" dot>Funding</Badge>
            </h1>
            <div className="detail-id">
              <span>DL-4401</span><span>·</span>
              <span>RU → AE</span><span>·</span>
              <span>Route RT-081 standard</span><span>·</span>
              <span>Due Apr 22</span>
            </div>
          </div>
        </div>
        <div className="page-head-actions">
          <Btn variant="secondary" icon="file">Contract</Btn>
          <Btn variant="secondary" icon="calculator" onClick={() => setViewIdx(stages.findIndex(x => x.key === "calculating"))}>Open calculation</Btn>
          <Btn variant="primary" icon="check">Approve funding</Btn>
        </div>
      </div>

      {/* Clickable stage tabs */}
      <div className="stage-track">
        {stages.map((s, i) => {
          const isActive = i === viewIdx;
          const isCurrent = i === currentIdx;
          return (
            <React.Fragment key={s.key}>
              <button
                type="button"
                className={cx("stage-tab",
                  isActive && "active",
                  s.done && "done",
                  isCurrent && "current",
                  !s.done && !isCurrent && "pending")}
                onClick={() => setViewIdx(i)}>
                <span className="stage-tab-num mono">0{i+1}</span>
                <div className="stage-tab-body">
                  <div className="stage-tab-label">{s.label}</div>
                  <div className="stage-tab-note">{s.note}</div>
                </div>
                <span className="stage-tab-state">
                  {s.done
                    ? <Icon name="check" size={13} />
                    : isCurrent
                      ? <span className="stage-tab-pulse" />
                      : <Icon name="lock" size={12} />}
                </span>
              </button>
              {i < stages.length - 1 && <div className={cx("stage-track-sep", stages[i].done && "done")} />}
            </React.Fragment>
          );
        })}
      </div>

      {viewIdx !== currentIdx && (
        <div className="stage-viewing-banner">
          <Icon name="info" size={13} />
          <span>
            Viewing <b>{stages[viewIdx].label}</b> ({stages[viewIdx].done ? "completed earlier" : "not reached yet"}).
            Current stage is <b>{stages[currentIdx].label}</b>.
          </span>
          <button className="link-btn" onClick={() => setViewIdx(currentIdx)}>Jump to current →</button>
        </div>
      )}

      <div className="detail-grid">
        <div className="detail-main">
          {pane}
        </div>

        <div className="detail-side">
          <Card title="Parties">
            <div className="vstack" style={{ gap: 12 }}>
              <div>
                <div className="kv-label">Customer</div>
                <div style={{ fontSize: 13, fontWeight: 500 }}>Nordmax Trading LLC</div>
                <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>CUS-0042 · RU</div>
              </div>
              <div className="divider" />
              <div>
                <div className="kv-label">Beneficiary</div>
                <div style={{ fontSize: 13, fontWeight: 500 }}>Lotus Global FZE</div>
                <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>CP-2101 · AE</div>
              </div>
              <div className="divider" />
              <div>
                <div className="kv-label">Agent</div>
                <div style={{ fontSize: 13, fontWeight: 500 }}>Anna Ermolova</div>
                <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>Bedrock CRM · AE desk</div>
              </div>
            </div>
          </Card>
          <Card title="Key dates">
            <div className="vstack" style={{ gap: 8, fontSize: 12.5 }}>
              <div className="hstack" style={{ justifyContent: "space-between" }}><span style={{ color: "var(--text-muted)" }}>Created</span><span className="mono">Apr 18 · 10:05</span></div>
              <div className="hstack" style={{ justifyContent: "space-between" }}><span style={{ color: "var(--text-muted)" }}>Offer accepted</span><span className="mono">Apr 18 · 11:40</span></div>
              <div className="hstack" style={{ justifyContent: "space-between" }}><span style={{ color: "var(--text-muted)" }}>Calc locked</span><span className="mono">Apr 19 · 09:10</span></div>
              <div className="hstack" style={{ justifyContent: "space-between" }}><span style={{ color: "var(--text-muted)" }}>Expected settlement</span><span className="mono">Apr 21</span></div>
            </div>
          </Card>
        </div>
      </div>
    </>
  );
};

window.DealsScreen = DealsScreen;
window.DealDetailScreen = DealDetailScreen;
