/* global React, Icon, Btn, IconBtn, Badge, Card, cx, Field, Input, Select, Segmented, Switch, Money, Num, Sparkline */
const { useState } = React;
const { RATE_SOURCES, RATE_DEFAULTS, RATES } = window.BEDROCK_DATA;

const sourceBadge = (s) => {
  const meta = RATE_SOURCES.find(x => x.id === s);
  return meta ? <Badge mono outline>{meta.name.split(" ")[0]}</Badge> : <span className="mono">{s}</span>;
};

const RatesConfigScreen = () => {
  const [overrides, setOverrides] = useState({ "USD/RUB": false });
  const [tab, setTab] = useState("pairs");

  return (
    <>
      <div className="page-head">
        <div>
          <h1 className="page-title">Currency rates · Sources</h1>
          <div className="page-sub">Default source per pair · fallback chain · manual override</div>
        </div>
        <div className="page-head-actions">
          <Btn variant="secondary" icon="refresh">Refresh all</Btn>
          <Btn variant="primary" icon="plus">Add source</Btn>
        </div>
      </div>

      <Segmented value={tab} onChange={setTab} options={[
        { value: "pairs", label: "By pair", count: RATE_DEFAULTS.length },
        { value: "sources", label: "Sources", count: RATE_SOURCES.length },
        { value: "history", label: "Override history" },
      ]} />

      {tab === "pairs" && (
        <div className="table-wrap" style={{ marginTop: 12 }}>
          <table className="table">
            <thead><tr>
              <th>Pair</th>
              <th>Primary source</th>
              <th>Fallback</th>
              <th className="right">Markup (bps)</th>
              <th className="right">Live rate</th>
              <th>Source label</th>
              <th>Override</th>
              <th style={{ width: 40 }}></th>
            </tr></thead>
            <tbody>
              {RATE_DEFAULTS.map(d => {
                const live = RATES.find(r => r.pair === d.pair);
                const isOverride = overrides[d.pair];
                return (
                  <tr key={d.pair}>
                    <td className="mono" style={{ fontWeight: 600 }}>{d.pair}</td>
                    <td>{sourceBadge(d.source)}</td>
                    <td>{sourceBadge(d.fallback)}</td>
                    <td className="right mono">{d.markup_bps}</td>
                    <td className="right">
                      {live ? <Num value={live.mid} digits={4} /> : <span style={{ color: "var(--text-faint)" }}>—</span>}
                    </td>
                    <td style={{ fontSize: 12, color: "var(--text-muted)" }}>
                      {isOverride ? <span style={{ color: "var(--warn)" }}>● manual</span> : live?.source || "—"}
                    </td>
                    <td>
                      <Switch on={!!isOverride} onChange={v => setOverrides({ ...overrides, [d.pair]: v })} />
                    </td>
                    <td><IconBtn name="dots_vertical" /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {tab === "sources" && (
        <div className="rates-source-grid" style={{ marginTop: 12 }}>
          {RATE_SOURCES.map(s => (
            <div key={s.id} className="rates-source-card">
              <div className="hstack" style={{ justifyContent: "space-between" }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{s.name}</div>
                  <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>{s.kind} · {s.region}</div>
                </div>
                <Badge tone={s.kind === "official" ? "info" : s.kind === "exchange" ? "pos" : s.kind === "internal" ? "warn" : "default"} dot>
                  {s.kind}
                </Badge>
              </div>
              <div className="divider" />
              <div className="kv-grid" style={{ gridTemplateColumns: "1fr 1fr", rowGap: 6 }}>
                <div><div className="kv-label">Frequency</div><div className="kv-value" style={{ fontSize: 12 }}>{s.freq}</div></div>
                <div><div className="kv-label">Latency</div><div className="kv-value mono" style={{ fontSize: 12 }}>{s.latency}</div></div>
                <div style={{ gridColumn: "1 / -1" }}>
                  <div className="kv-label">Covers</div>
                  <div className="hstack" style={{ gap: 4, flexWrap: "wrap", marginTop: 4 }}>
                    {s.covers.map(c => <span key={c} className="mono" style={{ fontSize: 10.5, padding: "1px 5px", border: "1px solid var(--border)", borderRadius: 3 }}>{c}</span>)}
                  </div>
                </div>
              </div>
              <div className="hstack" style={{ marginTop: 10, gap: 6 }}>
                <Btn variant="ghost" size="sm" icon="settings">Configure</Btn>
                <Btn variant="ghost" size="sm" icon="refresh">Test</Btn>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === "history" && (
        <Card>
          <table className="table" style={{ border: 0 }}>
            <thead><tr><th>When</th><th>Pair</th><th>Actor</th><th className="right">Old</th><th className="right">New</th><th>Reason</th></tr></thead>
            <tbody>
              {[
                { when: "Apr 20 · 14:02", pair: "USD/RUB", actor: "SY", old: 92.40, nu: 92.44, reason: "manual · end of day alignment" },
                { when: "Apr 19 · 09:15", pair: "AED/RUB", actor: "SY", old: 25.20, nu: 25.16, reason: "CBR unavailable, fallback to investing.com" },
                { when: "Apr 18 · 16:30", pair: "EUR/RUB", actor: "AE", old: 98.79, nu: 98.81, reason: "manual · customer-specific quote" },
              ].map((h, i) => (
                <tr key={i} style={{ cursor: "default" }}>
                  <td className="mono" style={{ fontSize: 12 }}>{h.when}</td>
                  <td className="mono">{h.pair}</td>
                  <td><span className="avatar sm muted">{h.actor}</span></td>
                  <td className="right mono">{h.old.toFixed(4)}</td>
                  <td className="right mono" style={{ fontWeight: 500 }}>{h.nu.toFixed(4)}</td>
                  <td style={{ color: "var(--text-muted)", fontSize: 12 }}>{h.reason}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </>
  );
};

// Manual override dialog shown inline when switch toggled (simplified — just a form card)
const RateOverridePanel = ({ pair = "USD/RUB", current = 92.44 }) => {
  const [val, setVal] = useState(current);
  const [ttl, setTtl] = useState("until-eod");
  return (
    <Card title={"Manual override · " + pair} sub="Takes precedence over live feeds until expiry">
      <div className="field-row three">
        <Field label="Rate" required>
          <Input type="number" step="0.0001" value={val} onChange={e => setVal(+e.target.value)} />
        </Field>
        <Field label="Valid until">
          <Select value={ttl} onChange={e => setTtl(e.target.value)}>
            <option value="until-eod">End of day (MSK)</option>
            <option value="until-eow">End of week</option>
            <option value="1h">1 hour</option>
            <option value="manual">Until manually cleared</option>
          </Select>
        </Field>
        <Field label="Scope">
          <Select><option>All deals</option><option>Only new deals</option><option>Specific customer</option></Select>
        </Field>
      </div>
      <div style={{ marginTop: 12 }}>
        <Field label="Reason (logged)" required>
          <Input placeholder="Customer-specific quote / feed outage / EOD alignment…" />
        </Field>
      </div>
    </Card>
  );
};

window.RatesConfigScreen = RatesConfigScreen;
window.RateOverridePanel = RateOverridePanel;
