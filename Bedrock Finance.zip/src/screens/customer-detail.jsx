/* global React, Icon, Btn, IconBtn, Badge, Segmented, Tabs, Card, CardSaveFoot, cx, CountryPill, Money, Field, Input, Select, Checkbox, Switch, BilingualToolbar, BilingualField */
const { useState } = React;

// The CORE pattern: resource detail with tabs, bilingual general form, card-level save/cancel.
// Same component works in both CRM (customer) and Finance (counterparty view).

const CustomerDetailScreen = ({ app = "finance", bilingualLayout = "toggle", onBack }) => {
  const [tab, setTab] = useState("general");
  const [lang, setLang] = useState("all");
  const [translating, setTranslating] = useState(false);

  const [legalName, setLegalName] = useState({
    base: "Severnaya Stal JSC",
    locales: { ru: "ОАО «Северная Сталь»", en: "Severnaya Stal JSC" },
  });
  const [shortName, setShortName] = useState({
    base: "Severnaya Stal",
    locales: { ru: "Северная Сталь", en: "Severnaya Stal" },
  });
  const [address, setAddress] = useState({
    base: "12 Naberezhnaya St., Saint-Petersburg, Russia, 198103",
    locales: {
      ru: "198103, Санкт-Петербург, Набережная ул., д. 12",
      en: "12 Naberezhnaya St., Saint-Petersburg, Russia, 198103",
    },
  });
  const [description, setDescription] = useState({
    base: "",
    locales: { ru: "", en: "" },
  });

  const [dirtyGeneral, setDirtyGeneral] = useState(false);
  const setField = (setter) => (v) => { setter(v); setDirtyGeneral(true); };

  const completeness = (() => {
    const fields = [legalName, shortName, address, description];
    let filled = 0, total = 0;
    fields.forEach(f => {
      total += 2;
      if (f?.locales?.ru) filled++;
      if (f?.locales?.en) filled++;
    });
    return filled / total;
  })();

  const translateAll = () => {
    setTranslating(true);
    setTimeout(() => {
      const autoFill = (o, from, to, suffix) => {
        const src = o.locales[from];
        if (src && !o.locales[to]) {
          return { ...o, locales: { ...o.locales, [to]: src + suffix } };
        }
        return o;
      };
      setLegalName(x => autoFill(x, "ru", "en", ""));
      setShortName(x => autoFill(x, "ru", "en", ""));
      setAddress(x => autoFill(x, "ru", "en", ""));
      setDescription(x => {
        const ruSrc = x.locales.ru; const enSrc = x.locales.en;
        if (ruSrc && !enSrc) return { ...x, locales: { ...x.locales, en: ruSrc + " (auto)" } };
        if (enSrc && !ruSrc) return { ...x, locales: { ...x.locales, ru: enSrc + " (авто)" } };
        return x;
      });
      setTranslating(false);
      setDirtyGeneral(true);
    }, 700);
  };

  return (
    <>
      <div className="detail-header">
        <div className="detail-header-left">
          <span className="avatar lg muted">SS</span>
          <div>
            <h1 className="detail-title">
              Severnaya Stal JSC
              <Badge tone="pos" dot>Active</Badge>
              <Badge tone="default" mono outline>Enterprise</Badge>
            </h1>
            <div className="detail-id">
              <span>CUS-0048</span>
              <span>·</span>
              <CountryPill code="RU" />
              <span>·</span>
              <span>TIN 7830004567</span>
              <span>·</span>
              <span>Owner SY</span>
            </div>
          </div>
        </div>
        <div className="page-head-actions">
          <Btn variant="ghost" icon="activity">Activity</Btn>
          <Btn variant="secondary" icon="external">Open in {app === "finance" ? "CRM" : "Finance"}</Btn>
          <Btn variant="secondary" icon="dots_vertical" />
        </div>
      </div>

      <Tabs value={tab} onChange={setTab} items={[
        { value: "general", label: "General", icon: "info" },
        { value: "counterparties", label: "Counterparties", icon: "briefcase", count: 4 },
        { value: "requisites", label: "Requisites", icon: "wallet", count: 6 },
        { value: "contacts", label: "Contacts", icon: "users", count: 3 },
        { value: "agreements", label: "Agreements", icon: "file", count: 2 },
        { value: "documents", label: "Documents", icon: "folder", count: 12 },
        { value: "deals", label: "Deals", icon: "activity", count: 18 },
        { value: "audit", label: "Audit log", icon: "activity" },
      ]} />

      {tab === "general" && (
        <div className="detail-grid">
          <div className="detail-main">
            <BilingualToolbar
              lang={lang} onLang={setLang}
              completeness={completeness}
              onTranslateAll={translateAll}
              translating={translating}
            />

            <Card
              title="Legal information"
              sub="Bilingual fields — filled in Russian and English for contracts and documents"
              actions={<>
                <Btn variant="ghost" size="sm" icon="copy">Copy</Btn>
                <Btn variant="ghost" size="sm" icon="dots_vertical" />
              </>}
              foot={<CardSaveFoot dirty={dirtyGeneral}
                onSave={() => setDirtyGeneral(false)}
                onReset={() => setDirtyGeneral(false)} />}
            >
              <div className="vstack" style={{ gap: 14 }}>
                <BilingualField layout={bilingualLayout} lang={lang}
                  label="Legal name" required
                  value={legalName} onChange={setField(setLegalName)}
                  placeholder="Full legal name" />
                <BilingualField layout={bilingualLayout} lang={lang}
                  label="Short name"
                  value={shortName} onChange={setField(setShortName)}
                  placeholder="Display name" />

                <div className="field-row three">
                  <Field label="TIN / INN" required>
                    <Input defaultValue="7830004567" />
                  </Field>
                  <Field label="Country of incorporation" required>
                    <Select defaultValue="RU">
                      <option value="RU">Russia</option>
                      <option value="AE">United Arab Emirates</option>
                      <option value="DE">Germany</option>
                      <option value="GB">United Kingdom</option>
                    </Select>
                  </Field>
                  <Field label="Registration number">
                    <Input defaultValue="1027800000123" />
                  </Field>
                </div>

                <BilingualField layout={bilingualLayout} lang={lang}
                  label="Registered address" required multiline
                  value={address} onChange={setField(setAddress)}
                  placeholder="Street, city, postal code, country" />

                <BilingualField layout={bilingualLayout} lang={lang}
                  label="Description"
                  value={description} onChange={setField(setDescription)}
                  placeholder="Short description for internal use"
                  multiline />
              </div>
            </Card>

            <Card title="Commercial" sub="Segment, owner, relationships"
              foot={<CardSaveFoot dirty={false} />}>
              <div className="field-row three">
                <Field label="Segment">
                  <Select defaultValue="enterprise">
                    <option value="sme">SME</option>
                    <option value="mid">Mid-market</option>
                    <option value="enterprise">Enterprise</option>
                  </Select>
                </Field>
                <Field label="Account owner">
                  <Select defaultValue="sy">
                    <option value="sy">Sergey Yermolov</option>
                    <option value="ae">Anna Ermolova</option>
                    <option value="mk">Maxim Kolesov</option>
                  </Select>
                </Field>
                <Field label="Onboarded">
                  <Input defaultValue="2023-08-14" />
                </Field>
              </div>
              <div className="field-row" style={{ marginTop: 12 }}>
                <Field label="Risk tier">
                  <Select defaultValue="a">
                    <option value="a">A — Standard</option>
                    <option value="b">B — Enhanced</option>
                    <option value="c">C — High</option>
                  </Select>
                </Field>
                <Field label="KYC status">
                  <div className="hstack">
                    <Badge tone="pos" dot>Completed</Badge>
                    <span className="mono" style={{ fontSize: 12, color: "var(--text-muted)" }}>reviewed 2026-02-11</span>
                  </div>
                </Field>
              </div>
            </Card>

            <Card title="Flags" sub="Permissions and limits">
              <div className="vstack" style={{ gap: 10 }}>
                {[
                  { k: "allow_overdraft", label: "Allow overdraft up to limit", on: true },
                  { k: "auto_fx", label: "Automatic FX pricing from MOEX+EBS", on: true },
                  { k: "portal", label: "Customer Portal access", on: true },
                  { k: "manual_approve", label: "Manual approval on deals > $250k", on: false },
                ].map(f => (
                  <div key={f.k} className="hstack" style={{ justifyContent: "space-between", padding: "6px 0" }}>
                    <div>
                      <div style={{ fontSize: 13 }}>{f.label}</div>
                    </div>
                    <Switch on={f.on} />
                  </div>
                ))}
              </div>
            </Card>
          </div>

          <div className="detail-side">
            <Card title="Balance summary">
              <div className="vstack" style={{ gap: 10 }}>
                <div>
                  <div className="eyebrow">Primary balance</div>
                  <div className="mono" style={{ fontSize: 22, fontWeight: 500, letterSpacing: "-0.02em" }}>
                    <Money value={2_410_998.74} ccy="USD" />
                  </div>
                </div>
                <div className="divider" />
                <div className="kv-grid" style={{ gridTemplateColumns: "1fr 1fr" }}>
                  <div>
                    <div className="kv-label">Credit limit</div>
                    <div className="kv-value mono"><Money value={5_000_000} ccy="USD" muteUnit /></div>
                  </div>
                  <div>
                    <div className="kv-label">Utilization</div>
                    <div className="kv-value mono">48.2%</div>
                  </div>
                  <div>
                    <div className="kv-label">Open deals</div>
                    <div className="kv-value mono">4</div>
                  </div>
                  <div>
                    <div className="kv-label">Past 90d volume</div>
                    <div className="kv-value mono"><Money value={14_220_000} ccy="USD" muteUnit /></div>
                  </div>
                </div>
              </div>
            </Card>

            <Card title="Recent activity">
              <div className="vstack" style={{ gap: 0 }}>
                {[
                  { who: "AE", what: "approved DL-4405", when: "2h ago" },
                  { who: "SY", what: "updated requisites (REQ-5017)", when: "yesterday" },
                  { who: "MK", what: "added counterparty Delta Shipping", when: "3d ago" },
                  { who: "AE", what: "attached KYC packet v3", when: "1w ago" },
                ].map((a, i) => (
                  <div key={i} className="hstack" style={{ padding: "8px 0", borderBottom: i < 3 ? "1px solid var(--divider)" : "none" }}>
                    <span className="avatar sm muted">{a.who}</span>
                    <div style={{ flex: 1, fontSize: 12.5 }}>{a.what}</div>
                    <span className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>{a.when}</span>
                  </div>
                ))}
              </div>
            </Card>

            <Card title="Agreements">
              <div className="vstack" style={{ gap: 8 }}>
                <div className="hstack" style={{ justifyContent: "space-between" }}>
                  <div>
                    <div style={{ fontSize: 12.5, fontWeight: 500 }}>Master service agreement</div>
                    <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>AGR-0114 · v3 · 2025-01-12</div>
                  </div>
                  <Badge tone="pos" dot>Active</Badge>
                </div>
                <div className="divider" />
                <div className="hstack" style={{ justifyContent: "space-between" }}>
                  <div>
                    <div style={{ fontSize: 12.5, fontWeight: 500 }}>FX pricing addendum</div>
                    <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>AGR-0114-A1 · v2</div>
                  </div>
                  <Badge tone="pos" dot>Active</Badge>
                </div>
              </div>
            </Card>
          </div>
        </div>
      )}

      {tab === "counterparties" && <window.CounterpartiesTab />}

      {tab === "requisites" && <window.RequisitesTab />}

      {tab !== "general" && tab !== "counterparties" && tab !== "requisites" && (
        <Card>
          <div style={{ padding: "40px 0", textAlign: "center", color: "var(--text-muted)" }}>
            <div className="eyebrow" style={{ marginBottom: 8 }}>{tab} tab</div>
            <div style={{ fontSize: 13 }}>Uses the same pattern: list → per-row card → card-level save/cancel.</div>
          </div>
        </Card>
      )}
    </>
  );
};

window.CustomerDetailScreen = CustomerDetailScreen;
