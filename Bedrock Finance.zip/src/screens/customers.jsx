/* global React, Icon, Btn, IconBtn, Badge, Segmented, cx, CountryPill, Money, CustomerCreateDialog */
const { useState, useMemo } = React;
const { CUSTOMERS } = window.BEDROCK_DATA;

const CustomersScreen = ({ onOpen, app = "finance" }) => {
  const [q, setQ] = useState("");
  const [seg, setSeg] = useState("all");
  const [createOpen, setCreateOpen] = useState(false);

  const rows = useMemo(() => {
    const s = q.trim().toLowerCase();
    return CUSTOMERS.filter(c => {
      if (seg !== "all" && c.status !== seg) return false;
      if (!s) return true;
      return [c.base, c.ru, c.en, c.id, c.tin].some(v => v.toLowerCase().includes(s));
    });
  }, [q, seg]);

  const counts = {
    all: CUSTOMERS.length,
    active: CUSTOMERS.filter(c => c.status === "active").length,
    onboarding: CUSTOMERS.filter(c => c.status === "onboarding").length,
    suspended: CUSTOMERS.filter(c => c.status === "suspended").length,
  };

  return (
    <>
      <div className="page-head">
        <div>
          <h1 className="page-title">Customers</h1>
          <div className="page-sub">{CUSTOMERS.length} total · 4 awaiting onboarding</div>
        </div>
        <div className="page-head-actions">
          <Btn variant="ghost" icon="download">Export</Btn>
          <Btn variant="secondary" icon="columns">Columns</Btn>
          <Btn variant="primary" icon="plus" onClick={() => setCreateOpen(true)}>New customer</Btn>
        </div>
      </div>

      <div className="table-wrap">
        <div className="table-toolbar">
          <div className="table-toolbar-left">
            <Segmented value={seg} onChange={setSeg} options={[
              { value: "all", label: "All", count: counts.all },
              { value: "active", label: "Active", count: counts.active },
              { value: "onboarding", label: "Onboarding", count: counts.onboarding },
              { value: "suspended", label: "Suspended", count: counts.suspended },
            ]} />
            <div className="input-group" style={{ width: 260 }}>
              <span className="input-group-prefix"><Icon name="search" size={13} /></span>
              <input className="input" placeholder="Name, TIN, ID…" value={q} onChange={e => setQ(e.target.value)} />
            </div>
            <Btn variant="ghost" size="sm" icon="filter">Filters</Btn>
          </div>
          <div className="table-toolbar-right">
            <span className="mono" style={{ fontSize: 11.5, color: "var(--text-muted)" }}>{rows.length} / {CUSTOMERS.length}</span>
            <IconBtn name="refresh" title="Refresh" bordered />
          </div>
        </div>

        <table className="table">
          <thead>
            <tr>
              <th style={{ width: 40 }}></th>
              <th style={{ width: 110 }}>ID</th>
              <th>Name</th>
              <th style={{ width: 80 }}>Country</th>
              <th style={{ width: 120 }}>Segment</th>
              <th style={{ width: 120 }}>Status</th>
              <th style={{ width: 70 }}>Owner</th>
              <th className="right" style={{ width: 180 }}>Balance</th>
              <th style={{ width: 120 }}>Last activity</th>
              <th style={{ width: 60 }}></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((c, i) => (
              <tr key={c.id} onClick={() => onOpen?.(c.id)}>
                <td><input type="checkbox" onClick={e => e.stopPropagation()} /></td>
                <td className="mono muted">{c.id}</td>
                <td>
                  <div style={{ fontWeight: 500 }}>{c.en}</div>
                  <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>{c.ru}</div>
                </td>
                <td><CountryPill code={c.country} /></td>
                <td style={{ color: "var(--text-secondary)" }}>{c.segment}</td>
                <td>
                  {c.status === "active" && <Badge tone="pos" dot>Active</Badge>}
                  {c.status === "onboarding" && <Badge tone="warn" dot>Onboarding</Badge>}
                  {c.status === "suspended" && <Badge tone="neg" dot>Suspended</Badge>}
                </td>
                <td><span className="avatar sm muted">{c.ownerInitials}</span></td>
                <td className="right">
                  <Money value={c.balance} ccy={c.ccy} signed />
                </td>
                <td style={{ color: "var(--text-muted)", fontSize: 12 }}>{c.lastDeal}</td>
                <td>
                  <span className="row-actions">
                    <IconBtn name="external" title="Open" />
                    <IconBtn name="dots_vertical" title="More" />
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="table-foot">
          <span>Showing 1–{rows.length} of {CUSTOMERS.length}</span>
          <div className="hstack">
            <Btn variant="ghost" size="sm" icon="chev_right" title="Prev">Prev</Btn>
            <span className="mono" style={{ fontSize: 11.5 }}>1 / 1</span>
            <Btn variant="ghost" size="sm" iconRight="chev_right">Next</Btn>
          </div>
        </div>
      </div>

      <CustomerCreateDialog open={createOpen} onClose={() => setCreateOpen(false)} onCreated={() => setCreateOpen(false)} />
    </>
  );
};

window.CustomersScreen = CustomersScreen;
