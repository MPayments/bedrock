/* global React, Card, Btn, Badge, Icon, Money */

const SystemScreen = () => (
  <>
    <div className="page-head">
      <div>
        <h1 className="page-title">Design system</h1>
        <div className="page-sub">Tokens, type, components — shared by Portal, CRM and Finance</div>
      </div>
    </div>

    <div className="detail-grid two-col-equal">
      <Card title="Typography" sub="Geist Sans for UI, Geist Mono for money & IDs (tabular)">
        <div className="vstack" style={{ gap: 14 }}>
          <div>
            <div className="eyebrow">Display · 28 / 600</div>
            <div style={{ fontSize: 28, fontWeight: 600, letterSpacing: "-0.02em" }}>Bedrock payments, clear.</div>
          </div>
          <div>
            <div className="eyebrow">Title · 18 / 600</div>
            <div style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-0.01em" }}>Quarterly FX exposure</div>
          </div>
          <div>
            <div className="eyebrow">Body · 13 / 400</div>
            <div style={{ fontSize: 13 }}>Every workflow lives inside a predictable list → detail → card shell.</div>
          </div>
          <div>
            <div className="eyebrow">Mono · 13 / 500 tnum</div>
            <div className="mono" style={{ fontSize: 13, fontWeight: 500 }}>2 410 998.74 USD · 92.4400 · CUS-0048</div>
          </div>
        </div>
      </Card>

      <Card title="Neutral scale" sub="Cool neutrals — hue 250, chroma ≤ 0.005">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(10, 1fr)", gap: 2 }}>
          {["ink-0","ink-50","ink-100","ink-150","ink-200","ink-250","ink-300","ink-500","ink-700","ink-900"].map(k => (
            <div key={k} style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              <div style={{ height: 48, background: `var(--${k})`, border: "1px solid var(--border)", borderRadius: 6 }} />
              <span className="mono" style={{ fontSize: 10, color: "var(--text-muted)" }}>{k.replace("ink-", "")}</span>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 16 }} className="eyebrow">Semantic · only for signals</div>
        <div className="hstack" style={{ gap: 8, marginTop: 8, flexWrap: "wrap" }}>
          <Badge tone="pos" dot>positive</Badge>
          <Badge tone="neg" dot>negative</Badge>
          <Badge tone="warn" dot>warning</Badge>
          <Badge tone="info" dot>info</Badge>
        </div>
      </Card>

      <Card title="Buttons">
        <div className="hstack" style={{ gap: 10, flexWrap: "wrap" }}>
          <Btn variant="primary" icon="check">Primary</Btn>
          <Btn variant="secondary" icon="plus">Secondary</Btn>
          <Btn variant="ghost" icon="filter">Ghost</Btn>
          <Btn variant="danger" icon="trash">Danger</Btn>
        </div>
        <div className="hstack" style={{ gap: 10, marginTop: 10 }}>
          <Btn variant="primary" size="sm">Sm</Btn>
          <Btn variant="primary">Md</Btn>
          <Btn variant="primary" size="lg">Lg</Btn>
        </div>
      </Card>

      <Card title="Money treatment" sub="Tabular, thin-space separators, dimmed decimal + unit; credit/debit color">
        <div className="vstack" style={{ gap: 6, fontSize: 18 }}>
          <Money value={2_410_998.74} ccy="USD" muteUnit />
          <Money value={-8_124.5} ccy="EUR" signed signColor muteUnit />
          <Money value={128_450.22} ccy="USD" signed signColor muteUnit />
          <Money value={0} ccy="AED" muteUnit />
        </div>
      </Card>
    </div>
  </>
);

window.SystemScreen = SystemScreen;
