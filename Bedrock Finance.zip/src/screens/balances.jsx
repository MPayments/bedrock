/* global React, Icon, Btn, IconBtn, Badge, Segmented, Card, cx, CountryPill, Money, Sparkline */
const { useState } = React;
const { BALANCES } = window.BEDROCK_DATA;

const BalancesScreen = () => {
  const totals = BALANCES.reduce((a, b) => {
    a[b.ccy] = (a[b.ccy] || 0) + b.available;
    return a;
  }, {});

  return (
    <>
      <div className="page-head">
        <div>
          <h1 className="page-title">Balances</h1>
          <div className="page-sub">6 accounts across 4 holding entities · USD equivalent $24.6M</div>
        </div>
        <div className="page-head-actions">
          <Btn variant="ghost" icon="refresh">Refresh</Btn>
          <Btn variant="secondary" icon="download">Export statement</Btn>
          <Btn variant="primary" icon="plus">New transfer</Btn>
        </div>
      </div>

      <div className="kpi-grid" style={{ gridTemplateColumns: "repeat(5, 1fr)" }}>
        {[
          { l: "Available USD equiv", v: "24.6M", d: "+2.1%" },
          { l: "Blocked", v: "1.2M", d: "4.9%" },
          { l: "Net position USD", v: "6.3M" },
          { l: "Net position EUR", v: "3.1M" },
          { l: "Net position RUB", v: "320M" },
        ].map(k => (
          <div className="kpi" key={k.l}>
            <div className="kpi-label">{k.l}</div>
            <div className="kpi-value">{k.v}</div>
            {k.d && <div className="kpi-delta pos"><Icon name="arrow_up_right" size={11} />{k.d}</div>}
          </div>
        ))}
      </div>

      <div className="table-wrap">
        <div className="table-toolbar">
          <div className="table-toolbar-left">
            <Segmented value="all" onChange={() => {}} options={[
              { value: "all", label: "All accounts", count: BALANCES.length },
              { value: "usd", label: "USD" },
              { value: "eur", label: "EUR" },
              { value: "rub", label: "RUB" },
            ]} />
            <Btn variant="ghost" size="sm" icon="filter">By entity</Btn>
          </div>
          <div className="table-toolbar-right">
            <span className="mono" style={{ fontSize: 11.5, color: "var(--text-muted)" }}>updated 34s ago</span>
          </div>
        </div>
        <table className="table">
          <thead><tr>
            <th>Entity / account</th><th>CCY</th>
            <th className="right">Available</th>
            <th className="right">Blocked</th>
            <th className="right">Total</th>
            <th>Trend 12w</th><th style={{ width: 40 }}></th>
          </tr></thead>
          <tbody>
            {BALANCES.map((b, i) => (
              <tr key={i}>
                <td>
                  <div style={{ fontWeight: 500 }}>{b.org}</div>
                  <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>{b.account}</div>
                </td>
                <td><span className="mono" style={{ fontSize: 11.5 }}>{b.ccy}</span></td>
                <td className="right"><Money value={b.available} ccy={b.ccy} muteUnit /></td>
                <td className="right"><Money value={b.blocked} ccy={b.ccy} muteUnit showZero /></td>
                <td className="right" style={{ fontWeight: 500 }}><Money value={b.total} ccy={b.ccy} muteUnit /></td>
                <td style={{ width: 120 }}><Sparkline data={b.spark} width={100} height={24} /></td>
                <td><IconBtn name="dots_vertical" /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

window.BalancesScreen = BalancesScreen;
