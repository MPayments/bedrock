/* global React, Icon, Btn, IconBtn, Badge, Card, Field, Input, Select, Segmented, Modal, cx, CountryPill, RequisiteForm, buildRequisiteDraft */
const { useState: useStateReq } = React;
const { REQUISITES, PROVIDERS } = window.BEDROCK_DATA;

/* ================================================================
   Requisites tab — CRM customer detail
   - Shows counterparty-owned requisites for this customer
   - Adds and edits via the shared <RequisiteForm>, with the holder
     locked to the selected counterparty
================================================================ */

const REQ_STATUS = {
  verified: { tone: "pos", label: "Verified" },
  pending:  { tone: "warn", label: "Pending" },
  expired:  { tone: "neg", label: "Expired" },
  draft:    { tone: "default", label: "Draft" },
};

const providerOf = (r) => PROVIDERS.find(p => p.id === r.providerId);
const kindOf = (r) => providerOf(r)?.kind;

const reqDisplayNumber = (r) =>
  r.iban || r.account || r.walletAddress || r.walletId || r.cardMasked || r.deskRef || "—";

const reqKindMeta = (r) => {
  const k = kindOf(r);
  const meta = window.REQUISITE_KIND_META?.[k];
  return meta || { short: k || "—", icon: "wallet" };
};

const reqSecondary = (r) => {
  const p = providerOf(r);
  const k = kindOf(r);
  if (k === "ru_bank") return `BIC ${p?.bic || "—"}`;
  if (k === "swift_bank") return `SWIFT ${p?.swift || "—"}`;
  if (k === "blockchain") return `Network ${p?.network || "—"}`;
  if (k === "cash_desk") return p?.address || "";
  return "";
};

const RequisitesTab = () => {
  const counterparties = (window.SEED_COUNTERPARTIES || []);
  const cpIds = counterparties.map(c => c.id);

  // Seed from platform data, filtered to this customer's counterparties
  const [items, setItems] = useStateReq(() =>
    REQUISITES.filter(r => r.holderRef?.kind === "counterparty" && cpIds.includes(r.holderRef.id))
  );
  const [filter, setFilter] = useStateReq("all");
  const [query, setQuery] = useStateReq("");
  const [expanded, setExpanded] = useStateReq(() => new Set(["CP-2101", "CP-2102"]));
  const [editReq, setEditReq] = useStateReq(null);
  const [addForCp, setAddForCp] = useStateReq(null);

  const toggle = (cpId) => {
    const next = new Set(expanded);
    next.has(cpId) ? next.delete(cpId) : next.add(cpId);
    setExpanded(next);
  };

  // Group by counterparty
  const grouped = counterparties.map(cp => ({
    cp,
    reqs: items.filter(r => {
      if (r.holderRef?.id !== cp.id) return false;
      if (filter !== "all" && r.status !== filter) return false;
      if (query) {
        const q = query.toLowerCase();
        const num = reqDisplayNumber(r).replace(/\s/g, "").toLowerCase();
        const pname = providerOf(r)?.name.toLowerCase() || "";
        return (r.nickname || "").toLowerCase().includes(q) ||
               pname.includes(q) ||
               num.includes(q.replace(/\s/g, ""));
      }
      return true;
    }),
  })).filter(g => g.reqs.length > 0 || filter === "all");

  const total = items.length;
  const verified = items.filter(r => r.status === "verified").length;
  const pending = items.filter(r => r.status === "pending").length;
  const expired = items.filter(r => r.status === "expired").length;

  return (
    <>
      <Card
        title="Requisites"
        sub={`${total} payment requisites across ${counterparties.length} counterparties · ${verified} verified, ${pending} pending, ${expired} expired`}
        actions={
          <Btn variant="primary" size="sm" icon="plus" onClick={() => setAddForCp(counterparties[0]?.id)}>
            Add requisite
          </Btn>
        }
      >
        <div className="req-summary">
          {[
            { label: "Total", value: total, tone: "default" },
            { label: "Verified", value: verified, tone: "pos" },
            { label: "Pending", value: pending, tone: "warn" },
            { label: "Expired", value: expired, tone: "neg" },
          ].map(s => (
            <div key={s.label} className="req-summary-cell">
              <div className={cx("req-summary-value mono", s.tone)}>{s.value}</div>
              <div className="req-summary-label">{s.label}</div>
            </div>
          ))}
        </div>

        <div className="hstack" style={{ gap: 12, marginTop: 16 }}>
          <Segmented
            value={filter}
            onChange={setFilter}
            options={[
              { value: "all", label: "All", count: total },
              { value: "verified", label: "Verified", count: verified },
              { value: "pending", label: "Pending", count: pending },
              { value: "expired", label: "Expired", count: expired },
            ]}
          />
          <div style={{ flex: 1 }}>
            <Input prefix={<Icon name="search" size={12} />} placeholder="Search by nickname, provider, IBAN…" value={query} onChange={e => setQuery(e.target.value)} />
          </div>
        </div>
      </Card>

      <div className="vstack" style={{ gap: 10 }}>
        {grouped.map(({ cp, reqs }) => {
          const isOpen = expanded.has(cp.id);
          return (
            <div key={cp.id} className="req-group">
              <button
                type="button"
                className="req-group-head"
                onClick={() => toggle(cp.id)}
              >
                <Icon name={isOpen ? "chevron_down" : "chevron_right"} size={14} />
                <Icon name={(window.CP_KIND_ICON || {})[cp.kind] || "briefcase"} size={14} style={{ color: "var(--text-muted)" }} />
                <div className="req-group-head-text">
                  <div className="req-group-name">{cp.name}</div>
                  <div className="req-group-meta">
                    <CountryPill code={cp.country} />
                    <span className="mono muted">{cp.id}</span>
                    <span className="muted">·</span>
                    <span className="muted">{reqs.length} requisite{reqs.length === 1 ? "" : "s"}</span>
                  </div>
                </div>
                <div
                  onClick={e => { e.stopPropagation(); setAddForCp(cp.id); }}
                  className="btn btn-ghost btn-sm"
                  style={{ display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer" }}
                >
                  <Icon name="plus" size={12} /> Add for {cp.country}
                </div>
              </button>

              {isOpen && (
                <div className="req-group-body">
                  {reqs.length === 0 ? (
                    <div className="req-empty">
                      <Icon name="wallet" size={20} style={{ color: "var(--text-faint)" }} />
                      <div>No requisites yet.</div>
                      <Btn variant="secondary" size="sm" icon="plus" onClick={() => setAddForCp(cp.id)}>Add first requisite</Btn>
                    </div>
                  ) : (
                    <div className="req-list">
                      {reqs.map(r => {
                        const p = providerOf(r);
                        const meta = reqKindMeta(r);
                        const status = REQ_STATUS[r.status] || REQ_STATUS.draft;
                        return (
                          <div key={r.id} className="req-card" onClick={() => setEditReq(r)}>
                            <div className="req-card-head">
                              <div style={{ display: "flex", alignItems: "center", gap: 8, minWidth: 0, flex: 1 }}>
                                {r.primary && <Badge tone="info" outline>Primary</Badge>}
                                <div className="req-card-name">{r.nickname}</div>
                              </div>
                              <Badge tone={status.tone} dot>{status.label}</Badge>
                            </div>
                            <div className="req-card-id">
                              <span className="mono muted">{r.id}</span>
                              <span className="muted">·</span>
                              <Icon name={meta.icon} size={11} />
                              <span className="muted">{meta.short}</span>
                              <span className="muted">·</span>
                              <span className="mono">{r.ccy}</span>
                            </div>
                            <div className="req-card-body">
                              <div className="req-card-provider">
                                <div className="req-card-provider-name">{p?.name || "—"}</div>
                                {reqSecondary(r) && (
                                  <div className="mono muted" style={{ fontSize: 11 }}>{reqSecondary(r)}</div>
                                )}
                              </div>
                              <div className="req-card-account">
                                <div className="mono" style={{ fontSize: 12.5 }}>{reqDisplayNumber(r)}</div>
                                {r.verifiedAt && <div className="mono muted" style={{ fontSize: 10.5 }}>verified {r.verifiedAt}</div>}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <RequisiteEditDialog
        open={!!editReq}
        item={editReq}
        onClose={() => setEditReq(null)}
        onSave={(next) => {
          setItems(items.map(i => i.id === editReq.id ? { ...i, ...next } : i));
          setEditReq(null);
        }}
      />

      <RequisiteAddDialog
        open={!!addForCp}
        cp={counterparties.find(c => c.id === addForCp)}
        onClose={() => setAddForCp(null)}
        onCreate={(req) => {
          setItems([
            {
              ...req,
              id: `REQ-${5200 + items.length + 1}`,
              status: "pending",
            },
            ...items,
          ]);
          setAddForCp(null);
        }}
      />
    </>
  );
};

/* ================================================================
   Add / edit dialogs — wrap the shared <RequisiteForm>
================================================================ */
const RequisiteAddDialog = ({ open, cp, onClose, onCreate }) => {
  const [draft, setDraft] = useStateReq(null);

  React.useEffect(() => {
    if (!cp) { setDraft(null); return; }
    setDraft(buildRequisiteDraft({
      holderRef: { kind: "counterparty", id: cp.id, name: cp.name, country: cp.country },
    }));
  }, [cp?.id]);

  if (!cp || !draft) return null;

  const canSave = draft.nickname && draft.ccy && (
    draft.iban || draft.account || draft.walletAddress || draft.walletId || draft.cardMasked || draft.deskRef || draft.mid
  );

  return (
    <Modal
      open={open}
      onClose={onClose}
      size="lg"
      title={`Add requisite for ${cp.name}`}
      sub={`${cp.country} · ${cp.tin || cp.id}`}
      foot={
        <>
          <div style={{ fontSize: 12, color: "var(--text-muted)" }}>
            {canSave ? "Will be created as pending · 1.00 test transfer before activation" : "Fill required fields to continue"}
          </div>
          <div className="hstack" style={{ gap: 8 }}>
            <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
            <Btn variant="primary" icon="check" disabled={!canSave} onClick={() => onCreate(draft)}>Add requisite</Btn>
          </div>
        </>
      }
    >
      <RequisiteForm
        value={draft}
        onChange={setDraft}
        holderLock={{ kind: "counterparty", id: cp.id, name: cp.name, country: cp.country }}
        compact
      />
    </Modal>
  );
};

const RequisiteEditDialog = ({ open, item, onClose, onSave }) => {
  const [draft, setDraft] = useStateReq({});
  React.useEffect(() => { if (item) setDraft({ ...item }); }, [item?.id]);
  if (!item) return null;
  const status = REQ_STATUS[item.status] || REQ_STATUS.draft;

  return (
    <Modal
      open={open}
      onClose={onClose}
      size="lg"
      title={`Edit · ${item.nickname}`}
      sub={`${item.id} · ${item.holderRef?.name} · ${item.ccy}`}
      foot={
        <>
          <div className="hstack" style={{ gap: 10 }}>
            <Badge tone={status.tone} dot>{status.label}</Badge>
            {item.verifiedAt && <span className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>verified {item.verifiedAt}</span>}
          </div>
          <div className="hstack" style={{ gap: 8 }}>
            <Btn variant="ghost" icon="archive">Archive</Btn>
            <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
            <Btn variant="primary" icon="check" onClick={() => onSave(draft)}>Save changes</Btn>
          </div>
        </>
      }
    >
      <RequisiteForm
        value={draft}
        onChange={setDraft}
        holderLock={item.holderRef}
        compact
      />
    </Modal>
  );
};

window.RequisitesTab = RequisitesTab;
