/* global React, Icon, Btn, IconBtn, Badge, Card, CardSaveFoot, cx, Field, Input, Select, Checkbox, Switch, Segmented, CountryPill, Money */
const { useState } = React;
const { PROVIDER_KINDS, PROVIDERS } = window.BEDROCK_DATA;

// ---------- Helpers --------------------------------------------------------

const kindIcon = (k) => ({
  ru_bank: "building", swift_bank: "globe", local_scheme: "building",
  psp: "link", e_wallet: "wallet", card_processor: "wallet",
  blockchain: "sparkles", cash_desk: "wallet",
}[k] || "folder");

const KindBadge = ({ kind }) => {
  const k = PROVIDER_KINDS.find(x => x.value === kind);
  return <Badge mono outline>{k?.label ?? kind}</Badge>;
};

// ---------- Provider list (Finance → Requisite providers) ------------------

const ProvidersScreen = ({ onOpen, onNew }) => {
  const [q, setQ] = useState("");
  const [kind, setKind] = useState("all");
  const rows = PROVIDERS.filter(p => {
    if (kind !== "all" && p.kind !== kind) return false;
    if (q && !p.name.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  });
  return (
    <>
      <div className="page-head">
        <div>
          <h1 className="page-title">Requisite providers</h1>
          <div className="page-sub">{PROVIDERS.length} providers · banks, PSPs, blockchain networks, cash desks</div>
        </div>
        <div className="page-head-actions">
          <Btn variant="secondary" icon="download">Export</Btn>
          <Btn variant="primary" icon="plus" onClick={onNew}>New provider</Btn>
        </div>
      </div>

      <div className="table-wrap">
        <div className="table-toolbar">
          <div className="table-toolbar-left">
            <div className="input-group" style={{ width: 280 }}>
              <span className="input-group-prefix"><Icon name="search" size={13} /></span>
              <input className="input" placeholder="Search providers…" value={q} onChange={e => setQ(e.target.value)} />
            </div>
            <Segmented value={kind} onChange={setKind} options={[
              { value: "all", label: "All", count: PROVIDERS.length },
              { value: "ru_bank", label: "RU banks", count: PROVIDERS.filter(p => p.kind === "ru_bank").length },
              { value: "swift_bank", label: "SWIFT", count: PROVIDERS.filter(p => p.kind === "swift_bank").length },
              { value: "blockchain", label: "Blockchain", count: PROVIDERS.filter(p => p.kind === "blockchain").length },
              { value: "psp", label: "PSP", count: PROVIDERS.filter(p => p.kind === "psp").length },
              { value: "cash_desk", label: "Cash", count: PROVIDERS.filter(p => p.kind === "cash_desk").length },
            ]} />
          </div>
        </div>
        <table className="table">
          <thead><tr>
            <th style={{ width: 110 }}>ID</th>
            <th>Name</th>
            <th>Kind</th>
            <th>Country</th>
            <th>Identifier</th>
            <th>Currencies</th>
            <th>Status</th>
            <th style={{ width: 40 }}></th>
          </tr></thead>
          <tbody>
            {rows.map(p => (
              <tr key={p.id} onClick={() => onOpen?.(p.id)}>
                <td className="mono muted">{p.id}</td>
                <td>
                  <div className="hstack">
                    <Icon name={kindIcon(p.kind)} size={14} />
                    <span style={{ fontWeight: 500 }}>{p.name}</span>
                  </div>
                </td>
                <td><KindBadge kind={p.kind} /></td>
                <td>{p.country === "ANY" ? <span style={{ color: "var(--text-faint)" }}>—</span> : <CountryPill code={p.country} />}</td>
                <td className="mono" style={{ fontSize: 12 }}>
                  {p.bic || p.swift || p.network || p.address?.split(",")[0] || p.api_key_tail || "—"}
                </td>
                <td>
                  <div className="hstack" style={{ gap: 3, flexWrap: "wrap" }}>
                    {p.ccy.map(c => <span key={c} className="mono" style={{ fontSize: 10.5, padding: "1px 5px", border: "1px solid var(--border)", borderRadius: 3, color: "var(--text-secondary)" }}>{c}</span>)}
                  </div>
                </td>
                <td>
                  {p.status === "active" && <Badge tone="pos" dot>Active</Badge>}
                  {p.status === "review" && <Badge tone="warn" dot>In review</Badge>}
                </td>
                <td><IconBtn name="dots_vertical" /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

// ---------- Provider CREATE / EDIT (conditional fields) --------------------

const ProviderEditorScreen = ({ providerId, onBack }) => {
  const existing = PROVIDERS.find(p => p.id === providerId);
  const [kind, setKind] = useState(existing?.kind || "ru_bank");
  const [country, setCountry] = useState(existing?.country || "RU");
  const [name, setName] = useState(existing?.name || "");
  const [ccy, setCcy] = useState(existing?.ccy || ["RUB"]);
  const [status, setStatus] = useState(existing?.status || "active");
  const [dirty, setDirty] = useState(false);
  const markDirty = () => setDirty(true);

  // Kind-specific field state (all local)
  const [bic, setBic]       = useState(existing?.bic || "");
  const [corr, setCorr]     = useState(existing?.corr || "");
  const [inn, setInn]       = useState(existing?.inn || "");
  const [kpp, setKpp]       = useState(existing?.kpp || "");
  const [swift, setSwift]   = useState(existing?.swift || "");
  const [ibanPfx, setIbanPfx] = useState(existing?.iban_prefix || "");
  const [intermediary, setIntermediary] = useState(existing?.intermediary || "");
  const [sortCode, setSortCode] = useState(existing?.sort_code || "");
  const [network, setNetwork] = useState(existing?.network || "TRC-20");
  const [confirmations, setConfirmations] = useState(existing?.confirmations || 12);
  const [apiEndpoint, setApiEndpoint] = useState("");
  const [webhook, setWebhook] = useState(existing?.webhook || "");
  const [address, setAddress] = useState(existing?.address || "");
  const [operator, setOperator] = useState(existing?.operator || "");
  const [limit, setLimit] = useState(existing?.limit_usd || 0);

  const kindMeta = PROVIDER_KINDS.find(k => k.value === kind);

  return (
    <>
      <div className="detail-header">
        <div className="detail-header-left">
          <span className="avatar lg muted"><Icon name={kindIcon(kind)} size={18} /></span>
          <div>
            <h1 className="detail-title">
              {existing ? existing.name : "New provider"}
              <Badge tone="warn" dot>{existing ? "Editing" : "Draft"}</Badge>
            </h1>
            <div className="detail-id">
              <span>{existing?.id || "— · new"}</span>
              <span>·</span>
              <KindBadge kind={kind} />
              {country !== "ANY" && <><span>·</span><CountryPill code={country} /></>}
            </div>
          </div>
        </div>
        <div className="page-head-actions">
          <Btn variant="ghost" onClick={onBack}>Cancel</Btn>
          <Btn variant="secondary" icon="copy">Save as template</Btn>
          <Btn variant="primary" icon="check" disabled={!dirty && !!existing}>Save provider</Btn>
        </div>
      </div>

      <div className="detail-grid">
        <div className="detail-main">
          <Card title="Type" sub="Choosing a type determines the connection fields below">
            <div className="kind-picker">
              {PROVIDER_KINDS.map(k => (
                <button type="button" key={k.value}
                  className={cx("kind-pill", kind === k.value && "active")}
                  onClick={() => { setKind(k.value); markDirty(); }}
                  title={k.hint}>
                  <Icon name={kindIcon(k.value)} size={13} />
                  <span>{k.label}</span>
                </button>
              ))}
            </div>
          </Card>

          <Card title="General">
            <div className="field-row two">
              <Field label="Display name" required>
                <Input value={name} onChange={e => { setName(e.target.value); markDirty(); }} placeholder="e.g. Raiffeisenbank, Emirates NBD" />
              </Field>
              <Field label="Country" required>
                {kindMeta?.countries[0] === "RU" ? (
                  <Input value="RU · Russia" disabled />
                ) : (
                  <Select value={country} onChange={e => { setCountry(e.target.value); markDirty(); }}>
                    <option value="ANY">— Any (network / global) —</option>
                    <option value="RU">RU · Russia</option>
                    <option value="AE">AE · United Arab Emirates</option>
                    <option value="DE">DE · Germany</option>
                    <option value="GB">GB · United Kingdom</option>
                    <option value="SG">SG · Singapore</option>
                    <option value="ZA">ZA · South Africa</option>
                    <option value="US">US · United States</option>
                  </Select>
                )}
              </Field>
            </div>

            <div className="field-row two" style={{ marginTop: 12 }}>
              <Field label="Supported currencies" hint="Which currencies this provider can handle">
                <div className="chip-input">
                  {ccy.map(c => (
                    <span key={c} className="chip">
                      {c}
                      <button type="button" onClick={() => { setCcy(ccy.filter(x => x !== c)); markDirty(); }}><Icon name="x" size={11} /></button>
                    </span>
                  ))}
                  <input placeholder="+ add currency" onKeyDown={e => {
                    if (e.key === "Enter" && e.target.value) {
                      setCcy([...ccy, e.target.value.toUpperCase()]);
                      e.target.value = ""; markDirty();
                    }
                  }} />
                </div>
              </Field>
              <Field label="Status">
                <Select value={status} onChange={e => { setStatus(e.target.value); markDirty(); }}>
                  <option value="active">Active</option>
                  <option value="review">In review</option>
                  <option value="archived">Archived</option>
                </Select>
              </Field>
            </div>
          </Card>

          {/* ---- Conditional fields -------------------------------------- */}
          <Card title={"Connection details · " + kindMeta?.label}
                sub="Fields below change based on the selected kind">
            {kind === "ru_bank" && (
              <div className="vstack" style={{ gap: 14 }}>
                <div className="field-row two">
                  <Field label="BIC (9 digits)" required hint="Russian bank identifier code">
                    <Input value={bic} onChange={e => { setBic(e.target.value); markDirty(); }} placeholder="044525700" maxLength={9} />
                  </Field>
                  <Field label="Correspondent account" required>
                    <Input value={corr} onChange={e => { setCorr(e.target.value); markDirty(); }} placeholder="30101 810 2 0000 0000 700" />
                  </Field>
                </div>
                <div className="field-row two">
                  <Field label="INN" required>
                    <Input value={inn} onChange={e => { setInn(e.target.value); markDirty(); }} placeholder="10 or 12 digits" />
                  </Field>
                  <Field label="KPP">
                    <Input value={kpp} onChange={e => { setKpp(e.target.value); markDirty(); }} placeholder="9 digits" />
                  </Field>
                </div>
                <div className="field-row two">
                  <Field label="OKPO">
                    <Input placeholder="optional" />
                  </Field>
                  <Field label="Registration date">
                    <Input type="date" />
                  </Field>
                </div>
              </div>
            )}

            {kind === "swift_bank" && (
              <div className="vstack" style={{ gap: 14 }}>
                <div className="field-row two">
                  <Field label="SWIFT / BIC" required hint="8 or 11 chars (ISO 9362)">
                    <Input value={swift} onChange={e => { setSwift(e.target.value); markDirty(); }} placeholder="EBILAEAD" maxLength={11} />
                  </Field>
                  <Field label="IBAN prefix" hint="Country IBAN prefix if applicable">
                    <Input value={ibanPfx} onChange={e => { setIbanPfx(e.target.value); markDirty(); }} placeholder="AE07, DE89…" />
                  </Field>
                </div>
                {country === "GB" && (
                  <Field label="Sort code (UK)">
                    <Input value={sortCode} onChange={e => { setSortCode(e.target.value); markDirty(); }} placeholder="40-05-15" />
                  </Field>
                )}
                {country === "US" && (
                  <div className="field-row two">
                    <Field label="ABA / Routing (US)" required>
                      <Input placeholder="9 digits" />
                    </Field>
                    <Field label="Fedwire eligible">
                      <Select defaultValue="yes"><option>Yes</option><option>No</option></Select>
                    </Field>
                  </div>
                )}
                <Field label="Intermediary bank" hint="USD correspondent, optional">
                  <Input value={intermediary} onChange={e => { setIntermediary(e.target.value); markDirty(); }} placeholder="e.g. Citibank N.A. NY" />
                </Field>
              </div>
            )}

            {kind === "local_scheme" && (
              <div className="field-row two">
                <Field label="Scheme" required>
                  <Select>
                    <option>SEPA Instant</option><option>Faster Payments (UK)</option>
                    <option>SG FAST</option><option>India IMPS/NEFT</option>
                  </Select>
                </Field>
                <Field label="Local identifier">
                  <Input placeholder="BSB / IFSC / SortCode / BIC-AT…" />
                </Field>
              </div>
            )}

            {kind === "psp" && (
              <div className="vstack" style={{ gap: 14 }}>
                <div className="field-row two">
                  <Field label="API base URL" required>
                    <Input value={apiEndpoint} onChange={e => { setApiEndpoint(e.target.value); markDirty(); }} placeholder="https://api.checkout.com" />
                  </Field>
                  <Field label="API key">
                    <Input type="password" placeholder="sk_live_…" />
                  </Field>
                </div>
                <Field label="Webhook URL (inbound)">
                  <Input value={webhook} onChange={e => { setWebhook(e.target.value); markDirty(); }} placeholder="https://bedrock.io/webhooks/..." />
                </Field>
                <div className="field-row three">
                  <Field label="Merchant ID">
                    <Input />
                  </Field>
                  <Field label="3-D Secure">
                    <Select><option>Required</option><option>Optional</option><option>Off</option></Select>
                  </Field>
                  <Field label="Settlement delay">
                    <Input suffix="days" defaultValue="2" />
                  </Field>
                </div>
              </div>
            )}

            {kind === "e_wallet" && (
              <div className="field-row two">
                <Field label="Wallet scheme" required>
                  <Select><option>Payeer</option><option>Perfect Money</option><option>AdvCash</option></Select>
                </Field>
                <Field label="Account / wallet ID" required>
                  <Input placeholder="P1234567" />
                </Field>
              </div>
            )}

            {kind === "card_processor" && (
              <div className="field-row three">
                <Field label="MID (Merchant ID)" required><Input /></Field>
                <Field label="Terminal ID"><Input /></Field>
                <Field label="Scheme">
                  <Select><option>Visa/Mastercard</option><option>Mir</option><option>UnionPay</option></Select>
                </Field>
              </div>
            )}

            {kind === "blockchain" && (
              <div className="vstack" style={{ gap: 14 }}>
                <div className="field-row two">
                  <Field label="Network" required>
                    <Select value={network} onChange={e => { setNetwork(e.target.value); markDirty(); }}>
                      <option>TRC-20</option><option>ERC-20</option><option>BEP-20</option>
                      <option>Solana</option><option>Bitcoin</option><option>TON</option>
                    </Select>
                  </Field>
                  <Field label="Confirmations required" hint="Before crediting">
                    <Input type="number" value={confirmations} onChange={e => { setConfirmations(+e.target.value); markDirty(); }} />
                  </Field>
                </div>
                <Field label="Notes" hint="Any network-specific ops notes">
                  <textarea className="input textarea" rows={2} placeholder="e.g. memo/tag required; only energy-enabled wallets accepted" />
                </Field>
                <div className="callout">
                  <Icon name="info" size={14} />
                  <div>
                    <div style={{ fontWeight: 500, fontSize: 12.5 }}>Blockchain providers don't hold banking identifiers.</div>
                    <div style={{ fontSize: 12, color: "var(--text-muted)" }}>Requisites under this provider only require a wallet address (plus memo for TON/XRP).</div>
                  </div>
                </div>
              </div>
            )}

            {kind === "cash_desk" && (
              <div className="vstack" style={{ gap: 14 }}>
                <Field label="Physical address" required>
                  <Input value={address} onChange={e => { setAddress(e.target.value); markDirty(); }} placeholder="Street, building, city" />
                </Field>
                <div className="field-row two">
                  <Field label="Operator in charge" required>
                    <Input value={operator} onChange={e => { setOperator(e.target.value); markDirty(); }} />
                  </Field>
                  <Field label="Daily limit" hint="Per desk, per day">
                    <Input type="number" value={limit} onChange={e => { setLimit(+e.target.value); markDirty(); }} suffix="USD" />
                  </Field>
                </div>
              </div>
            )}
          </Card>

          <Card title="Fees & limits" sub="Defaults pre-fill on any requisite using this provider">
            <div className="field-row three">
              <Field label="Default fee basis">
                <Select defaultValue="gross_pct">
                  <option value="gross_pct">% of gross</option>
                  <option value="fixed_ccy">Fixed amount</option>
                  <option value="spread_bps">FX spread (bps)</option>
                </Select>
              </Field>
              <Field label="Default fee value">
                <Input type="number" defaultValue={0.35} suffix="%" />
              </Field>
              <Field label="Minimum fee">
                <Input type="number" defaultValue={5} suffix="USD" />
              </Field>
            </div>
            <div className="field-row three" style={{ marginTop: 12 }}>
              <Field label="Transaction floor">
                <Input type="number" defaultValue={10} suffix="USD" />
              </Field>
              <Field label="Transaction cap">
                <Input type="number" defaultValue={1_000_000} suffix="USD" />
              </Field>
              <Field label="Daily cap">
                <Input type="number" defaultValue={5_000_000} suffix="USD" />
              </Field>
            </div>
          </Card>
        </div>

        <div className="detail-side">
          <Card title="Will be usable for">
            <div className="vstack" style={{ gap: 8, fontSize: 12.5 }}>
              <div className="hstack"><Icon name="check" size={13} /> Requisites of kind <b style={{ marginLeft: 4 }}>{kindMeta?.label}</b></div>
              <div className="hstack"><Icon name="check" size={13} /> Legs in payment routes</div>
              <div className="hstack"><Icon name="check" size={13} /> Rate source references (if applicable)</div>
            </div>
          </Card>
          <Card title="Validation">
            <div className="vstack" style={{ gap: 6, fontSize: 12.5 }}>
              <div className="hstack" style={{ gap: 6 }}>
                {name ? <Icon name="check" size={13} /> : <span style={{ color: "var(--warn)" }}>•</span>}
                <span>Display name present</span>
              </div>
              <div className="hstack" style={{ gap: 6 }}>
                {(kind === "ru_bank" ? bic && corr : kind === "swift_bank" ? swift : true) ?
                  <Icon name="check" size={13} /> : <span style={{ color: "var(--warn)" }}>•</span>}
                <span>Kind-specific identifier filled</span>
              </div>
              <div className="hstack" style={{ gap: 6 }}>
                {ccy.length ? <Icon name="check" size={13} /> : <span style={{ color: "var(--warn)" }}>•</span>}
                <span>At least one currency</span>
              </div>
            </div>
          </Card>
          {dirty && (
            <Card>
              <CardSaveFoot dirty onSave={() => setDirty(false)} onReset={() => setDirty(false)} />
            </Card>
          )}
        </div>
      </div>
    </>
  );
};

window.ProvidersScreen = ProvidersScreen;
window.ProviderEditorScreen = ProviderEditorScreen;
