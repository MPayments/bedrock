/* global React, Icon, Btn, IconBtn, Badge, Card, cx, Money, Num, Sparkline */
const { RATES } = window.BEDROCK_DATA;

const RatesScreen = () => (
  <>
    <div className="page-head">
      <div>
        <h1 className="page-title">Currency rates</h1>
        <div className="page-sub">Live · MOEX + EBS + Reuters · used for deal pricing</div>
      </div>
      <div className="page-head-actions">
        <Btn variant="ghost" icon="refresh">Refresh</Btn>
        <Btn variant="secondary" icon="plus">Add pair</Btn>
      </div>
    </div>

    <div className="table-wrap">
      <table className="table">
        <thead><tr>
          <th>Pair</th>
          <th className="right">Mid</th>
          <th className="right">Buy</th>
          <th className="right">Sell</th>
          <th className="right">24h</th>
          <th>Trend</th>
          <th>Source</th>
          <th>Updated</th>
          <th style={{ width: 40 }}></th>
        </tr></thead>
        <tbody>
          {RATES.map(r => (
            <tr key={r.pair}>
              <td style={{ fontWeight: 600 }} className="mono">{r.pair}</td>
              <td className="right"><Num value={r.mid} digits={4} /></td>
              <td className="right" style={{ color: "var(--text-secondary)" }}><Num value={r.buy} digits={4} /></td>
              <td className="right" style={{ color: "var(--text-secondary)" }}><Num value={r.sell} digits={4} /></td>
              <td className="right">
                <span className={`mono money ${r.change > 0 ? "pos" : r.change < 0 ? "neg" : ""}`}>
                  {r.change > 0 ? "+" : ""}{(r.change * 100).toFixed(2)}%
                </span>
              </td>
              <td style={{ width: 110 }}><Sparkline data={r.spark} width={90} height={24} /></td>
              <td style={{ fontSize: 12, color: "var(--text-muted)" }}>{r.source}</td>
              <td className="mono" style={{ fontSize: 11.5, color: "var(--text-muted)" }}>{r.updated}</td>
              <td><IconBtn name="dots_vertical" /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </>
);

window.RatesScreen = RatesScreen;
