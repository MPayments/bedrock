/* global React, Icon, Btn, IconBtn, Badge, Card, Field, Input, Select, Segmented, Modal, cx, CountryPill, CardSaveFoot */
const { useState, useRef, useEffect: useEffectCP } = React;

/* ================================================================
   Counterparty data (per-customer)
   kinds: legal_entity | organization | individual
   sources: manual | business_card | inn_lookup | edgar
================================================================ */
const SEED_COUNTERPARTIES = [
  {
    id: "CP-2101",
    kind: "legal_entity",
    name: "Lotus Global FZE",
    nameRu: "Лотус Глобал ФЗЕ",
    country: "AE",
    tin: "100123456789",
    regNumber: "DMCC-2011-445",
    address: "Office 2201, Emirates Towers, Sheikh Zayed Rd, Dubai, UAE",
    director: "Rajesh Menon",
    signatoryRole: "Managing Director",
    email: "ops@lotusglobal.ae",
    phone: "+971 4 330 0990",
    status: "active",
    source: "manual",
    requisites: 2,
    deals: 8,
    addedBy: "AE",
    addedAt: "2024-03-14",
  },
  {
    id: "CP-2102",
    kind: "legal_entity",
    name: "Nordmax Trading LLC",
    nameRu: "ООО «Нордмакс Трейдинг»",
    country: "RU",
    tin: "7712345678",
    kpp: "771201001",
    regNumber: "1127700123456",
    address: "Moscow, 125009, ul. Tverskaya 15, office 402",
    director: "Elena Smirnova",
    signatoryRole: "Генеральный директор",
    email: "contracts@nordmax.ru",
    phone: "+7 495 120-33-11",
    status: "active",
    source: "inn_lookup",
    requisites: 3,
    deals: 12,
    addedBy: "SY",
    addedAt: "2024-07-22",
  },
  {
    id: "CP-2103",
    kind: "individual",
    name: "Dmitri Volkov",
    country: "RU",
    tin: "771234567890",
    passport: "4512 345678",
    address: "Moscow, Russia, 119049",
    email: "d.volkov@protonmail.com",
    phone: "+7 916 220-44-02",
    status: "pending_kyc",
    source: "business_card",
    requisites: 1,
    deals: 0,
    addedBy: "AE",
    addedAt: "2026-04-12",
  },
  {
    id: "CP-2104",
    kind: "organization",
    name: "Alpine Metals GmbH",
    nameRu: "Альпин Металс ГмбХ",
    country: "DE",
    tin: "DE312345678",
    regNumber: "HRB 89231",
    address: "Arnulfstrasse 30, 80335 München, Germany",
    director: "Klaus Richter",
    signatoryRole: "Geschäftsführer",
    email: "k.richter@alpinemetals.de",
    phone: "+49 89 551 420-30",
    status: "active",
    source: "manual",
    requisites: 2,
    deals: 5,
    addedBy: "MK",
    addedAt: "2025-11-04",
  },
];

const KIND_LABEL = {
  legal_entity: "Legal entity",
  organization: "Organization",
  individual: "Individual",
};
const KIND_ICON = {
  legal_entity: "briefcase",
  organization: "building",
  individual: "user",
};
const STATUS_BADGE = {
  active: { tone: "pos", label: "Active" },
  pending_kyc: { tone: "warn", label: "Pending KYC" },
  draft: { tone: "default", label: "Draft" },
  archived: { tone: "default", label: "Archived" },
};
const SOURCE_BADGE = {
  manual: { icon: "edit", label: "Manual" },
  business_card: { icon: "sparkle", label: "AI · business card" },
  inn_lookup: { icon: "search", label: "INN lookup" },
  edgar: { icon: "search", label: "EDGAR lookup" },
};

/* ================================================================
   Counterparties tab
================================================================ */
const CounterpartiesTab = () => {
  const [items, setItems] = useState(SEED_COUNTERPARTIES);
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState(null);

  const rows = items.filter(i => {
    if (filter !== "all" && i.kind !== filter) return false;
    if (query) {
      const q = query.toLowerCase();
      return i.name.toLowerCase().includes(q) || i.tin.includes(q) || (i.nameRu || "").toLowerCase().includes(q);
    }
    return true;
  });

  const handleAdd = (cp) => {
    setItems([{ ...cp, id: `CP-${2100 + items.length + 1}`, requisites: 0, deals: 0, addedBy: "AE", addedAt: "today" }, ...items]);
    setDialogOpen(false);
  };

  const editing = items.find(i => i.id === editId);

  return (
    <>
      <Card
        title="Counterparties"
        sub={`${items.length} legal entities, organizations and individuals linked to this customer`}
        actions={
          <Btn variant="primary" size="sm" icon="plus" onClick={() => setDialogOpen(true)}>
            Add counterparty
          </Btn>
        }
      >
        <div className="hstack" style={{ gap: 12, marginBottom: 12 }}>
          <Segmented
            value={filter}
            onChange={setFilter}
            options={[
              { value: "all", label: "All", count: items.length },
              { value: "legal_entity", label: "Legal entities", count: items.filter(i => i.kind === "legal_entity").length },
              { value: "organization", label: "Organizations", count: items.filter(i => i.kind === "organization").length },
              { value: "individual", label: "Individuals", count: items.filter(i => i.kind === "individual").length },
            ]}
          />
          <div style={{ flex: 1 }}>
            <Input prefix={<Icon name="search" size={12} />} placeholder="Search by name, TIN, INN…" value={query} onChange={e => setQuery(e.target.value)} />
          </div>
        </div>

        <table className="table">
          <thead>
            <tr>
              <th style={{ width: 100 }}>ID</th>
              <th>Name</th>
              <th style={{ width: 140 }}>Kind</th>
              <th style={{ width: 80 }}>Country</th>
              <th style={{ width: 160 }}>TIN / INN</th>
              <th style={{ width: 120 }}>Requisites</th>
              <th style={{ width: 120 }}>Status</th>
              <th style={{ width: 140 }}>Source</th>
              <th style={{ width: 40 }}></th>
            </tr>
          </thead>
          <tbody>
            {rows.map(cp => (
              <tr key={cp.id} onClick={() => setEditId(cp.id)}>
                <td className="mono muted">{cp.id}</td>
                <td>
                  <div className="hstack" style={{ gap: 8 }}>
                    <Icon name={KIND_ICON[cp.kind]} size={14} style={{ color: "var(--text-muted)" }} />
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontWeight: 500, fontSize: 13 }}>{cp.name}</div>
                      {cp.nameRu && <div className="mono" style={{ fontSize: 11.5, color: "var(--text-muted)" }}>{cp.nameRu}</div>}
                    </div>
                  </div>
                </td>
                <td style={{ fontSize: 12.5, color: "var(--text-secondary)" }}>{KIND_LABEL[cp.kind]}</td>
                <td><CountryPill code={cp.country} /></td>
                <td className="mono" style={{ fontSize: 12 }}>{cp.tin}</td>
                <td>
                  <div className="hstack" style={{ gap: 6 }}>
                    <Icon name="wallet" size={12} style={{ color: "var(--text-faint)" }} />
                    <span className="mono" style={{ fontSize: 12 }}>{cp.requisites}</span>
                    <span style={{ fontSize: 12, color: "var(--text-muted)" }}>requisite{cp.requisites === 1 ? "" : "s"}</span>
                  </div>
                </td>
                <td><Badge tone={STATUS_BADGE[cp.status].tone} dot>{STATUS_BADGE[cp.status].label}</Badge></td>
                <td>
                  <div className="hstack" style={{ gap: 6, fontSize: 11.5, color: "var(--text-muted)" }}>
                    <Icon name={SOURCE_BADGE[cp.source].icon} size={12} />
                    <span>{SOURCE_BADGE[cp.source].label}</span>
                  </div>
                </td>
                <td onClick={e => e.stopPropagation()}>
                  <IconBtn name="dots_vertical" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <CounterpartyCreateDialog open={dialogOpen} onClose={() => setDialogOpen(false)} onCreate={handleAdd} />
      <CounterpartyEditDialog open={!!editing} item={editing} onClose={() => setEditId(null)} onSave={(next) => {
        setItems(items.map(i => i.id === editing.id ? { ...i, ...next } : i));
        setEditId(null);
      }} />
    </>
  );
};

/* ================================================================
   Create counterparty — 3 modes: Manual | Business card AI | INN lookup
================================================================ */
const CounterpartyCreateDialog = ({ open, onClose, onCreate }) => {
  const [mode, setMode] = useState("card"); // card | inn | manual
  const [draft, setDraft] = useState({});

  // Reset when opened
  useEffectCP(() => {
    if (open) {
      setMode("card");
      setDraft({});
    }
  }, [open]);

  const canSave = draft.name && draft.country && draft.tin;

  const handleSave = () => {
    const cp = {
      kind: draft.kind || "legal_entity",
      name: draft.name,
      nameRu: draft.nameRu || "",
      country: draft.country,
      tin: draft.tin,
      kpp: draft.kpp,
      regNumber: draft.regNumber,
      address: draft.address,
      director: draft.director,
      signatoryRole: draft.signatoryRole,
      email: draft.email,
      phone: draft.phone,
      status: "pending_kyc",
      source: mode === "card" ? "business_card" : mode === "inn" ? "inn_lookup" : "manual",
    };
    onCreate(cp);
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      size="xl"
      title="Add counterparty"
      sub="Capture identity, then review before saving. Requisites and KYC docs come later."
      foot={
        <>
          <div style={{ fontSize: 12, color: "var(--text-muted)" }}>
            {canSave ? "Ready to save · KYC will start as pending" : "Fill name, country and TIN to continue"}
          </div>
          <div className="hstack" style={{ gap: 8 }}>
            <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
            <Btn variant="primary" icon="check" disabled={!canSave} onClick={handleSave}>
              Add counterparty
            </Btn>
          </div>
        </>
      }
    >
      {/* Mode switcher */}
      <div className="cp-mode-switcher">
        {[
          { key: "card", icon: "sparkle", title: "From business card", sub: "Upload a PDF — AI extracts name, TIN, address" },
          { key: "inn", icon: "search", title: "Search by INN", sub: "Russian registry · autofills legal data", ruOnly: true },
          { key: "manual", icon: "edit", title: "Manual entry", sub: "Type in fields directly" },
        ].map(m => (
          <button
            key={m.key}
            type="button"
            className={cx("cp-mode-card", mode === m.key && "active")}
            onClick={() => setMode(m.key)}
          >
            <div className="cp-mode-icon"><Icon name={m.icon} size={16} /></div>
            <div className="cp-mode-text">
              <div className="cp-mode-title">{m.title}{m.ruOnly && <Badge tone="default" outline>RU only</Badge>}</div>
              <div className="cp-mode-sub">{m.sub}</div>
            </div>
            <div className="cp-mode-check">
              {mode === m.key && <Icon name="check" size={14} />}
            </div>
          </button>
        ))}
      </div>

      <div className="divider" style={{ margin: "18px 0" }} />

      {mode === "card" && <BusinessCardMode draft={draft} setDraft={setDraft} />}
      {mode === "inn" && <InnLookupMode draft={draft} setDraft={setDraft} />}
      {mode === "manual" && <ManualEntryMode draft={draft} setDraft={setDraft} />}
    </Modal>
  );
};

/* ================================================================
   Mode: AI business-card extraction
================================================================ */
const BusinessCardMode = ({ draft, setDraft }) => {
  // stages: idle → uploading → analyzing → done
  const [stage, setStage] = useState("idle");
  const [fileName, setFileName] = useState("");
  const [progress, setProgress] = useState(0);
  const [aiFields, setAiFields] = useState({}); // key -> { value, confidence }
  const inputRef = useRef(null);

  const pickFile = () => inputRef.current?.click();

  const handleFile = (file) => {
    if (!file) return;
    setFileName(file.name || "business_card.pdf");
    setStage("uploading");
    setProgress(0);
    const upStart = Date.now();
    const up = setInterval(() => {
      const p = Math.min(100, ((Date.now() - upStart) / 700) * 100);
      setProgress(p);
      if (p >= 100) {
        clearInterval(up);
        setStage("analyzing");
        setProgress(0);
        const anStart = Date.now();
        const an = setInterval(() => {
          const p2 = Math.min(100, ((Date.now() - anStart) / 1500) * 100);
          setProgress(p2);
          if (p2 >= 100) {
            clearInterval(an);
            // "Inferred" results
            const inferred = {
              kind: { value: "legal_entity", confidence: 0.95 },
              name: { value: "Meridian Capital Partners LLC", confidence: 0.98 },
              nameRu: { value: "ООО «Меридиан Капитал Партнерс»", confidence: 0.87 },
              country: { value: "RU", confidence: 0.95 },
              tin: { value: "7704567890", confidence: 0.92 },
              kpp: { value: "770401001", confidence: 0.88 },
              director: { value: "Oleg Mironov", confidence: 0.82 },
              signatoryRole: { value: "Генеральный директор", confidence: 0.74 },
              address: { value: "Moscow, 119019, Nikitsky Blvd., 4, office 8", confidence: 0.79 },
              email: { value: "o.mironov@meridian-cp.ru", confidence: 0.94 },
              phone: { value: "+7 495 223-88-01", confidence: 0.91 },
            };
            setAiFields(inferred);
            const next = {};
            Object.keys(inferred).forEach(k => next[k] = inferred[k].value);
            setDraft({ ...draft, ...next });
            setStage("done");
          }
        }, 30);
      }
    }, 30);
  };

  const onDrop = (e) => {
    e.preventDefault();
    handleFile(e.dataTransfer.files?.[0]);
  };

  const set = (k, v) => {
    setDraft({ ...draft, [k]: v });
    // clear AI confidence once user edits
    if (aiFields[k]) {
      setAiFields({ ...aiFields, [k]: { ...aiFields[k], edited: true } });
    }
  };

  return (
    <div className="cp-card-mode">
      {stage === "idle" && (
        <div
          className="cp-dropzone"
          onDragOver={e => e.preventDefault()}
          onDrop={onDrop}
          onClick={pickFile}
        >
          <div className="cp-dropzone-icon"><Icon name="file" size={28} /></div>
          <div className="cp-dropzone-title">Drop a business card PDF here</div>
          <div className="cp-dropzone-sub">
            PDF up to 10 MB · AI extracts company name, TIN, address, signatory and contact details
          </div>
          <Btn variant="secondary" icon="upload" onClick={(e) => { e.stopPropagation(); pickFile(); }}>
            Choose file
          </Btn>
          <input
            ref={inputRef}
            type="file"
            accept="application/pdf"
            style={{ display: "none" }}
            onChange={e => handleFile(e.target.files?.[0])}
          />
          <div className="cp-dropzone-hint">
            <Icon name="info" size={12} />
            Tip: a crisp scan or export (not a photo of a printed card) gives the best results.
          </div>
        </div>
      )}

      {(stage === "uploading" || stage === "analyzing") && (
        <div className="cp-progress-panel">
          <div className="cp-progress-file">
            <Icon name="file" size={18} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 500 }}>{fileName}</div>
              <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>
                {stage === "uploading" ? "Uploading…" : "Analyzing content…"}
              </div>
            </div>
            <div className="mono" style={{ fontSize: 12, color: "var(--text-muted)" }}>{Math.round(progress)}%</div>
          </div>
          <div className="cp-progress-bar">
            <div className="cp-progress-bar-fill" style={{ width: `${progress}%` }} />
          </div>
          {stage === "analyzing" && (
            <div className="cp-progress-steps">
              {["Extracting text regions", "Identifying fields", "Resolving entity", "Cross-checking registry"].map((s, i) => (
                <div key={i} className={cx("cp-progress-step", progress >= (i + 1) * 25 && "done")}>
                  {progress >= (i + 1) * 25
                    ? <Icon name="check" size={12} />
                    : progress >= i * 25
                      ? <span className="cp-spinner" />
                      : <span className="cp-dot-empty" />}
                  <span>{s}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {stage === "done" && (
        <>
          <div className="cp-ai-banner">
            <Icon name="sparkle" size={14} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12.5, fontWeight: 500 }}>Extracted from {fileName}</div>
              <div style={{ fontSize: 11.5, color: "var(--text-muted)" }}>
                11 fields detected · review confidence markers and edit as needed
              </div>
            </div>
            <Btn variant="ghost" size="sm" icon="refresh" onClick={() => { setStage("idle"); setAiFields({}); }}>Try another</Btn>
          </div>

          <AiField label="Kind" name="kind" draft={draft} set={set} ai={aiFields.kind} kind="select"
                   options={[["legal_entity","Legal entity"],["organization","Organization"],["individual","Individual"]]} />
          <div className="field-row two">
            <AiField label="Name (EN)" name="name" required draft={draft} set={set} ai={aiFields.name} />
            <AiField label="Name (RU)" name="nameRu" draft={draft} set={set} ai={aiFields.nameRu} />
          </div>
          <div className="field-row three">
            <AiField label="Country" name="country" required draft={draft} set={set} ai={aiFields.country} kind="country" />
            <AiField label="TIN / INN" name="tin" required draft={draft} set={set} ai={aiFields.tin} mono />
            <AiField label="KPP" name="kpp" draft={draft} set={set} ai={aiFields.kpp} mono />
          </div>
          <AiField label="Registered address" name="address" draft={draft} set={set} ai={aiFields.address} multiline />
          <div className="field-row two">
            <AiField label="Signatory name" name="director" draft={draft} set={set} ai={aiFields.director} />
            <AiField label="Signatory role" name="signatoryRole" draft={draft} set={set} ai={aiFields.signatoryRole} />
          </div>
          <div className="field-row two">
            <AiField label="Email" name="email" draft={draft} set={set} ai={aiFields.email} />
            <AiField label="Phone" name="phone" draft={draft} set={set} ai={aiFields.phone} mono />
          </div>
        </>
      )}
    </div>
  );
};

/* Field wrapper that shows AI confidence */
const AiField = ({ label, name, required, draft, set, ai, kind = "text", multiline, mono, options }) => {
  const value = draft[name] || "";
  const confidence = ai?.confidence;
  const edited = ai?.edited;
  const tone = !ai ? null : edited ? "edited" : confidence >= 0.9 ? "high" : confidence >= 0.8 ? "mid" : "low";
  const toneLabel = edited ? "edited" : confidence >= 0.9 ? "high confidence" : confidence >= 0.8 ? "medium confidence" : "low · verify";

  return (
    <Field label={label} required={required} hint={tone && <span className={cx("ai-conf", tone)}>
      {edited
        ? <><Icon name="edit" size={10} />edited</>
        : <><Icon name="sparkle" size={10} />AI · {Math.round(confidence * 100)}% · {toneLabel.replace(/ ·.*/, "")}</>}
    </span>}>
      {kind === "select" ? (
        <Select value={value} onChange={e => set(name, e.target.value)} className={tone && `ai-input ai-${tone}`}>
          {options.map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>
      ) : kind === "country" ? (
        <Select value={value} onChange={e => set(name, e.target.value)} className={tone && `ai-input ai-${tone}`}>
          {["RU", "AE", "DE", "GB", "SG", "US", "ZA", "CH"].map(c => <option key={c} value={c}>{c}</option>)}
        </Select>
      ) : multiline ? (
        <textarea
          className={cx("input", tone && `ai-input ai-${tone}`, mono && "mono")}
          rows={2}
          value={value}
          onChange={e => set(name, e.target.value)}
        />
      ) : (
        <Input
          value={value}
          onChange={e => set(name, e.target.value)}
          className={cx(tone && `ai-input ai-${tone}`, mono && "mono")}
        />
      )}
    </Field>
  );
};

/* ================================================================
   Mode: INN lookup (RU)
================================================================ */
const InnLookupMode = ({ draft, setDraft }) => {
  const [inn, setInn] = useState("");
  const [stage, setStage] = useState("idle"); // idle | searching | found | notfound | imported
  const [result, setResult] = useState(null);

  const search = () => {
    if (inn.length < 10) return;
    setStage("searching");
    setResult(null);
    setTimeout(() => {
      // Fake dataset of known results
      const DB = {
        "7712345678": {
          name: "Nordmax Trading LLC",
          nameRu: "ООО «Нордмакс Трейдинг»",
          country: "RU",
          tin: "7712345678",
          kpp: "771201001",
          regNumber: "1127700123456",
          regDate: "2012-03-14",
          address: "Moscow, 125009, ul. Tverskaya 15, office 402",
          director: "Elena Smirnova",
          signatoryRole: "Генеральный директор",
          okved: "46.72.22 · Wholesale of metals and metal ores",
          status: "Действующая",
          source: "egrul_api",
          fetchedAt: "just now",
        },
        "7830004567": {
          name: "Severnaya Stal JSC",
          nameRu: "АО «Северная Сталь»",
          country: "RU",
          tin: "7830004567",
          kpp: "783001001",
          regNumber: "1027800000123",
          regDate: "2002-11-08",
          address: "12 Naberezhnaya St., Saint-Petersburg, 198103",
          director: "Ivan Petrov",
          signatoryRole: "Генеральный директор",
          okved: "24.10 · Manufacture of basic iron and steel",
          status: "Действующая",
          source: "egrul_api",
          fetchedAt: "just now",
        },
      };
      const r = DB[inn];
      if (r) { setResult(r); setStage("found"); }
      else { setStage("notfound"); }
    }, 900);
  };

  const importResult = () => {
    setDraft({
      ...draft,
      kind: "legal_entity",
      name: result.name,
      nameRu: result.nameRu,
      country: result.country,
      tin: result.tin,
      kpp: result.kpp,
      regNumber: result.regNumber,
      address: result.address,
      director: result.director,
      signatoryRole: result.signatoryRole,
    });
    setStage("imported");
  };

  return (
    <div className="cp-inn-mode">
      <div className="cp-inn-search">
        <Field label="Russian INN (TIN)" required hint="10 digits for legal entities, 12 for individuals">
          <div className="hstack" style={{ gap: 8 }}>
            <div style={{ flex: 1 }}>
              <Input
                className="mono"
                placeholder="e.g. 7712345678"
                value={inn}
                onChange={e => setInn(e.target.value.replace(/\D/g, "").slice(0, 12))}
                prefix={<Icon name="search" size={12} />}
              />
            </div>
            <Btn variant="primary" icon="search" onClick={search} disabled={inn.length < 10 || stage === "searching"}>
              {stage === "searching" ? "Searching…" : "Search registry"}
            </Btn>
          </div>
        </Field>
        <div className="cp-inn-hint">
          <Icon name="info" size={12} />
          Looks up EGRUL/EGRIP via <b>Dadata</b> · returns legal name, director, address, OKVED and status. Nothing is saved until you click <b>Import</b>.
        </div>
        <div className="cp-inn-quick">
          <span style={{ fontSize: 11.5, color: "var(--text-muted)" }}>Try:</span>
          {["7712345678", "7830004567"].map(v => (
            <button key={v} type="button" className="cp-inn-quick-btn" onClick={() => setInn(v)}>{v}</button>
          ))}
        </div>
      </div>

      {stage === "searching" && (
        <div className="cp-inn-result loading">
          <span className="cp-spinner lg" />
          <div>Querying EGRUL registry…</div>
        </div>
      )}

      {stage === "notfound" && (
        <div className="cp-inn-result notfound">
          <Icon name="alert" size={18} style={{ color: "var(--warn)" }} />
          <div>
            <div style={{ fontSize: 13, fontWeight: 500 }}>Nothing found for {inn}</div>
            <div style={{ fontSize: 12, color: "var(--text-muted)" }}>
              The INN may be invalid or the company is not in EGRUL. Try another INN or switch to manual entry.
            </div>
          </div>
        </div>
      )}

      {(stage === "found" || stage === "imported") && result && (
        <div className="cp-inn-result found">
          <div className="cp-inn-result-head">
            <div>
              <div className="hstack" style={{ gap: 8, marginBottom: 4 }}>
                <Badge tone="pos" dot>{result.status}</Badge>
                <Badge tone="default" outline mono>EGRUL</Badge>
                <span className="mono" style={{ fontSize: 11, color: "var(--text-faint)" }}>fetched {result.fetchedAt}</span>
              </div>
              <div style={{ fontSize: 15, fontWeight: 500 }}>{result.name}</div>
              <div style={{ fontSize: 12.5, color: "var(--text-secondary)" }}>{result.nameRu}</div>
            </div>
            {stage === "imported"
              ? <Badge tone="pos" dot>Imported</Badge>
              : <Btn variant="primary" size="sm" icon="download" onClick={importResult}>Import to form</Btn>}
          </div>

          <div className="kv-grid cp-inn-kv" style={{ gridTemplateColumns: "1fr 1fr" }}>
            <div><div className="kv-label">INN</div><div className="kv-value mono">{result.tin}</div></div>
            <div><div className="kv-label">KPP</div><div className="kv-value mono">{result.kpp}</div></div>
            <div><div className="kv-label">OGRN</div><div className="kv-value mono">{result.regNumber}</div></div>
            <div><div className="kv-label">Registered</div><div className="kv-value mono">{result.regDate}</div></div>
            <div style={{ gridColumn: "1 / -1" }}>
              <div className="kv-label">Legal address</div>
              <div className="kv-value">{result.address}</div>
            </div>
            <div>
              <div className="kv-label">Director</div>
              <div className="kv-value">{result.director}</div>
              <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>{result.signatoryRole}</div>
            </div>
            <div>
              <div className="kv-label">OKVED</div>
              <div className="kv-value">{result.okved}</div>
            </div>
          </div>

          {stage === "imported" && (
            <div className="callout" style={{ marginTop: 12 }}>
              <Icon name="check" size={13} style={{ color: "var(--pos)" }} />
              <div style={{ fontSize: 12 }}>Fields imported — review below and click <b>Add counterparty</b> to save.</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

/* ================================================================
   Mode: manual
================================================================ */
const ManualEntryMode = ({ draft, setDraft }) => {
  const set = (k, v) => setDraft({ ...draft, [k]: v });
  return (
    <div className="vstack" style={{ gap: 14 }}>
      <Field label="Kind" required>
        <Segmented
          value={draft.kind || "legal_entity"}
          onChange={(v) => set("kind", v)}
          options={[
            { value: "legal_entity", label: "Legal entity" },
            { value: "organization", label: "Organization" },
            { value: "individual", label: "Individual" },
          ]}
        />
      </Field>
      <div className="field-row two">
        <Field label={draft.kind === "individual" ? "Full name (EN)" : "Legal name (EN)"} required>
          <Input value={draft.name || ""} onChange={e => set("name", e.target.value)} />
        </Field>
        <Field label={draft.kind === "individual" ? "Full name (RU)" : "Legal name (RU)"}>
          <Input value={draft.nameRu || ""} onChange={e => set("nameRu", e.target.value)} />
        </Field>
      </div>
      <div className="field-row three">
        <Field label="Country" required>
          <Select value={draft.country || ""} onChange={e => set("country", e.target.value)}>
            <option value="">Select…</option>
            {["RU", "AE", "DE", "GB", "SG", "US", "ZA", "CH"].map(c => <option key={c} value={c}>{c}</option>)}
          </Select>
        </Field>
        <Field label="TIN / INN" required>
          <Input className="mono" value={draft.tin || ""} onChange={e => set("tin", e.target.value)} />
        </Field>
        {draft.country === "RU" && draft.kind !== "individual" && (
          <Field label="KPP">
            <Input className="mono" value={draft.kpp || ""} onChange={e => set("kpp", e.target.value)} />
          </Field>
        )}
      </div>
      <Field label="Registered address">
        <textarea className="input" rows={2} value={draft.address || ""} onChange={e => set("address", e.target.value)} />
      </Field>
      {draft.kind !== "individual" && (
        <div className="field-row two">
          <Field label="Signatory name">
            <Input value={draft.director || ""} onChange={e => set("director", e.target.value)} />
          </Field>
          <Field label="Signatory role">
            <Input value={draft.signatoryRole || ""} onChange={e => set("signatoryRole", e.target.value)} />
          </Field>
        </div>
      )}
      <div className="field-row two">
        <Field label="Email">
          <Input value={draft.email || ""} onChange={e => set("email", e.target.value)} />
        </Field>
        <Field label="Phone">
          <Input className="mono" value={draft.phone || ""} onChange={e => set("phone", e.target.value)} />
        </Field>
      </div>
    </div>
  );
};

/* ================================================================
   Edit dialog — simpler, just the manual form
================================================================ */
const CounterpartyEditDialog = ({ open, item, onClose, onSave }) => {
  const [draft, setDraft] = useState({});
  useEffectCP(() => { if (item) setDraft({ ...item }); }, [item]);
  if (!item) return null;

  return (
    <Modal
      open={open}
      onClose={onClose}
      size="lg"
      title={`Edit · ${item.name}`}
      sub={`${KIND_LABEL[item.kind]} · ${item.id}`}
      foot={
        <>
          <div style={{ fontSize: 12, color: "var(--text-muted)" }}>
            Added by {item.addedBy} on {item.addedAt} · via {SOURCE_BADGE[item.source].label}
          </div>
          <div className="hstack" style={{ gap: 8 }}>
            <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
            <Btn variant="primary" icon="check" onClick={() => onSave(draft)}>Save changes</Btn>
          </div>
        </>
      }
    >
      <ManualEntryMode draft={draft} setDraft={setDraft} />
    </Modal>
  );
};

window.CounterpartiesTab = CounterpartiesTab;
window.SEED_COUNTERPARTIES = SEED_COUNTERPARTIES;
window.CP_KIND_LABEL = KIND_LABEL;
window.CP_KIND_ICON = KIND_ICON;
window.CP_STATUS_BADGE = STATUS_BADGE;
window.CP_SOURCE_BADGE = SOURCE_BADGE;
