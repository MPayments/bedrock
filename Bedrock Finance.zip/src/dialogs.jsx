/* global React, Icon, Btn, IconBtn, Badge, Field, Input, Select, Segmented, Checkbox, CountryPill, cx */
const { useState, useEffect } = React;

/* ========== Modal shell ========== */
const Modal = ({ open, onClose, title, sub, size = "md", children, foot }) => {
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === "Escape") onClose?.(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className={cx("modal", `modal-${size}`)} onClick={e => e.stopPropagation()}>
        <div className="modal-head">
          <div>
            <div className="modal-title">{title}</div>
            {sub && <div className="modal-sub">{sub}</div>}
          </div>
          <IconBtn name="x" onClick={onClose} title="Close" />
        </div>
        <div className="modal-body">{children}</div>
        {foot && <div className="modal-foot">{foot}</div>}
      </div>
    </div>
  );
};

/* ========== Stepper ========== */
const ModalStepper = ({ steps, current, onPick }) => (
  <div className="modal-stepper">
    {steps.map((s, i) => (
      <React.Fragment key={s.key}>
        <button
          type="button"
          className={cx("modal-step", i === current && "active", i < current && "done")}
          onClick={() => onPick?.(i)}>
          <span className="modal-step-num">{i < current ? <Icon name="check" size={11} /> : i + 1}</span>
          <span>{s.label}</span>
        </button>
        {i < steps.length - 1 && <div className="modal-step-sep" />}
      </React.Fragment>
    ))}
  </div>
);

/* ================================================================
   Customer creation dialog
   Minimal identity capture → drops into detail page as draft.
================================================================ */
const CustomerCreateDialog = ({ open, onClose, onCreated }) => {
  const [step, setStep] = useState(0);
  const [values, setValues] = useState({
    entityType: "legal",
    country: "RU",
    baseName: "",
    legalNameRu: "",
    legalNameEn: "",
    tin: "",
    regNumber: "",
    contactName: "",
    contactEmail: "",
    contactPhone: "",
    ownerInitials: "AE",
  });
  const set = (patch) => setValues({ ...values, ...patch });

  const reset = () => { setStep(0); setValues({ ...values, baseName: "", legalNameRu: "", legalNameEn: "", tin: "", regNumber: "", contactName: "", contactEmail: "", contactPhone: "" }); };
  const close = () => { onClose?.(); setTimeout(reset, 200); };

  const steps = [
    { key: "identity", label: "Identity" },
    { key: "contact",  label: "Primary contact" },
    { key: "review",   label: "Review" },
  ];

  const canNext = (() => {
    if (step === 0) return values.baseName.trim().length >= 2 && values.tin.trim().length >= 4;
    if (step === 1) return values.contactEmail.includes("@");
    return true;
  })();

  return (
    <Modal
      open={open} onClose={close}
      title="New customer"
      sub="Capture the legal identity — onboarding tasks continue on the customer page"
      size="lg"
      foot={
        <>
          <div className="hstack" style={{ gap: 12, color: "var(--text-muted)", fontSize: 12 }}>
            <Icon name="info" size={13} />
            <span>You'll be able to edit details and complete KYC on the detail page.</span>
          </div>
          <div className="hstack" style={{ gap: 8 }}>
            <Btn variant="ghost" onClick={close}>Cancel</Btn>
            {step > 0 && <Btn variant="secondary" icon="arrow_left" onClick={() => setStep(step - 1)}>Back</Btn>}
            {step < steps.length - 1
              ? <Btn variant="primary" iconRight="arrow_right" disabled={!canNext} onClick={() => setStep(step + 1)}>Continue</Btn>
              : <Btn variant="primary" icon="check" onClick={() => { onCreated?.(values); close(); }}>Create &amp; open</Btn>}
          </div>
        </>
      }>

      <ModalStepper steps={steps} current={step} onPick={(i) => i <= step && setStep(i)} />

      {step === 0 && (
        <div className="modal-content">
          <Field label="Entity type" required>
            <Segmented value={values.entityType} onChange={v => set({ entityType: v })} options={[
              { value: "legal", label: "Legal entity" },
              { value: "ip",    label: "IP / sole proprietor" },
              { value: "individual", label: "Individual" },
            ]} />
          </Field>
          <div className="field-row two">
            <Field label="Country of registration" required>
              <Select value={values.country} onChange={e => set({ country: e.target.value })}>
                <option value="RU">🇷🇺 Russia</option>
                <option value="AE">🇦🇪 United Arab Emirates</option>
                <option value="SG">🇸🇬 Singapore</option>
                <option value="HK">🇭🇰 Hong Kong</option>
                <option value="TR">🇹🇷 Türkiye</option>
                <option value="KZ">🇰🇿 Kazakhstan</option>
              </Select>
            </Field>
            <Field label="Short / display name" required hint="Used everywhere in lists and search">
              <Input value={values.baseName} onChange={e => set({ baseName: e.target.value })} placeholder="e.g. Nordmax Trading" />
            </Field>
          </div>
          <div className="field-row two">
            <Field label="Legal name (Russian)" hint="As in registration documents">
              <Input value={values.legalNameRu} onChange={e => set({ legalNameRu: e.target.value })} placeholder="ООО «Нордмакс Трейдинг»" />
            </Field>
            <Field label="Legal name (English)" hint="For international contracts">
              <Input value={values.legalNameEn} onChange={e => set({ legalNameEn: e.target.value })} placeholder="Nordmax Trading LLC" />
            </Field>
          </div>
          <div className="field-row two">
            <Field label={values.country === "RU" ? "INN (tax ID)" : "Tax ID / TIN"} required>
              <Input value={values.tin} onChange={e => set({ tin: e.target.value })} placeholder="7701234567" />
            </Field>
            <Field label={values.country === "RU" ? "OGRN (registration number)" : "Registration number"}>
              <Input value={values.regNumber} onChange={e => set({ regNumber: e.target.value })} placeholder="1157746123456" />
            </Field>
          </div>
          <div className="callout">
            <Icon name="info" size={14} />
            <div style={{ fontSize: 12 }}>
              We'll create the customer as <b>Draft</b>. Deals can be drafted immediately, but <b>can't settle</b> until
              KYC is approved and at least one requisite is added.
            </div>
          </div>
        </div>
      )}

      {step === 1 && (
        <div className="modal-content">
          <div className="eyebrow">Primary contact</div>
          <div className="field-row two">
            <Field label="Full name" required>
              <Input value={values.contactName} onChange={e => set({ contactName: e.target.value })} placeholder="Ivan Petrov" />
            </Field>
            <Field label="Role at customer">
              <Select defaultValue="ceo">
                <option value="ceo">CEO / Director</option>
                <option value="cfo">CFO</option>
                <option value="finance">Finance lead</option>
                <option value="ops">Operations</option>
                <option value="other">Other</option>
              </Select>
            </Field>
          </div>
          <div className="field-row two">
            <Field label="Email" required hint="Portal invite will be sent here">
              <Input type="email" value={values.contactEmail} onChange={e => set({ contactEmail: e.target.value })} placeholder="[email protected]" />
            </Field>
            <Field label="Phone (with country code)">
              <Input value={values.contactPhone} onChange={e => set({ contactPhone: e.target.value })} placeholder="+7 495 123 45 67" />
            </Field>
          </div>
          <div className="divider" />
          <div className="eyebrow">Internal assignment</div>
          <div className="field-row two">
            <Field label="Account manager" required>
              <Select value={values.ownerInitials} onChange={e => set({ ownerInitials: e.target.value })}>
                <option value="AE">Anna Ermolova · AE desk</option>
                <option value="SY">Sergey Yanov · Treasury</option>
                <option value="MK">Marko Kovač · Compliance</option>
                <option value="IV">Ivan Volkov · SG desk</option>
              </Select>
            </Field>
            <Field label="Portal invite">
              <Checkbox checked={true} onChange={() => {}} label="Send portal invite on create" />
            </Field>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="modal-content">
          <div className="eyebrow">Review</div>
          <div className="review-grid">
            <div><div className="kv-label">Short name</div><div className="kv-value">{values.baseName || "—"}</div></div>
            <div><div className="kv-label">Entity type</div><div className="kv-value">{values.entityType === "legal" ? "Legal entity" : values.entityType === "ip" ? "IP / sole proprietor" : "Individual"}</div></div>
            <div><div className="kv-label">Country</div><div className="kv-value">{values.country}</div></div>
            <div><div className="kv-label">Tax ID</div><div className="kv-value mono">{values.tin || "—"}</div></div>
            <div><div className="kv-label">Legal RU</div><div className="kv-value">{values.legalNameRu || "—"}</div></div>
            <div><div className="kv-label">Legal EN</div><div className="kv-value">{values.legalNameEn || "—"}</div></div>
            <div><div className="kv-label">Primary contact</div><div className="kv-value">{values.contactName || "—"}<div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>{values.contactEmail}</div></div></div>
            <div><div className="kv-label">Owner</div><div className="kv-value">{values.ownerInitials}</div></div>
          </div>

          <div className="divider" />

          <div className="eyebrow">What happens next</div>
          <div className="onboarding-gates">
            {[
              { icon: "check", tone: "pos", label: "Draft deals", done: true, note: "Identity captured — enough to draft deals" },
              { icon: "dots_horizontal", tone: "warn", label: "Price & calculate", done: false, note: "Needs: one customer requisite" },
              { icon: "lock", tone: "default", label: "Transact live", done: false, note: "Needs: KYC approved + signed agreement" },
            ].map((g, i) => (
              <div key={i} className={cx("onboarding-gate", g.done && "done")}>
                <div className={cx("onboarding-gate-icon", g.tone)}>
                  <Icon name={g.icon} size={13} />
                </div>
                <div>
                  <div className="onboarding-gate-label">{g.label}</div>
                  <div className="onboarding-gate-note">{g.note}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </Modal>
  );
};

/* ================================================================
   Deal creation dialog
   Lands the deal in "Pricing" stage.
================================================================ */
const DealCreateDialog = ({ open, onClose, onCreated }) => {
  const [step, setStep] = useState(0);
  const [v, setV] = useState({
    customerId: "CUS-0042",
    beneficiaryMode: "existing", // existing | new
    beneficiaryId: "CP-2101",
    newBeneficiaryName: "",
    newBeneficiaryCountry: "AE",
    direction: "outbound",
    gross: 142000,
    sourceCcy: "RUB",
    targetCcy: "USD",
    purpose: "goods",
    purposeText: "Payment for electronics equipment per Invoice INV-2201",
    requestedDate: "2026-04-21",
    preferredRoute: "RT-081",
    notes: "",
  });
  const set = (patch) => setV({ ...v, ...patch });
  const close = () => { onClose?.(); setTimeout(() => setStep(0), 200); };

  const steps = [
    { key: "parties", label: "Parties" },
    { key: "money",   label: "Money" },
    { key: "route",   label: "Route & purpose" },
  ];

  return (
    <Modal
      open={open} onClose={close}
      title="New deal"
      sub="Captures the commercial intent — lands in Pricing stage"
      size="lg"
      foot={
        <>
          <div className="hstack" style={{ gap: 12, color: "var(--text-muted)", fontSize: 12 }}>
            <Badge tone="info" outline dot>Pricing</Badge>
            <span>You'll be able to prepare the initial offer on the deal page.</span>
          </div>
          <div className="hstack" style={{ gap: 8 }}>
            <Btn variant="ghost" onClick={close}>Cancel</Btn>
            {step > 0 && <Btn variant="secondary" icon="arrow_left" onClick={() => setStep(step - 1)}>Back</Btn>}
            {step < steps.length - 1
              ? <Btn variant="primary" iconRight="arrow_right" onClick={() => setStep(step + 1)}>Continue</Btn>
              : <Btn variant="primary" icon="check" onClick={() => { onCreated?.(v); close(); }}>Create deal</Btn>}
          </div>
        </>
      }>

      <ModalStepper steps={steps} current={step} onPick={(i) => i <= step && setStep(i)} />

      {step === 0 && (
        <div className="modal-content">
          <Field label="Customer" required hint="Who is paying us">
            <Select value={v.customerId} onChange={e => set({ customerId: e.target.value })}>
              <option value="CUS-0042">Nordmax Trading LLC · RU · active</option>
              <option value="CUS-0038">Volga Materials JSC · RU · active</option>
              <option value="CUS-0051">Prism Holdings Ltd · AE · active</option>
              <option value="CUS-0077">Ural Trade House · RU · onboarding</option>
            </Select>
          </Field>

          <div className="divider" />

          <div className="eyebrow">Beneficiary</div>
          <Segmented value={v.beneficiaryMode} onChange={val => set({ beneficiaryMode: val })} options={[
            { value: "existing", label: "Pick existing counterparty" },
            { value: "new",      label: "New beneficiary (quick capture)" },
          ]} />

          {v.beneficiaryMode === "existing" ? (
            <Field label="Counterparty">
              <Select value={v.beneficiaryId} onChange={e => set({ beneficiaryId: e.target.value })}>
                <option value="CP-2101">Lotus Global FZE · AE · last used Apr 10</option>
                <option value="CP-2108">Karim Electronics LLC · AE</option>
                <option value="CP-3012">Shenzhen Bright Co. Ltd · CN</option>
                <option value="CP-3042">Atlas Machinery BV · NL</option>
              </Select>
            </Field>
          ) : (
            <div className="vstack" style={{ gap: 12 }}>
              <div className="field-row two">
                <Field label="Beneficiary name" required>
                  <Input value={v.newBeneficiaryName} onChange={e => set({ newBeneficiaryName: e.target.value })} placeholder="e.g. Acme Trading FZE" />
                </Field>
                <Field label="Country" required>
                  <Select value={v.newBeneficiaryCountry} onChange={e => set({ newBeneficiaryCountry: e.target.value })}>
                    <option value="AE">🇦🇪 United Arab Emirates</option>
                    <option value="CN">🇨🇳 China</option>
                    <option value="NL">🇳🇱 Netherlands</option>
                    <option value="TR">🇹🇷 Türkiye</option>
                    <option value="IN">🇮🇳 India</option>
                  </Select>
                </Field>
              </div>
              <div className="callout">
                <Icon name="info" size={14} />
                <div style={{ fontSize: 12 }}>
                  Requisites (IBAN, SWIFT, etc.) will be captured on the deal page during <b>Pricing</b> — no need to block the customer now.
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {step === 1 && (
        <div className="modal-content">
          <Field label="Direction" required>
            <Segmented value={v.direction} onChange={val => set({ direction: val })} options={[
              { value: "outbound", label: "Outbound — customer pays beneficiary" },
              { value: "inbound",  label: "Inbound — beneficiary pays customer" },
            ]} />
          </Field>
          <div className="field-row three">
            <Field label="Gross amount" required>
              <Input type="number" value={v.gross} onChange={e => set({ gross: +e.target.value })} />
            </Field>
            <Field label="Source currency" required hint="What customer sends">
              <Select value={v.sourceCcy} onChange={e => set({ sourceCcy: e.target.value })}>
                <option>RUB</option><option>USD</option><option>EUR</option><option>AED</option><option>CNY</option>
              </Select>
            </Field>
            <Field label="Target currency" required hint="What beneficiary receives">
              <Select value={v.targetCcy} onChange={e => set({ targetCcy: e.target.value })}>
                <option>USD</option><option>EUR</option><option>AED</option><option>CNY</option><option>RUB</option>
              </Select>
            </Field>
          </div>
          <div className="callout">
            <Icon name="exchange" size={14} />
            <div style={{ fontSize: 12 }}>
              Indicative: at current mid rate <b className="mono">92.44</b>, beneficiary would receive ≈{" "}
              <b className="mono">{Math.round(v.gross / 92.44).toLocaleString()} {v.targetCcy}</b> before fees.
              Final pricing is set in the next stage.
            </div>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="modal-content">
          <div className="field-row two">
            <Field label="Requested settlement date" required>
              <Input type="date" value={v.requestedDate} onChange={e => set({ requestedDate: e.target.value })} />
            </Field>
            <Field label="Preferred route" hint="Can be swapped later">
              <Select value={v.preferredRoute} onChange={e => set({ preferredRoute: e.target.value })}>
                <option value="RT-081">RT-081 · RU → AE standard (USD/AED)</option>
                <option value="RT-042">RT-042 · RU → CN via HK</option>
                <option value="RT-110">RT-110 · EU → RU inbound</option>
                <option value="auto">Auto-pick best route</option>
              </Select>
            </Field>
          </div>
          <Field label="Purpose of payment" required hint="Shown to compliance, printed on SWIFT 70">
            <Select value={v.purpose} onChange={e => set({ purpose: e.target.value })}>
              <option value="goods">Goods — imports / exports</option>
              <option value="services">Services</option>
              <option value="intercompany">Intercompany transfer</option>
              <option value="dividend">Dividend</option>
              <option value="other">Other</option>
            </Select>
          </Field>
          <Field label="Purpose details" required hint="Free-text description that will appear on documents">
            <textarea className="input" rows={3} value={v.purposeText} onChange={e => set({ purposeText: e.target.value })} />
          </Field>
          <Field label="Internal notes (not shown to customer)">
            <Input value={v.notes} onChange={e => set({ notes: e.target.value })} placeholder="e.g. Priority client — do not delay beyond Apr 22" />
          </Field>
        </div>
      )}
    </Modal>
  );
};

window.Modal = Modal;
window.ModalStepper = ModalStepper;
window.CustomerCreateDialog = CustomerCreateDialog;
window.DealCreateDialog = DealCreateDialog;
