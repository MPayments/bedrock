/* global React */

// Mock data — realistic enough for the prototype; bilingual where relevant.

const CUSTOMERS = [
  { id: "CUS-0042", base: "Nordmax Trading LLC", ru: "ООО «Нордмакс Трейдинг»", en: "Nordmax Trading LLC", country: "AE", tin: "100456789700003", segment: "SME", status: "active", ownerInitials: "AE", balance: 128_450.22, ccy: "USD", lastDeal: "2 days ago" },
  { id: "CUS-0043", base: "Ursa Industrial OOO", ru: "ООО «Урса Индастриал»", en: "Ursa Industrial LLC", country: "RU", tin: "7701234567", segment: "Mid-market", status: "active", ownerInitials: "MK", balance: -8_124.50, ccy: "EUR", lastDeal: "today" },
  { id: "CUS-0044", base: "Bluefield Holdings", ru: "Блюфилд Холдингс", en: "Bluefield Holdings Ltd", country: "GB", tin: "GB324561231", segment: "Enterprise", status: "active", ownerInitials: "AE", balance: 892_001.00, ccy: "USD", lastDeal: "1 week ago" },
  { id: "CUS-0045", base: "Dalniy Vostok Export", ru: "ООО «Дальний Восток Экспорт»", en: "Dalniy Vostok Export", country: "RU", tin: "2540987654", segment: "SME", status: "onboarding", ownerInitials: "SY", balance: 0, ccy: "RUB", lastDeal: "—" },
  { id: "CUS-0046", base: "Atlas Polymers", ru: "Атлас Полимерс", en: "Atlas Polymers AG", country: "DE", tin: "DE812345678", segment: "Mid-market", status: "active", ownerInitials: "MK", balance: 45_201.18, ccy: "EUR", lastDeal: "3 days ago" },
  { id: "CUS-0047", base: "Harbor Logistics FZE", ru: "Харбор Лоджистикс", en: "Harbor Logistics FZE", country: "AE", tin: "100112233445", segment: "SME", status: "suspended", ownerInitials: "AE", balance: 0, ccy: "AED", lastDeal: "2 months ago" },
  { id: "CUS-0048", base: "Severnaya Stal", ru: "ОАО «Северная Сталь»", en: "Severnaya Stal JSC", country: "RU", tin: "7830004567", segment: "Enterprise", status: "active", ownerInitials: "SY", balance: 2_410_998.74, ccy: "USD", lastDeal: "yesterday" },
  { id: "CUS-0049", base: "Meridian Commodities", ru: "Меридиан Коммодитис", en: "Meridian Commodities Pte", country: "SG", tin: "SG2019004521", segment: "Mid-market", status: "active", ownerInitials: "AE", balance: 301_440.00, ccy: "SGD", lastDeal: "4 days ago" },
  { id: "CUS-0050", base: "KoraTech OOO", ru: "ООО «КораТех»", en: "KoraTech LLC", country: "RU", tin: "5024801234", segment: "SME", status: "active", ownerInitials: "MK", balance: 18_700.55, ccy: "USD", lastDeal: "5 days ago" },
  { id: "CUS-0051", base: "Obsidian Mining", ru: "Обсидиан Майнинг", en: "Obsidian Mining Ltd", country: "ZA", tin: "ZA432109876", segment: "Enterprise", status: "active", ownerInitials: "SY", balance: 1_201_440.30, ccy: "USD", lastDeal: "today" },
];

const DEALS = [
  { id: "DL-4401", customer: "Nordmax Trading LLC", route: "RU → AE (USD)", amount: 142_000, ccy: "USD", stage: "funding", rate: 0.9872, fee: 1_960, profit: 1_240, due: "Apr 22", owner: "AE" },
  { id: "DL-4402", customer: "Severnaya Stal JSC", route: "RU → DE (EUR)", amount: 820_500, ccy: "EUR", stage: "approval", rate: 0.9341, fee: 9_820, profit: 6_450, due: "Apr 23", owner: "SY" },
  { id: "DL-4403", customer: "Atlas Polymers AG", route: "DE → AE (USD)", amount: 64_200, ccy: "USD", stage: "pricing", rate: 1.0812, fee: 855, profit: 540, due: "Apr 24", owner: "MK" },
  { id: "DL-4404", customer: "Meridian Commodities Pte", route: "SG → AE (AED)", amount: 210_000, ccy: "AED", stage: "calculating", rate: 3.6725, fee: 2_400, profit: 1_770, due: "Apr 25", owner: "AE" },
  { id: "DL-4405", customer: "Bluefield Holdings Ltd", route: "GB → RU (USD)", amount: 1_450_000, ccy: "USD", stage: "settled", rate: 1.2531, fee: 14_800, profit: 11_220, due: "Apr 18", owner: "AE" },
  { id: "DL-4406", customer: "KoraTech LLC", route: "RU → SG (USD)", amount: 28_000, ccy: "USD", stage: "funding", rate: 0.9870, fee: 420, profit: 260, due: "Apr 22", owner: "MK" },
  { id: "DL-4407", customer: "Ursa Industrial LLC", route: "RU → AE (AED)", amount: 96_400, ccy: "AED", stage: "rejected", rate: 3.6720, fee: 1_050, profit: -180, due: "Apr 21", owner: "MK" },
  { id: "DL-4408", customer: "Obsidian Mining Ltd", route: "ZA → GB (USD)", amount: 640_300, ccy: "USD", stage: "approval", rate: 0.0542, fee: 7_340, profit: 4_980, due: "Apr 24", owner: "SY" },
];

const STAGE_LABEL = {
  pricing: "Pricing",
  calculating: "Calculating",
  approval: "Approval",
  funding: "Funding",
  settled: "Settled",
  rejected: "Rejected",
};

const STAGE_BADGE = {
  pricing: "info",
  calculating: "info",
  approval: "warn",
  funding: "info",
  settled: "pos",
  rejected: "neg",
};

const COUNTERPARTIES = [
  { id: "CP-2101", base: "Lotus Global FZE", ru: "Лотус Глобал", en: "Lotus Global FZE", type: "Buyer", country: "AE", customer: "Nordmax Trading LLC", requisites: 3, status: "active" },
  { id: "CP-2102", base: "Vega Metal Works", ru: "ООО «Вега Металл»", en: "Vega Metal Works LLC", type: "Supplier", country: "RU", customer: "Severnaya Stal JSC", requisites: 2, status: "active" },
  { id: "CP-2103", base: "Polaris Chem", ru: "Полярис Кем", en: "Polaris Chem GmbH", type: "Buyer", country: "DE", customer: "Atlas Polymers AG", requisites: 1, status: "review" },
  { id: "CP-2104", base: "Delta Shipping", ru: "Дельта Шиппинг", en: "Delta Shipping Pte", type: "Buyer", country: "SG", customer: "Meridian Commodities Pte", requisites: 2, status: "active" },
  { id: "CP-2105", base: "Ironhill Ltd", ru: "Айронхилл", en: "Ironhill Ltd", type: "Supplier", country: "GB", customer: "Bluefield Holdings Ltd", requisites: 4, status: "active" },
  { id: "CP-2106", base: "Kairos Minerals", ru: "Кайрос Минералс", en: "Kairos Minerals SA", type: "Buyer", country: "ZA", customer: "Obsidian Mining Ltd", requisites: 2, status: "active" },
  { id: "CP-2107", base: "Birch Trade", ru: "Бёрч Трейд", en: "Birch Trade LLC", type: "Buyer", country: "RU", customer: "KoraTech LLC", requisites: 1, status: "draft" },
  { id: "CP-2108", base: "Orion Foods", ru: "Орион Фудс", en: "Orion Foods", type: "Supplier", country: "RU", customer: "Ursa Industrial LLC", requisites: 2, status: "active" },
];

const REQUISITES = [
  // --- Counterparty-held requisites (shown in CRM customer → counterparty) ---
  {
    id: "REQ-5101",
    providerId: "PRV-001", // Raiffeisenbank (ru_bank)
    holderRef: { kind: "counterparty", id: "CP-2102", name: "Nordmax Trading LLC", country: "RU" },
    ccy: "RUB",
    nickname: "Primary RUB account",
    account: "40702 810 3 0000 0012345",
    accountHolderName: "ООО «Нордмакс Трейдинг»",
    accountType: "settlement",
    purpose: "Оплата по договору №___ от ___, в т.ч. НДС 20%",
    primary: true,
    status: "verified",
    verifiedAt: "2025-09-04",
    allowedFor: { incoming: true, outgoing: true, refunds: false, salary: false },
  },
  {
    id: "REQ-5102",
    providerId: "PRV-002", // VTB Bank (ru_bank)
    holderRef: { kind: "counterparty", id: "CP-2102", name: "Nordmax Trading LLC", country: "RU" },
    ccy: "USD",
    nickname: "USD correspondent",
    account: "40702 840 9 0000 0099321",
    accountHolderName: "ООО «Нордмакс Трейдинг»",
    accountType: "currency",
    primary: false,
    status: "verified",
    verifiedAt: "2025-09-11",
    allowedFor: { incoming: true, outgoing: true, refunds: false, salary: false },
  },
  {
    id: "REQ-5103",
    providerId: "PRV-001",
    holderRef: { kind: "counterparty", id: "CP-2102", name: "Nordmax Trading LLC", country: "RU" },
    ccy: "RUB",
    nickname: "Backup RUB",
    account: "40702 810 5 0000 0055412",
    accountHolderName: "ООО «Нордмакс Трейдинг»",
    primary: false,
    status: "pending",
    allowedFor: { incoming: true, outgoing: false, refunds: false, salary: false },
  },
  {
    id: "REQ-5111",
    providerId: "PRV-004", // Emirates NBD (swift_bank)
    holderRef: { kind: "counterparty", id: "CP-2101", name: "Lotus Global FZE", country: "AE" },
    ccy: "USD",
    nickname: "FAB · operating USD",
    iban: "AE07 0331 2345 6789 012",
    accountHolderName: "Lotus Global FZE",
    beneficiaryAddress: "Office 2201, Emirates Towers, Sheikh Zayed Rd, Dubai, UAE",
    charges: "OUR",
    purposeCode: "GDSV",
    primary: true,
    status: "verified",
    verifiedAt: "2024-12-02",
    allowedFor: { incoming: true, outgoing: true, refunds: false, salary: false },
  },
  {
    id: "REQ-5112",
    providerId: "PRV-004",
    holderRef: { kind: "counterparty", id: "CP-2101", name: "Lotus Global FZE", country: "AE" },
    ccy: "AED",
    nickname: "Emirates NBD · AED",
    iban: "AE55 0260 0010 0100 3412 089",
    accountHolderName: "Lotus Global FZE",
    beneficiaryAddress: "Office 2201, Emirates Towers, Sheikh Zayed Rd, Dubai, UAE",
    charges: "SHA",
    purposeCode: "GDSV",
    primary: false,
    status: "verified",
    verifiedAt: "2025-02-14",
    allowedFor: { incoming: true, outgoing: true, refunds: false, salary: false },
  },
  {
    id: "REQ-5121",
    providerId: "PRV-005", // Commerzbank (swift_bank)
    holderRef: { kind: "counterparty", id: "CP-2104", name: "Alpine Metals GmbH", country: "DE" },
    ccy: "EUR",
    nickname: "Commerzbank · EUR",
    iban: "DE89 3704 0044 0532 0130 00",
    accountHolderName: "Alpine Metals GmbH",
    beneficiaryAddress: "Arnulfstrasse 30, 80335 München, Germany",
    charges: "SHA",
    purposeCode: "GDSV",
    primary: true,
    status: "verified",
    verifiedAt: "2025-11-15",
    allowedFor: { incoming: true, outgoing: true, refunds: false, salary: false },
  },
  {
    id: "REQ-5122",
    providerId: "PRV-005",
    holderRef: { kind: "counterparty", id: "CP-2104", name: "Alpine Metals GmbH", country: "DE" },
    ccy: "EUR",
    nickname: "Backup · Commerzbank",
    iban: "DE42 7002 0270 0032 7601 81",
    accountHolderName: "Alpine Metals GmbH",
    beneficiaryAddress: "Arnulfstrasse 30, 80335 München, Germany",
    primary: false,
    status: "expired",
    verifiedAt: "2024-06-01",
    allowedFor: { incoming: true, outgoing: false, refunds: false, salary: false },
  },
  {
    id: "REQ-5131",
    providerId: "PRV-003", // Tinkoff (ru_bank)
    holderRef: { kind: "counterparty", id: "CP-2103", name: "Dmitri Volkov", country: "RU" },
    ccy: "RUB",
    nickname: "Tinkoff · personal",
    account: "40817 810 1 0000 0099123",
    accountHolderName: "Волков Д.А.",
    accountType: "settlement",
    primary: true,
    status: "pending",
    allowedFor: { incoming: true, outgoing: false, refunds: false, salary: false },
  },

  // --- Customer-held requisites (also surface in Finance list) ---
  {
    id: "REQ-5012",
    providerId: "PRV-004",
    holderRef: { kind: "customer", id: "CUS-0042", name: "Nordmax Trading LLC", country: "AE" },
    ccy: "USD",
    nickname: "Primary · Emirates NBD",
    iban: "AE07 0331 2345 6789 012",
    accountHolderName: "Nordmax Trading LLC",
    beneficiaryAddress: "Office 2201, Emirates Towers, Dubai, UAE",
    charges: "OUR",
    purposeCode: "GDSV",
    primary: true,
    status: "verified",
    verifiedAt: "2024-10-12",
    allowedFor: { incoming: true, outgoing: true, refunds: false, salary: false },
  },
  {
    id: "REQ-5013",
    providerId: "PRV-002",
    holderRef: { kind: "customer", id: "CUS-0048", name: "Severnaya Stal JSC", country: "RU" },
    ccy: "RUB",
    nickname: "Primary · VTB",
    account: "40702 810 9 0000 0012345",
    accountHolderName: "ОАО «Северная Сталь»",
    accountType: "settlement",
    primary: true,
    status: "verified",
    verifiedAt: "2025-04-01",
    allowedFor: { incoming: true, outgoing: true, refunds: false, salary: false },
  },
  {
    id: "REQ-5014",
    providerId: "PRV-005",
    holderRef: { kind: "customer", id: "CUS-0046", name: "Atlas Polymers AG", country: "DE" },
    ccy: "EUR",
    nickname: "Primary · Commerzbank",
    iban: "DE89 3704 0044 0532 0130 00",
    accountHolderName: "Atlas Polymers AG",
    beneficiaryAddress: "Frankfurt am Main, DE",
    primary: true,
    status: "verified",
    verifiedAt: "2025-05-22",
    allowedFor: { incoming: true, outgoing: true, refunds: false, salary: false },
  },
  {
    id: "REQ-5017",
    providerId: "PRV-008", // USDT TRON (blockchain)
    holderRef: { kind: "customer", id: "CUS-0051", name: "Obsidian Mining Ltd", country: "ZA" },
    ccy: "USDT",
    nickname: "Treasury · USDT TRC-20",
    walletAddress: "TXyZ9mK2fVqLpRsT4uN8aB3cDeFgHjK1Lm",
    primary: true,
    status: "verified",
    verifiedAt: "2025-07-18",
    allowedFor: { incoming: true, outgoing: true, refunds: false, salary: false },
  },
  {
    id: "REQ-5018",
    providerId: "PRV-003",
    holderRef: { kind: "customer", id: "CUS-0050", name: "KoraTech LLC", country: "RU" },
    ccy: "RUB",
    nickname: "Tinkoff · operating",
    account: "40702 810 3 0000 0099876",
    accountHolderName: "ООО «КораТех»",
    accountType: "settlement",
    primary: true,
    status: "verified",
    verifiedAt: "2025-08-02",
    allowedFor: { incoming: true, outgoing: true, refunds: false, salary: false },
  },
  {
    id: "REQ-5019",
    providerId: "PRV-002",
    holderRef: { kind: "customer", id: "CUS-0043", name: "Ursa Industrial LLC", country: "RU" },
    ccy: "RUB",
    nickname: "VTB · operating",
    account: "40702 810 7 0000 0055621",
    accountHolderName: "ООО «Урса Индастриал»",
    accountType: "settlement",
    primary: true,
    status: "expired",
    verifiedAt: "2024-08-15",
    allowedFor: { incoming: true, outgoing: false, refunds: false, salary: false },
  },

  // --- Own-organization requisites ---
  {
    id: "REQ-5201",
    providerId: "PRV-004",
    holderRef: { kind: "organization", id: "ORG-AE", name: "Bedrock AE Holding", country: "AE" },
    ccy: "USD",
    nickname: "AE operating · USD",
    iban: "AE07 0260 0010 0100 3412 001",
    accountHolderName: "Bedrock AE Holding",
    beneficiaryAddress: "Cluster Y, JLT, Dubai, UAE",
    charges: "SHA",
    purposeCode: "SERV",
    primary: true,
    status: "verified",
    verifiedAt: "2024-01-20",
    allowedFor: { incoming: true, outgoing: true, refunds: true, salary: true },
  },
];

const BALANCES = [
  { org: "Bedrock AE Holding", account: "Emirates NBD · 0040-0112", ccy: "USD", available: 4_892_332.12, blocked: 212_000.00, total: 5_104_332.12, spark: [70,72,74,71,78,82,86,84,88,92,95,98] },
  { org: "Bedrock AE Holding", account: "Emirates NBD · 0040-0114", ccy: "AED", available: 12_104_881.55, blocked: 480_000.00, total: 12_584_881.55, spark: [40,44,46,48,52,55,52,58,60,62,64,66] },
  { org: "Bedrock EU GmbH", account: "Commerzbank · 2230-8814", ccy: "EUR", available: 2_201_445.00, blocked: 0, total: 2_201_445.00, spark: [60,58,59,61,60,62,64,66,65,68,70,72] },
  { org: "Bedrock EU GmbH", account: "Unicredit · 4401-0012", ccy: "EUR", available: 880_122.44, blocked: 12_000, total: 892_122.44, spark: [50,52,51,53,55,56,58,60,61,63,64,66] },
  { org: "Bedrock RU Invest", account: "Raiffeisen · 40702-0811", ccy: "RUB", available: 312_440_220.00, blocked: 8_200_000, total: 320_640_220.00, spark: [30,32,34,33,35,38,40,42,41,44,46,48] },
  { org: "Bedrock SG Pte", account: "DBS · 003-123456-7", ccy: "SGD", available: 1_001_220.80, blocked: 0, total: 1_001_220.80, spark: [20,22,25,26,28,30,32,34,36,38,40,42] },
];

const RATES = [
  { pair: "USD/RUB", mid: 92.44, buy: 92.12, sell: 92.76, change: +0.0043, source: "MOEX+EBS", updated: "34s ago", spark: [90,91,91,92,92,91,92,93,92,93,92,92] },
  { pair: "EUR/RUB", mid: 98.81, buy: 98.54, sell: 99.12, change: +0.0012, source: "MOEX+EBS", updated: "34s ago", spark: [97,98,98,99,99,98,99,99,99,99,98,99] },
  { pair: "AED/RUB", mid: 25.16, buy: 25.08, sell: 25.24, change: -0.0021, source: "CBR+EBS", updated: "1m ago", spark: [26,26,25,25,25,25,25,25,25,25,25,25] },
  { pair: "USD/AED", mid: 3.6725, buy: 3.6715, sell: 3.6735, change: 0, source: "Reuters", updated: "4m ago", spark: [36,36,36,36,36,36,36,36,36,36,36,36] },
  { pair: "EUR/USD", mid: 1.0721, buy: 1.0713, sell: 1.0729, change: -0.0018, source: "Reuters", updated: "18s ago", spark: [108,108,107,107,107,107,107,107,107,107,107,107] },
  { pair: "GBP/USD", mid: 1.2531, buy: 1.2521, sell: 1.2541, change: +0.0041, source: "Reuters", updated: "18s ago", spark: [124,125,124,125,125,125,125,125,125,125,126,125] },
  { pair: "USD/SGD", mid: 1.3482, buy: 1.3478, sell: 1.3487, change: +0.0006, source: "Reuters", updated: "22s ago", spark: [135,135,135,134,134,134,135,135,135,135,135,135] },
  { pair: "USD/ZAR", mid: 18.452, buy: 18.430, sell: 18.474, change: -0.0083, source: "Reuters", updated: "22s ago", spark: [186,185,185,184,184,184,184,184,184,184,184,184] },
];

const ROUTES = [
  {
    id: "RT-081", name: "RU→AE standard (USD/AED)", legs: 3, margin: "1.15%", uses: 312, status: "live",
    corridor: "RU → AE", in_ccy: "RUB", out_ccy: "USD", settlement: "1.8 days",
    flow: [
      { role: "Customer", title: "Sender", sub: "RUB · RU" },
      { role: "Bedrock", title: "Raiffeisen RU", sub: "RUB collection", fee: "0.35%" },
      { role: "Bedrock", title: "RU→USD FX", sub: "8 bps spread", fee: "8 bps" },
      { role: "Bedrock", title: "Emirates NBD", sub: "USD internal", fee: "0.60%" },
      { role: "Beneficiary", title: "Payout", sub: "USD · AE", fee: "$85" },
    ],
  },
  {
    id: "RT-082", name: "EU→RU priority (EUR)", legs: 4, margin: "1.40%", uses: 88, status: "live",
    corridor: "EU → RU", in_ccy: "EUR", out_ccy: "RUB", settlement: "2.3 days",
    flow: [
      { role: "Customer", title: "Sender", sub: "EUR · DE" },
      { role: "Bedrock", title: "Commerzbank AG", sub: "EUR collection", fee: "0.45%" },
      { role: "Bedrock", title: "EUR→USD FX", sub: "12 bps spread", fee: "12 bps" },
      { role: "Bedrock", title: "USD→RUB FX", sub: "15 bps spread", fee: "15 bps" },
      { role: "Beneficiary", title: "VTB Bank", sub: "RUB · RU", fee: "0.40%" },
    ],
  },
  {
    id: "RT-083", name: "SG→AE low-touch (SGD)", legs: 2, margin: "0.95%", uses: 146, status: "live",
    corridor: "SG → AE", in_ccy: "SGD", out_ccy: "USD", settlement: "0.9 days",
    flow: [
      { role: "Customer", title: "Sender", sub: "SGD · SG" },
      { role: "Bedrock", title: "DBS Bank", sub: "SGD→USD FX", fee: "0.65%" },
      { role: "Beneficiary", title: "Emirates NBD", sub: "USD · AE", fee: "$60" },
    ],
  },
  {
    id: "RT-084", name: "ZA→GB mining corridor", legs: 5, margin: "1.60%", uses: 41, status: "draft",
    corridor: "ZA → GB", in_ccy: "ZAR", out_ccy: "GBP", settlement: "3.1 days",
    flow: [
      { role: "Customer", title: "Sender", sub: "ZAR · ZA" },
      { role: "Bedrock", title: "Standard Bank", sub: "ZAR collection", fee: "0.55%" },
      { role: "Bedrock", title: "ZAR→USD FX", sub: "18 bps spread", fee: "18 bps" },
      { role: "Bedrock", title: "USD transfer", sub: "Intermediary", fee: "$45" },
      { role: "Bedrock", title: "USD→GBP FX", sub: "10 bps spread", fee: "10 bps" },
      { role: "Beneficiary", title: "HSBC UK", sub: "GBP · GB", fee: "0.30%" },
    ],
  },
  {
    id: "RT-085", name: "RU→DE energy (EUR)", legs: 4, margin: "1.25%", uses: 210, status: "live",
    corridor: "RU → DE", in_ccy: "RUB", out_ccy: "EUR", settlement: "2.1 days",
    flow: [
      { role: "Customer", title: "Sender", sub: "RUB · RU" },
      { role: "Bedrock", title: "Tinkoff Bank", sub: "RUB collection", fee: "0.40%" },
      { role: "Bedrock", title: "RUB→EUR FX", sub: "14 bps spread", fee: "14 bps" },
      { role: "Bedrock", title: "Commerzbank AG", sub: "EUR internal", fee: "0.50%" },
      { role: "Beneficiary", title: "Payout", sub: "EUR · DE", fee: "$75" },
    ],
  },
];

// --- Providers -------------------------------------------------------------

// Provider kinds drive which fields are visible on both
// the Provider form and the Requisite form that references it.
const PROVIDER_KINDS = [
  { value: "ru_bank",        label: "Russian bank",             hint: "BIC, correspondent account, INN, KPP",                 countries: ["RU"] },
  { value: "swift_bank",     label: "International bank (SWIFT)", hint: "SWIFT/BIC, IBAN, sometimes ABA/SortCode",             countries: ["ANY"] },
  { value: "local_scheme",   label: "Local clearing scheme",    hint: "Country-specific (ABA/SortCode/BSB/IFSC)",              countries: ["ANY"] },
  { value: "psp",            label: "Payment service provider", hint: "API integration, merchant account",                    countries: ["ANY"] },
  { value: "e_wallet",       label: "E-wallet",                 hint: "Wallet ID + holder email",                              countries: ["ANY"] },
  { value: "card_processor", label: "Card acquirer",            hint: "MID, terminal, scheme",                                 countries: ["ANY"] },
  { value: "blockchain",     label: "Blockchain / crypto",      hint: "Network + wallet address only",                         countries: ["ANY"] },
  { value: "cash_desk",      label: "Cash desk",                hint: "Physical location, operator, limit",                    countries: ["ANY"] },
];

const PROVIDERS = [
  { id: "PRV-001", kind: "ru_bank",        name: "Raiffeisenbank",   country: "RU", bic: "044525700", corr: "30101810200000000700", inn: "7744000912", kpp: "770401001", ccy: ["RUB", "USD", "EUR"], status: "active" },
  { id: "PRV-002", kind: "ru_bank",        name: "VTB Bank",         country: "RU", bic: "044525187", corr: "30101810700000000187", inn: "7702070139", kpp: "770801001", ccy: ["RUB", "USD"], status: "active" },
  { id: "PRV-003", kind: "ru_bank",        name: "Tinkoff Bank",     country: "RU", bic: "044525974", corr: "30101810145250000974", inn: "7710140679", kpp: "771301001", ccy: ["RUB"], status: "active" },
  { id: "PRV-004", kind: "swift_bank",     name: "Emirates NBD",     country: "AE", swift: "EBILAEAD", iban_prefix: "AE07", intermediary: "Citibank N.A. NY", ccy: ["USD", "AED", "EUR"], status: "active" },
  { id: "PRV-005", kind: "swift_bank",     name: "Commerzbank AG",   country: "DE", swift: "COBADEFF", iban_prefix: "DE89", ccy: ["EUR", "USD"], status: "active" },
  { id: "PRV-006", kind: "swift_bank",     name: "DBS Bank",         country: "SG", swift: "DBSSSGSG", iban_prefix: "SG", ccy: ["SGD", "USD"], status: "active" },
  { id: "PRV-007", kind: "swift_bank",     name: "HSBC UK",          country: "GB", swift: "HBUKGB4B", sort_code: "40-05-15", ccy: ["GBP", "USD", "EUR"], status: "active" },
  { id: "PRV-008", kind: "blockchain",     name: "USDT / TRON",      country: "ANY", network: "TRC-20", confirmations: 20, ccy: ["USDT"], status: "active" },
  { id: "PRV-009", kind: "blockchain",     name: "USDC / Ethereum",  country: "ANY", network: "ERC-20", confirmations: 12, ccy: ["USDC"], status: "active" },
  { id: "PRV-010", kind: "psp",            name: "Checkout.com",     country: "ANY", api_key_tail: "••••7e8a", webhook: "https://bedrock/cko", ccy: ["USD", "EUR", "GBP"], status: "active" },
  { id: "PRV-011", kind: "cash_desk",      name: "AE · Dubai JLT desk", country: "AE", address: "Cluster Y, Tower 3, JLT, Dubai", operator: "Rashid Al-Mansouri", limit_usd: 50_000, ccy: ["USD", "AED"], status: "active" },
  { id: "PRV-012", kind: "e_wallet",       name: "Payeer",           country: "ANY", ccy: ["USD", "EUR"], status: "review" },
];

// --- Rate sources ----------------------------------------------------------

const RATE_SOURCES = [
  { id: "cbr",       name: "CBR (Bank of Russia)",  region: "RU",   kind: "official",  freq: "daily 12:00 MSK", covers: ["USD/RUB","EUR/RUB","AED/RUB","CNY/RUB","GBP/RUB"], latency: "next-day" },
  { id: "moex",      name: "MOEX",                  region: "RU",   kind: "exchange",  freq: "live (tick)",      covers: ["USD/RUB","EUR/RUB","CNY/RUB"], latency: "live" },
  { id: "investing", name: "Investing.com",         region: "Global", kind: "aggregator", freq: "1 min",          covers: ["USD/*","EUR/*","GBP/*"], latency: "1min" },
  { id: "reuters",   name: "Reuters WM/Refinitiv",  region: "Global", kind: "pro-feed",   freq: "live (tick)",    covers: ["*"], latency: "live" },
  { id: "ebs",       name: "EBS",                   region: "Global", kind: "pro-feed",   freq: "live (tick)",    covers: ["USD/*","EUR/*"], latency: "live" },
  { id: "manual",    name: "Manual override",       region: "—",    kind: "internal",  freq: "on demand",          covers: ["*"], latency: "—" },
];

// Default source routing — per currency pair
const RATE_DEFAULTS = [
  { pair: "USD/RUB", source: "cbr",       fallback: "moex",      markup_bps: 15 },
  { pair: "EUR/RUB", source: "cbr",       fallback: "moex",      markup_bps: 18 },
  { pair: "AED/RUB", source: "cbr",       fallback: "investing", markup_bps: 22 },
  { pair: "GBP/RUB", source: "cbr",       fallback: "investing", markup_bps: 22 },
  { pair: "CNY/RUB", source: "moex",      fallback: "cbr",       markup_bps: 20 },
  { pair: "USD/AED", source: "investing", fallback: "reuters",   markup_bps: 8,  pegged: true },
  { pair: "EUR/USD", source: "investing", fallback: "reuters",   markup_bps: 10 },
  { pair: "GBP/USD", source: "investing", fallback: "reuters",   markup_bps: 10 },
  { pair: "USD/SGD", source: "reuters",   fallback: "investing", markup_bps: 10 },
  { pair: "USD/ZAR", source: "reuters",   fallback: "investing", markup_bps: 15 },
];

// --- Payment-route internals ----------------------------------------------
// Legs reference providers. Fees are per-leg and can be fixed or %-based.

const FEE_BASES = [
  { value: "gross_pct",    label: "% of gross amount" },
  { value: "net_pct",      label: "% of net amount" },
  { value: "fixed_ccy",    label: "Fixed in currency" },
  { value: "spread_bps",   label: "FX spread (bps)" },
  { value: "tier",         label: "Tiered by amount" },
];

const LEG_TYPES = [
  { value: "collect",  label: "Collect",   hint: "Money in from customer → Bedrock account" },
  { value: "fx",       label: "FX",        hint: "Convert between currencies" },
  { value: "transfer", label: "Transfer",  hint: "Move between Bedrock accounts" },
  { value: "payout",   label: "Payout",    hint: "Send to external beneficiary" },
];

const ROUTE_TEMPLATES = [
  {
    id: "RT-081", name: "RU→AE standard (USD/AED)", status: "live", uses: 312,
    legs: [
      { n: 1, type: "collect",  from: "Customer (RU)",      to: "Bedrock RU · Raiffeisen",    ccy: "RUB", provider: "PRV-001", fee: { base: "gross_pct",  value: 0.35 } },
      { n: 2, type: "fx",       from: "Bedrock RU",          to: "Bedrock RU",                 ccy: "RUB→USD", provider: "PRV-001", fee: { base: "spread_bps", value: 8 } },
      { n: 3, type: "transfer", from: "Bedrock RU",          to: "Bedrock AE · Emirates NBD",  ccy: "USD", provider: "PRV-004", fee: { base: "gross_pct",  value: 0.60 } },
      { n: 4, type: "payout",   from: "Bedrock AE",          to: "Beneficiary (AE)",           ccy: "USD", provider: "PRV-004", fee: { base: "fixed_ccy",  value: 85, ccy: "USD" } },
    ],
    margin_bps: 29,
  },
];

const TREASURY_DEAL = {
  id: "DL-4401",
  customer: "Nordmax Trading LLC",
  beneficiary: "Lotus Global FZE",
  gross: 142_000, ccy: "USD",
  route: "RT-081",
  stage: "funding",
  operations: [
    { id: "OP-1", title: "Invoice sent to customer",    kind: "doc",    status: "done",     when: "Apr 18 10:12", actor: "AE", meta: "INV-2201.pdf · 142 000 USD" },
    { id: "OP-2", title: "Contract signed",              kind: "doc",    status: "done",     when: "Apr 18 14:40", actor: "AE", meta: "Contract-DL4401.pdf · both parties" },
    { id: "OP-3", title: "Funds received (RUB leg)",     kind: "money_in", status: "done",   when: "Apr 19 09:02", actor: "Treasury", meta: "13 126 568.00 RUB · Raiffeisen" },
    { id: "OP-4", title: "FX booked RUB→USD",            kind: "fx",     status: "done",     when: "Apr 19 09:18", actor: "SY", meta: "rate 92.4400 · 142 000.00 USD" },
    { id: "OP-5", title: "Internal transfer RU→AE",      kind: "money_out",status: "in_flight", when: "Apr 20 15:10", actor: "SY", meta: "Raiffeisen → Emirates NBD · 142 000.00 USD" },
    { id: "OP-6", title: "Proof of payment to attach",   kind: "proof",  status: "pending",  when: "—",           actor: "—",  meta: "awaiting SWIFT MT103 copy" },
    { id: "OP-7", title: "Payout to beneficiary",        kind: "payout", status: "queued",   when: "scheduled Apr 21", actor: "—", meta: "Lotus Global · 140 040.00 USD" },
    { id: "OP-8", title: "Close deal · reconcile books", kind: "close",  status: "queued",   when: "after payout", actor: "—",  meta: "post to GL, send closing statement" },
  ],
};

window.BEDROCK_DATA = {
  CUSTOMERS, DEALS, STAGE_LABEL, STAGE_BADGE,
  COUNTERPARTIES, REQUISITES, BALANCES, RATES, ROUTES,
  PROVIDER_KINDS, PROVIDERS, RATE_SOURCES, RATE_DEFAULTS,
  FEE_BASES, LEG_TYPES, ROUTE_TEMPLATES, TREASURY_DEAL,
};

// Formatters
const fmtMoney = (n, ccy, { signed = false } = {}) => {
  if (n == null || Number.isNaN(n)) return "—";
  const abs = Math.abs(n);
  const sign = n < 0 ? "−" : signed ? "+" : "";
  const parts = abs.toFixed(2).split(".");
  // Thin space separators
  const whole = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, "\u2009");
  return { sign, whole, frac: parts[1], ccy };
};

const Money = ({ value, ccy, signed = false, signColor = true, muteUnit = true, showZero = true }) => {
  if (value === 0 && !showZero) return <span className="mono" style={{ color: "var(--text-faint)" }}>—</span>;
  const m = fmtMoney(value, ccy, { signed });
  if (typeof m !== "object") return <span className="mono">—</span>;
  const cls = signColor ? (value > 0 && signed ? "pos" : value < 0 ? "neg" : "") : "";
  return (
    <span className={`mono money ${cls}`}>
      {m.sign}{m.whole}<span className="sep">.</span>{m.frac}
      {muteUnit && ccy ? <span className="unit">{ccy}</span> : (ccy ? ` ${ccy}` : null)}
    </span>
  );
};

const Num = ({ value, digits = 2 }) => {
  if (value == null || Number.isNaN(value)) return <span className="mono">—</span>;
  const parts = value.toFixed(digits).split(".");
  const whole = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, "\u2009");
  return (
    <span className="mono">
      {whole}{parts[1] ? <><span className="sep">.</span>{parts[1]}</> : null}
    </span>
  );
};

window.Money = Money;
window.Num = Num;
