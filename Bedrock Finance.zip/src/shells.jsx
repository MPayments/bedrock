/* global React, Icon, Btn, IconBtn, Badge, Segmented, cx */
const { useState } = React;

// Finance sidebar
const NAV_FINANCE = [
  { section: "Treasury" },
  { id: "balances", label: "Balances", icon: "wallet", badge: "6" },
  { id: "rates", label: "Currency rates", icon: "rates" },
  { id: "transfers", label: "Transfers", icon: "exchange" },
  { id: "liquidity", label: "Liquidity", icon: "activity" },
  { section: "Entities" },
  { id: "customers-fin", label: "Customers", icon: "users", badge: "124" },
  { id: "counterparties", label: "Counterparties", icon: "briefcase" },
  { id: "organizations", label: "Organizations", icon: "building" },
  { id: "requisites", label: "Requisites", icon: "folder" },
  { id: "providers", label: "Requisite providers", icon: "shield" },
  { section: "Flows" },
  { id: "routes", label: "Payment routes", icon: "route" },
  { id: "workbench", label: "Deal workbench", icon: "briefcase" },
  { id: "documents", label: "Documents", icon: "file" },
  { id: "accounting", label: "Accounting", icon: "bar" },
  { section: "System" },
  { id: "users-fin", label: "Users", icon: "users" },
  { id: "settings", label: "Settings", icon: "settings" },
];

const FinanceSidebar = ({ collapsed, onToggle, activeId, onNavigate }) => (
  <aside className={cx("sidebar", collapsed && "collapsed")}>
    <div className="sidebar-brand">
      <div className="sidebar-brand-mark">B</div>
      <div className="sidebar-brand-text">
        <div className="sidebar-brand-name">Bedrock</div>
        <div className="sidebar-brand-app">Finance</div>
      </div>
    </div>

    <nav className="sidebar-nav">
      {NAV_FINANCE.map((it, i) => {
        if (it.section) {
          return <div key={"s"+i} className="sidebar-section-label">{it.section}</div>;
        }
        return (
          <div
            key={it.id}
            className={cx("nav-item", activeId === it.id && "active")}
            onClick={() => onNavigate?.(it.id)}
            title={collapsed ? it.label : undefined}
          >
            <Icon name={it.icon} size={15} />
            <span className="nav-item-label">{it.label}</span>
            {it.badge && <span className="nav-item-badge mono">{it.badge}</span>}
          </div>
        );
      })}
    </nav>

    <div className="sidebar-user">
      <span className="avatar">SY</span>
      <div className="sidebar-user-meta">
        <div className="sidebar-user-name">Sergey Yermolov</div>
        <div className="sidebar-user-role">Treasury Lead</div>
      </div>
      <button className="icon-btn sidebar-user-chev" title="Collapse" onClick={onToggle}>
        <Icon name={collapsed ? "side_expand" : "side_collapse"} size={15} />
      </button>
    </div>
  </aside>
);

// CRM top navbar
const NAV_CRM = [
  { id: "dashboard-crm", label: "Home", icon: "home" },
  { id: "deals", label: "Deals", icon: "briefcase" },
  { id: "customers-crm", label: "Customers", icon: "users" },
  { id: "applications", label: "Applications", icon: "activity" },
  { id: "calendar", label: "Calendar", icon: "calendar" },
  { id: "documents-crm", label: "Documents", icon: "file" },
  { id: "reports", label: "Reports", icon: "chart_line" },
];

const CrmTopnav = ({ activeId, onNavigate }) => (
  <header className="topnav">
    <div className="topnav-brand">
      <div className="sidebar-brand-mark">B</div>
      <div className="sidebar-brand-text">
        <div className="sidebar-brand-name">Bedrock</div>
        <div className="sidebar-brand-app">CRM</div>
      </div>
    </div>
    <nav className="topnav-nav">
      {NAV_CRM.map(it => (
        <div key={it.id}
          className={cx("topnav-item", activeId === it.id && "active")}
          onClick={() => onNavigate?.(it.id)}
        >
          <Icon name={it.icon} size={14} />
          {it.label}
        </div>
      ))}
    </nav>
    <div className="topnav-spacer" />
    <div className="topnav-actions">
      <div className="input-group" style={{ width: 260 }}>
        <span className="input-group-prefix"><Icon name="search" size={13} /></span>
        <input className="input" placeholder="Search deals, customers…" />
        <span className="input-group-suffix">⌘K</span>
      </div>
      <IconBtn name="bell" title="Notifications" />
      <IconBtn name="help" title="Help" />
      <span className="avatar sm" title="Anna Ermolova">AE</span>
    </div>
  </header>
);

const Subheader = ({ crumbs, right }) => (
  <div className="subheader">
    <nav className="crumbs">
      {crumbs.map((c, i) => (
        <React.Fragment key={i}>
          {i > 0 && <Icon className="crumbs-sep" name="chev_right" size={12} />}
          <span className={i === crumbs.length - 1 ? "crumbs-current" : ""}>{c}</span>
        </React.Fragment>
      ))}
    </nav>
    <div className="spacer" />
    {right}
  </div>
);

Object.assign(window, { FinanceSidebar, CrmTopnav, Subheader });
