/* global React, Icon, Btn, IconBtn, Badge, Segmented, cx */
const { useState } = React;

// Bilingual form coordinator
// Supports three layouts: "toggle" (form-level lang switch),
// "sbs" (side-by-side RU | EN), "tabs" (per-field lang tabs).

const LocaleTabs = ({ value, onChange, hasValues, size = "md" }) => {
  const items = [
    { v: "all", label: "All" },
    { v: "ru", label: "RU" },
    { v: "en", label: "EN" },
  ];
  return (
    <div className="segmented" role="tablist" aria-label="Form language">
      {items.map(it => (
        <button
          key={it.v}
          type="button"
          role="tab"
          aria-selected={value === it.v}
          className={cx("segmented-item", value === it.v && "active")}
          onClick={() => onChange(it.v)}
        >
          {it.label}
          {it.v !== "all" && (
            <span className={cx("locale-chip", hasValues?.[it.v] ? "filled" : "missing")}
              style={{ padding: "0 4px", fontSize: 9, border: "none", background: "transparent" }}>
              {hasValues?.[it.v] ? "●" : "○"}
            </span>
          )}
        </button>
      ))}
    </div>
  );
};

const BilingualToolbar = ({ lang, onLang, completeness, onTranslateAll, translating, layout, onLayout }) => {
  const pct = Math.round(completeness * 100);
  return (
    <div className="bilingual-toolbar">
      <div className="bilingual-toolbar-left">
        <div className="eyebrow hstack" style={{ gap: 6 }}>
          <Icon name="language" size={13} /> Localization
        </div>
        <LocaleTabs value={lang} onChange={onLang}
          hasValues={{ ru: completeness > 0, en: completeness > 0.4 }} />
      </div>
      <div className="hstack" style={{ gap: 14 }}>
        <div className="bilingual-meter" title="Share of localized fields filled in both languages">
          <span>Bilingual</span>
          <div className="bilingual-meter-bar">
            <div className="bilingual-meter-fill" style={{ width: `${pct}%` }} />
          </div>
          <span className="mono" style={{ fontSize: 11 }}>{pct}%</span>
        </div>
        <Btn size="sm" variant="secondary" icon={translating ? "refresh" : "translate"} onClick={onTranslateAll} disabled={translating}>
          {translating ? "Translating…" : "Translate all"}
        </Btn>
      </div>
    </div>
  );
};

// A single bilingual field, rendered according to layout
// value shape: { base: string, locales: { ru?: string, en?: string } }
const BilingualField = ({
  layout, lang, label, required, value, onChange, placeholder, multiline,
}) => {
  const ru = value?.locales?.ru ?? "";
  const en = value?.locales?.en ?? "";
  const filled = { ru: ru.length > 0, en: en.length > 0 };

  const update = (which, v) => {
    const next = { ...(value || {}), locales: { ...(value?.locales || {}) } };
    next.locales[which] = v;
    next.base = which === "en" ? v : (next.base || (which === "ru" && !next.locales.en ? v : next.base));
    onChange?.(next);
  };

  const translateOne = (fromLang) => {
    const src = fromLang === "ru" ? ru : en;
    const target = fromLang === "ru" ? "en" : "ru";
    if (!src) return;
    const mock = target === "en" ? `${src} (auto-translated)` : `${src} (авто-перевод)`;
    update(target, mock);
  };

  const labelRow = (
    <div className="field-label">
      <span>{label}{required && <span className="req"> *</span>}</span>
      <span className="hstack" style={{ gap: 4, marginLeft: "auto" }}>
        <span className={cx("locale-chip", filled.ru ? "filled" : "missing")}>RU</span>
        <span className={cx("locale-chip", filled.en ? "filled" : "missing")}>EN</span>
      </span>
    </div>
  );

  const inputProps = {
    placeholder,
  };

  if (layout === "sbs") {
    return (
      <div className="field">
        {labelRow}
        <div className="bilingual-sbs">
          <div className="sbs-cell">
            <div className="hstack" style={{ justifyContent: "space-between" }}>
              <span className="sbs-cell-label">Русский</span>
              <button type="button" className="btn ghost sm" style={{ height: 18, padding: "0 5px", fontSize: 10.5 }}
                onClick={() => translateOne("en")} title="Translate from EN to RU" disabled={!en}>
                <Icon name="translate" size={11} /> ← EN
              </button>
            </div>
            {multiline
              ? <textarea className="input textarea" rows={3} value={ru} onChange={e => update("ru", e.target.value)} {...inputProps} />
              : <input className="input" value={ru} onChange={e => update("ru", e.target.value)} {...inputProps} />
            }
          </div>
          <div className="sbs-cell">
            <div className="hstack" style={{ justifyContent: "space-between" }}>
              <span className="sbs-cell-label">English</span>
              <button type="button" className="btn ghost sm" style={{ height: 18, padding: "0 5px", fontSize: 10.5 }}
                onClick={() => translateOne("ru")} title="Translate from RU to EN" disabled={!ru}>
                <Icon name="translate" size={11} /> ← RU
              </button>
            </div>
            {multiline
              ? <textarea className="input textarea" rows={3} value={en} onChange={e => update("en", e.target.value)} {...inputProps} />
              : <input className="input" value={en} onChange={e => update("en", e.target.value)} {...inputProps} />
            }
          </div>
        </div>
      </div>
    );
  }

  if (layout === "tabs") {
    return (
      <div className="field">
        {labelRow}
        <BilingualTabsField ru={ru} en={en} update={update} translateOne={translateOne} multiline={multiline} placeholder={placeholder} />
      </div>
    );
  }

  // "toggle" — show only the active language, or both if lang==="all"
  return (
    <div className="field">
      {labelRow}
      {lang === "all" ? (
        <div className="bilingual-sbs">
          <div className="sbs-cell">
            <span className="sbs-cell-label">RU</span>
            {multiline
              ? <textarea className="input textarea" rows={3} value={ru} onChange={e => update("ru", e.target.value)} {...inputProps} />
              : <input className="input" value={ru} onChange={e => update("ru", e.target.value)} {...inputProps} />}
          </div>
          <div className="sbs-cell">
            <span className="sbs-cell-label">EN</span>
            {multiline
              ? <textarea className="input textarea" rows={3} value={en} onChange={e => update("en", e.target.value)} {...inputProps} />
              : <input className="input" value={en} onChange={e => update("en", e.target.value)} {...inputProps} />}
          </div>
        </div>
      ) : (
        <div className="input-group">
          {multiline
            ? <textarea className="input textarea" rows={3}
                value={lang === "ru" ? ru : en}
                onChange={e => update(lang, e.target.value)}
                {...inputProps} />
            : <input className="input"
                value={lang === "ru" ? ru : en}
                onChange={e => update(lang, e.target.value)}
                {...inputProps} />
          }
          <button type="button" className="input-group-suffix"
            style={{ cursor: "pointer", background: "var(--surface)" }}
            title={`Fill ${lang === "ru" ? "EN" : "RU"} from ${lang.toUpperCase()}`}
            onClick={() => translateOne(lang)}
            disabled={lang === "ru" ? !ru : !en}>
            <Icon name="translate" size={12} />
          </button>
        </div>
      )}
    </div>
  );
};

const BilingualTabsField = ({ ru, en, update, translateOne, multiline, placeholder }) => {
  const [active, setActive] = useState("ru");
  return (
    <div className="bilingual-tabs">
      <div className="bilingual-tabs-head">
        <div className={cx("bilingual-tabs-tab", active === "ru" && "active")} onClick={() => setActive("ru")}>
          RU <span className={cx("locale-chip", ru ? "filled" : "missing")} style={{ padding: "0 4px", fontSize: 9, border: "none", background: "transparent" }}>{ru ? "●" : "○"}</span>
        </div>
        <div className={cx("bilingual-tabs-tab", active === "en" && "active")} onClick={() => setActive("en")}>
          EN <span className={cx("locale-chip", en ? "filled" : "missing")} style={{ padding: "0 4px", fontSize: 9, border: "none", background: "transparent" }}>{en ? "●" : "○"}</span>
        </div>
        <span style={{ flex: 1 }} />
        <button type="button" className="btn ghost sm" style={{ height: 22, padding: "0 6px", marginRight: 4 }}
          onClick={() => translateOne(active === "ru" ? "en" : "ru")}
          disabled={active === "ru" ? !en : !ru}>
          <Icon name="translate" size={11} /> Fill from {active === "ru" ? "EN" : "RU"}
        </button>
      </div>
      <div className="bilingual-tabs-body">
        {multiline
          ? <textarea className="input textarea" rows={3}
              value={active === "ru" ? ru : en}
              onChange={e => update(active, e.target.value)}
              placeholder={placeholder} />
          : <input className="input"
              value={active === "ru" ? ru : en}
              onChange={e => update(active, e.target.value)}
              placeholder={placeholder} />
        }
      </div>
    </div>
  );
};

Object.assign(window, { BilingualToolbar, BilingualField, LocaleTabs });
