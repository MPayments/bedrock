/* global React, Icon */
const { useState, useRef, useEffect } = React;

const cx = (...a) => a.filter(Boolean).join(" ");

const Btn = ({ variant = "secondary", size = "md", icon, iconRight, children, onClick, className, disabled, title, as }) => {
  const Cmp = as || "button";
  return (
    <Cmp
      className={cx("btn", variant, size !== "md" && size, !children && "icon-only", className)}
      onClick={onClick}
      disabled={disabled}
      title={title}
      type="button"
    >
      {icon && <Icon name={icon} size={14} />}
      {children}
      {iconRight && <Icon name={iconRight} size={14} />}
    </Cmp>
  );
};

const IconBtn = ({ name, onClick, title, bordered, className }) => (
  <button type="button" className={cx("icon-btn", bordered && "bordered", className)} onClick={onClick} title={title}>
    <Icon name={name} size={15} />
  </button>
);

const Badge = ({ tone = "default", children, dot = false, outline = false, mono = false, className }) => (
  <span className={cx("badge", tone !== "default" && tone, dot && "dot", outline && "outline", mono && "mono", className)}>
    {children}
  </span>
);

const Segmented = ({ value, onChange, options }) => (
  <div className="segmented">
    {options.map(o => (
      <button
        key={o.value}
        type="button"
        className={cx("segmented-item", value === o.value && "active")}
        onClick={() => onChange(o.value)}
      >
        {o.icon && <Icon name={o.icon} size={13} />}
        {o.label}
        {o.count != null && <span style={{ color: "var(--text-faint)", fontFamily: "var(--font-mono)", fontSize: 10.5, marginLeft: 2 }}>{o.count}</span>}
      </button>
    ))}
  </div>
);

const Tabs = ({ value, onChange, items }) => (
  <div className="tabs">
    {items.map(it => (
      <div key={it.value}
        className={cx("tab", value === it.value && "active")}
        onClick={() => onChange(it.value)}
      >
        {it.icon && <Icon name={it.icon} size={14} />}
        {it.label}
        {it.count != null && <span className="tab-count mono">{it.count}</span>}
      </div>
    ))}
  </div>
);

const Card = ({ title, sub, actions, foot, children, bodyPad = true, flush, className }) => (
  <div className={cx("card", className)}>
    {(title || actions) && (
      <div className="card-head">
        <div className="card-head-left">
          {typeof title === "string" ? <div className="card-title">{title}</div> : title}
          {sub && <div className="card-sub">{sub}</div>}
        </div>
        {actions && <div className="card-head-actions">{actions}</div>}
      </div>
    )}
    <div className={cx("card-body", !bodyPad && "tight", flush && "flush")}>{children}</div>
    {foot && <div className="card-foot between">{foot}</div>}
  </div>
);

// Save/cancel footer for card-level edits
const CardSaveFoot = ({ dirty, onSave, onReset }) => (
  <>
    <div className="dirty-hint">
      {dirty ? <><span className="dot" /> Unsaved changes in this card</> : <span style={{ color: "var(--text-faint)" }}>Up to date</span>}
    </div>
    <div className="hstack">
      <Btn variant="ghost" size="sm" onClick={onReset} disabled={!dirty}>Cancel</Btn>
      <Btn variant="primary" size="sm" icon="check" onClick={onSave} disabled={!dirty}>Save section</Btn>
    </div>
  </>
);

// Country flag emoji placeholder (monochrome rendering) — we use a small pill instead
const CountryPill = ({ code }) => (
  <span className="mono" style={{
    display: "inline-flex", alignItems: "center", justifyContent: "center",
    fontSize: 10, padding: "1px 6px", border: "1px solid var(--border-strong)",
    borderRadius: 4, color: "var(--text-secondary)", letterSpacing: "0.04em",
    background: "var(--surface)",
  }}>{code}</span>
);

const Field = ({ label, hint, children, required, action }) => (
  <div className="field">
    {label && (
      <div className="field-label">
        <span>{label}{required && <span className="req"> *</span>}</span>
        <span style={{ flex: 1 }} />
        {action}
      </div>
    )}
    {children}
    {hint && <div className="field-hint">{hint}</div>}
  </div>
);

const Input = ({ prefix, suffix, ...props }) => {
  if (prefix || suffix) {
    return (
      <div className="input-group">
        {prefix && <span className="input-group-prefix">{prefix}</span>}
        <input className="input" {...props} />
        {suffix && <span className="input-group-suffix">{suffix}</span>}
      </div>
    );
  }
  return <input className="input" {...props} />;
};

const Select = ({ children, ...props }) => (
  <div className="input-group">
    <select className="input" {...props}>{children}</select>
    <span className="input-group-suffix" style={{ background: "transparent", borderLeft: "none", marginLeft: -26, pointerEvents: "none" }}>
      <Icon name="chev_down" size={13} />
    </span>
  </div>
);

const Checkbox = ({ checked, onChange, label }) => (
  <label className="hstack" style={{ cursor: "pointer", fontSize: 13 }}>
    <span className={cx("checkbox", checked && "checked")} onClick={() => onChange?.(!checked)}>
      {checked && <Icon name="check" size={11} stroke={2.5} />}
    </span>
    {label && <span>{label}</span>}
  </label>
);

const Switch = ({ on, onChange }) => (
  <button type="button" className={cx("switch", on && "on")} onClick={() => onChange?.(!on)} aria-pressed={on} />
);

const Sparkline = ({ data, width = 80, height = 28, color }) => {
  if (!data?.length) return null;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const step = width / (data.length - 1);
  const pts = data.map((v, i) => [i * step, height - ((v - min) / range) * (height - 4) - 2]);
  const line = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(" ");
  const fill = `${line} L${width} ${height} L0 ${height} Z`;
  return (
    <svg className="spark" width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
      <path className="fill" d={fill} />
      <path className="line" d={line} style={color ? { stroke: color } : undefined} />
    </svg>
  );
};

// Click-outside helper
const useOutside = (onClose) => {
  const ref = useRef(null);
  useEffect(() => {
    const fn = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose?.(); };
    document.addEventListener("mousedown", fn);
    return () => document.removeEventListener("mousedown", fn);
  }, [onClose]);
  return ref;
};

// Searchable combobox — good for long lists (providers, customers, etc.)
// options: [{ value, label, sub?, icon?, group?, meta? }]
const SearchSelect = ({ options, value, onChange, placeholder = "Select…", searchPlaceholder = "Search…", renderOption, renderValue, disabled }) => {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const ref = useOutside(() => { setOpen(false); setQ(""); });
  const current = options.find(o => o.value === value);

  const filtered = q
    ? options.filter(o =>
        (o.label || "").toLowerCase().includes(q.toLowerCase()) ||
        (o.sub || "").toLowerCase().includes(q.toLowerCase()) ||
        (o.group || "").toLowerCase().includes(q.toLowerCase())
      )
    : options;

  // Group by `group` field preserving first-seen order
  const groups = [];
  const seen = new Map();
  filtered.forEach(o => {
    const g = o.group || "";
    if (!seen.has(g)) { seen.set(g, groups.length); groups.push({ label: g, items: [] }); }
    groups[seen.get(g)].items.push(o);
  });

  return (
    <div ref={ref} className={cx("search-select", open && "open", disabled && "disabled")}>
      <button type="button" className="search-select-trigger" onClick={() => !disabled && setOpen(v => !v)} disabled={disabled}>
        <span className="search-select-value">
          {current
            ? (renderValue ? renderValue(current) : (
                <>
                  {current.icon && <Icon name={current.icon} size={13} />}
                  <span>{current.label}</span>
                  {current.meta && <span className="search-select-meta">{current.meta}</span>}
                </>
              ))
            : <span className="search-select-placeholder">{placeholder}</span>}
        </span>
        <Icon name="chev_down" size={13} />
      </button>
      {open && (
        <div className="search-select-pop">
          <div className="search-select-search">
            <Icon name="search" size={13} />
            <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder={searchPlaceholder} />
          </div>
          <div className="search-select-list">
            {groups.length === 0 && <div className="search-select-empty">No matches</div>}
            {groups.map((g, gi) => (
              <div key={gi}>
                {g.label && <div className="search-select-group">{g.label}</div>}
                {g.items.map(o => (
                  <button type="button" key={o.value}
                    className={cx("search-select-opt", o.value === value && "active")}
                    onClick={() => { onChange?.(o.value); setOpen(false); setQ(""); }}>
                    {renderOption
                      ? renderOption(o)
                      : (
                        <>
                          {o.icon && <Icon name={o.icon} size={13} />}
                          <span className="search-select-opt-label">{o.label}</span>
                          {o.sub && <span className="search-select-opt-sub">{o.sub}</span>}
                          {o.meta && <span className="search-select-opt-meta">{o.meta}</span>}
                        </>
                      )}
                    {o.value === value && <Icon name="check" size={13} />}
                  </button>
                ))}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

Object.assign(window, {
  cx, Btn, IconBtn, Badge, Segmented, Tabs, Card, CardSaveFoot,
  CountryPill, Field, Input, Select, SearchSelect, Checkbox, Switch, Sparkline, useOutside,
});
